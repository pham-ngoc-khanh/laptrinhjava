# Xóa năm học 2020-2021 và 2021-2022

Mở MySQL Workbench và chạy file:

`sql/XOA_NAM_HOC_2020_2021_2021_2022.sql`

File này xóa dữ liệu phụ thuộc của 2 năm học trước rồi xóa 2 năm học khỏi `HocKyNamHoc` và `NamHocHocPhi`.

Sau khi chạy xong, khởi động lại ứng dụng. Danh sách Năm học sẽ còn từ 2025-2026 đến 2029-2030 (theo dữ liệu mẫu hiện tại).

Lưu ý: thao tác xóa này là xóa thật dữ liệu liên quan đến 2 năm học cũ trong CSDL hiện tại. Hãy sao lưu CSDL nếu bạn muốn giữ dữ liệu lịch sử.
