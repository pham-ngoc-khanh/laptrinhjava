# Hàng đợi triển khai: Mô hình 3 tầng + Phân quyền 3 Vai trò

Ánh xạ 1:1 với các AC trong spec.md. Thực hiện theo thứ tự ưu tiên (priority).

---

## Task 1: Bổ sung Role ADMIN và cập nhật Model / Session / DAO cơ sở

**Status:** pending
**Priority:** high
**Map AC:** AC-2, AC-3, AC-8

**Mô tả:**
- Chỉnh `VaiTro.java`: Thêm `ADMIN("Quản trị hệ thống")`, cập nhật `fromDb()` nhận `"ADMIN"`, `"ADMINISTRATOR"`, `"QUAN_TRI"`.
- Chỉnh `TaiKhoan.java`: Thêm method `isAdmin()`.
- Chỉnh `UserSession.java`: Thêm method `isAdmin()`, `getVaiTro()`.
- Chỉnh `TaiKhoanDAO.java`: Thêm đủ CRUD: `getAll()`, `getByTenDN()`, `getById()`, `search()`, `insert()`, `update()`, `delete()`, `updateTrangThai()`, `resetPassword()`, `kiemTraAdminCuoiCung()`.
- Chỉnh `TaiKhoanDAO.authenticate`: Nếu tìm thấy tk nhưng `TrangThai='Khoa'` → ném Exception với message "Tài khoản đã bị khóa…" (hoặc trả về một trạng thái đặc biệt).

**Test Requirements (TR):**
- `rule (T1-1)`: Biên dịch không lỗi.
- `rule (T1-2)`: `VaiTro.fromDb("ADMIN")` != null, `VaiTro.fromDb("THU_KY")` vẫn đúng.
- `rule (T1-3)`: `TaiKhoan tk` set `vaiTro=ADMIN` → `tk.isAdmin()` true.
- `rule (T1-4)`: Đọc file `TaiKhoanDAO.java` → có 9 phương thức theo mô tả.

---

## Task 2: Tạo bảng AuditLog và SQL seed cho Admin

**Status:** pending
**Priority:** high
**Map AC:** AC-10, AC-2

**Mô tả:**
- Sửa `init.sql`: Thêm `CREATE TABLE IF NOT EXISTS AuditLog (MaLog INT AUTO_INCREMENT PK, ThoiGian DATETIME, MaTK INT, TenDangNhap VARCHAR(50), HanhDong VARCHAR(50), DoiTuong VARCHAR(50), ChiTiet VARCHAR(500), NguoiThucHien VARCHAR(100))`.
- Sửa `seed.sql`: Thêm tài khoản admin (`INSERT IGNORE INTO TaiKhoan ... ('admin','123456','ADMIN',NULL,'Quản trị Hệ thống','Hoat dong')`).
- Cập nhật `DatabaseInitializer` (nếu có) chạy init → seed đúng thứ tự (đảm bảo init chạy trước seed).

**Test Requirements:**
- `rule (T2-1)`: init.sql có đúng khai báo bảng AuditLog.
- `rule (T2-2)`: seed.sql có dòng admin với vai trò ADMIN, mk=123456.

---

## Task 3: Tạo Service Layer (Business Logic) – toàn bộ DAO được bọc Service

**Status:** pending
**Priority:** high
**Map AC:** AC-9, AC-11, NFR-2

**Mô tả:**
Tạo package `com.mycompany.baitaplon.service` với các class:
- `TaiKhoanService`: bao bọc TaiKhoanDAO. Thêm validate nghiệp vụ (check trùng tên DN, check admin cuối cùng trước khi xóa/khóa, đặt mk mặc định 123456).
- `SinhVienService`: bao bọc SinhVienDAO. Thêm validate (trùng MaSV, check ngày sinh, tuổi hợp lệ, check lớp tồn tại). **Transaction thêm SV = thêm SinhVien + thêm TaiKhoan SINH_VIEN** (moved từ DAO lên Service).
- `HocPhiService`, `CongNoService`, `ThanhToanService`, `YeuCauThanhToanService`, `DangKyHocPhanService`, `BaoCaoService`, `AuditService`: bao bọc DAO tương ứng.
- `AuditService`: method `ghi(String hanhDong, String doiTuong, String chiTiet)` → gọi `AuditDAO.insert()`.
- Mọi `setAutoCommit(false) / commit / rollback` **chuyển hết vào Service** (DAO chỉ thực thi từng câu lệnh đơn, quản lý transaction ở lớp Service).

**Test Requirements:**
- `rule (T3-1)`: LS package `service/` → có ≥ 8 file Service.java liệt kê trên.
- `rule (T3-2)`: `SinhVienService.insert()` có block `conn.setAutoCommit(false)` → try 2 lần INSERT (SinhVien + TaiKhoan) → commit, exception rollback.
- `rule (T3-3)`: grep trên `ui/**/*.java` `pattern=import.*dao.*` kết quả = 0 (không file UI nào gọi DAO).
- `rubric (T3-4)`: Độ tách bạch Service – DAO – UI (0=DAO vẫn lẫn UI, 1=Service có nhưng vài chỗ vẫn gọi DAO trực tiếp, 2=UI chỉ gọi Service). Ngưỡng đạt: ≥ 2.

---

## Task 4: Refactor tất cả UI – đổi từ gọi DAO sang gọi Service

**Status:** pending
**Priority:** high
**Map AC:** AC-9, AC-11, NFR-2, NFR-3

**Mô tả:**
- Tất cả `*Panel.java` + `LoginDialog.java` + `MainFrame.java`:
  - Xóa import `dao.*`, thay bằng import `service.*`.
  - Thay các field `private XxxDAO xxxDAO` → `private XxxService xxxService = new XxxService();`.
  - Gọi `xxxService.xxx()` thay vì `xxxDAO.xxx()`.
- Với các hành động quan trọng (đăng nhập, đổi mk, thêm SV, thêm TK, xác nhận TT, reset mk) → sau khi thành công, gọi `AuditService.ghi(...)`.
- `LoginDialog.doLogin()`: sau khi authenticate OK → gọi `AuditService.ghi("DANG_NHAP", "TaiKhoan", "Thành công bởi: " + tenDN)`; nếu thất bại (mk sai / tk khóa) → ghi log thất bại.

**Test Requirements:**
- `rule (T4-1)`: `mvn -DskipTests compile` exit code 0.
- `rule (T4-2)`: `Grep -r "import com.mycompany.baitaplon.dao" src/main/java/com/mycompany/baitaplon/ui → 0 dòng`.
- `rule (T4-3)`: `AuditService.ghi()` được gọi ở ≥ 6 điểm (đăng nhập, đăng xuất, đổi mk, thêm SV, thêm TK, reset mk, xác nhận TT…).

---

## Task 5: Tạo màn hình Quản lý Tài khoản (TaiKhoanPanel) cho Admin

**Status:** pending
**Priority:** high
**Map AC:** AC-3, AC-6, AC-7, AC-8

**Mô tả:**
- Tạo `ui/TaiKhoanPanel.java` giống bố cục `SinhVienPanel`:
  - **Table 8 cột**: MaTK | Tên đăng nhập | Vai trò | Mã SV (nếu SV) | Họ tên | Trạng thái | Ngày tạo (nếu có) | Hành động (nút)
  - **Form bên trái/phải**: nhập Tên đăng nhập, MK (mặc định 123456), chọn Vai trò (combobox: ADMIN, THU_KY, SINH_VIEN), Mã SV (bỏ trống nếu không phải SV), Họ tên, Trạng thái (Hoạt động / Khóa).
  - **Nút**: Thêm / Sửa / Xóa / 🔑 Đặt lại MK / Làm mới form / 🔍 Tìm kiếm / Bộ lọc theo vai trò & trạng thái.
  - Xử lý nút Đặt lại MK: `TaiKhoanService.resetPassword(maTK)` → set `123456`.
  - Xử lý Xóa: `TaiKhoanService.delete(maTK)` → trong Service check `kiemTraAdminCuoiCung()`: nếu true và tk sắp xóa là admin duy nhất → báo lỗi.
  - Bảng ẩn cột mật khẩu (không hiển thị ra).

**Test Requirements:**
- `rule (T5-1)`: File `TaiKhoanPanel.java` tồn tại và compile được.
- `rule (T5-2)`: Có 4 nút Thêm, Sửa, Xóa, Đặt lại MK rõ ràng.
- `rule (T5-3)`: Scenario "tk admin cuối + bấm xóa" → hiển thị JOptionPane error, tài khoản không bị xóa (assert DB).

---

## Task 6: MainFrame – Thêm Nav Tài khoản, Phân quyền điều hướng đúng 3 role

**Status:** pending
**Priority:** high
**Map AC:** AC-3, AC-4, AC-5

**Mô tả:**
- Trong `MainFrame.createNav()`: Thêm mục `("👥", "Tài khoản")` sau mục Báo cáo → index thứ 9 (tổng 10).
- Trong `MainFrame.createContentArea()`: Khởi tạo `taiKhoanPanel = new TaiKhoanPanel()` và add vào CardLayout với key `CARD_TAIKHOAN="TAIKHOAN"`.
- Cập nhật `navigateTo(...)` nhận thêm case CARD_TAIKHOAN và refresh taiKhoanPanel.
- Sửa logic ẩn/hiện nav theo role:
  - ADMIN → đếm `count < 10` (đủ 10 mục).
  - THU_KY → đếm `count < 9` (bỏ mục Tài khoản).
  - SINH_VIEN → đếm `count < 5` (giữ 5 mục cũ: Tổng quan, Học phí, Công nợ, Thanh toán + đăng xuất/đổi mk).
- Cập nhật `MainFrame.lblStatus` hiển thị role hiện tại (VD: "🔐 Admin · Nguyễn Văn A").
- Cập nhật hint trong `LoginDialog.java` → `Admin: admin/123456 | Thư ký: thuky/123456 | Sinh viên: sv001/123456`.

**Test Requirements:**
- `rule (T6-1)`: Khởi động 3 role → kiểm tra menu điều hướng số lượng mục đúng 10/9/5.
- `rule (T6-2)`: Nav "Tài khoản" **không hiển thị** với THU_KY và SINH_VIEN (chỉ ADMIN thấy).
- `rule (T6-3)`: LoginDialog hint text chứa `admin / 123456`.

---

## Task 7: SinhVienPanel – Củng cố chức năng Thêm SV + Phân quyền ẩn form với SV

**Status:** pending
**Priority:** medium
**Map AC:** AC-4, AC-5, AC-6

**Mô tả:**
- Kiểm tra `SinhVienPanel.configureForRole()`: nếu `UserSession.isSinhVien()` → setVisible(false) toàn bộ form nhập liệu (MaSV, HoTen, ...) + các nút Thêm/Sửa/Xóa + chỉ load 1 dòng của mình như hiện tại.
- Đảm bảo khi thêm SV → gọi `SinhVienService.insert()` (đã chuyển từ DAO sang Service).
- Thêm hint bên cạnh nút Thêm: "💡 Tạo xong sẽ auto tạo tài khoản đăng nhập `mã_sv` / `123456`".

**Test Requirements:**
- `rule (T7-1)`: Login SV001 → vào menu Sinh viên → không nhìn thấy form nhập liệu, không có 3 nút Thêm/Sửa/Xóa.
- `rule (T7-2)`: Login thuky → thêm SV mới SV999 → insert DB xong, kiểm tra TaiKhoan có dòng TenDangNhap='sv999', VaiTro='SINH_VIEN', MatKhau='123456' → login sv999 được.

---

## Task 8: Audit log – Tạo AuditDAO + AuditPanel cho Admin xem Nhật ký

**Status:** pending
**Priority:** medium
**Map AC:** AC-10, AC-12, AC-13

**Mô tả:**
- Tạo `AuditDAO.java`: method `insert(AuditLog al)`, `getAll()`, `searchByKeyword(String kw)`, `getByDateRange(Date from, Date to)`.
- Tạo `AuditLog.java` model trong `model/` (MaLog, ThoiGian, MaTK, TenDangNhap, HanhDong, DoiTuong, ChiTiet, NguoiThucHien).
- **Tùy chọn (tiện lợi)**: Thêm 1 tab "📜 Nhật ký hoạt động" bên trong `TaiKhoanPanel` (dùng `JTabbedPane` bọc 2 tab: "Danh sách tài khoản" + "Nhật ký hệ thống") → không cần tạo Nav riêng.
- Gọi `AuditService.ghi()` ở các điểm sau:
  - Đăng nhập thành công / thất bại.
  - Đăng xuất.
  - Đổi mật khẩu (do chính user).
  - Thêm/Sửa/Xóa Tài khoản (Admin).
  - Reset mật khẩu (Admin).
  - Thêm/Sửa/Xóa Sinh viên (Thư ký / Admin).
  - Xác nhận / Từ chối yêu cầu thanh toán.

**Test Requirements:**
- `rule (T8-1)`: 2 file model/AuditLog.java + dao/AuditDAO.java tồn tại, compile OK.
- `rule (T8-2)`: Thực hiện 2 hành động (login admin, thêm SV) → SELECT * FROM AuditLog có ≥ 2 dòng mới.
- `rubric (T8-3)`: Số điểm gọi `ghi`; ≥ 6 điểm → 2, 3-5 điểm → 1, 0-2 → 0. Ngưỡng đạt: ≥ 1 (≥3 điểm).

---

## Task 9: Build + Smoke Test toàn bộ 3 Vai trò

**Status:** pending
**Priority:** high
**Map AC:** AC-1, NFR-1, NFR-2

**Mô tả:**
- Chạy `mvn -q -DskipTests compile`; nếu lỗi sửa.
- Smoke test (chạy tay, có thể mô phỏng kiểm tra bằng code read vì không có headless UI test framework):
  1. Đăng nhập admin → có 10 menu. Vào Tài khoản → thêm tài khoản thuky2 role=THU_KY → OK. Đặt lại mk thuky2 → OK. Cố xóa admin cuối → báo lỗi, không xóa. Đổi trạng thái sv001=Khóa → login sv001 bị chặn + báo đúng msg.
  2. Đăng nhập thuky → có 9 menu (không Tài khoản). Thêm SV SV999 → tài khoản sv999 tự tạo. Login sv999 → OK.
  3. Đăng nhập sv002 → có 5 menu, không thấy thêm/sửa/xóa SV, bảng sinh viên chỉ có 1 dòng SV002.

**Test Requirements:**
- `rule (T9-1)`: `mvn -DskipTests compile` exit code 0.
- `rule (T9-2)`: Không có WARNING import class không dùng.
- `rule (T9-3)`: Tất cả AC rule được kiểm tra và ghi bằng bằng chứng (file ảnh / kết quả SQL select) trong phần "Completion Evidence".

---

## Tổng quan map AC → Task

| AC rule/AC rubric | Được kiểm chứng bởi task |
|-------------------|-------------------------|
| AC-1 compile OK   | Task 9 |
| AC-2 login admin  | Task 1, Task 2, Task 9 |
| AC-3 ADMIN thấy 10 mục, có Tài khoản | Task 6, Task 5 |
| AC-4 THU_KY 9 mục, CRUD SV | Task 6, Task 7 |
| AC-5 SV 5 mục, ẩn edit | Task 6, Task 7 |
| AC-6 Auto tạo TK SV, login được | Task 3, Task 7, Task 9 |
| AC-7 Không xóa admin cuối | Task 1, Task 5 |
| AC-8 Khóa tài khoản → chặn đăng nhập | Task 1, Task 5, Task 9 |
| AC-9 UI không gọi DAO | Task 3, Task 4 |
| AC-10 Audit log ghi được | Task 2, Task 8 |
| AC-11 rubric 3-tier rõ ràng | Task 3, T3-4 |
| AC-12 rubric phân quyền UI+Service | Task 4, Task 6 |
| AC-13 rubric audit đủ hành động | Task 8, T8-3 |
