# Đặc tả: Mô hình 3 tầng + Phân quyền 3 Vai trò + Quản lý Tài khoản Sinh viên

## 1. Vấn đề (Problem)
Ứng dụng Quản lý Học phí & Công nợ hiện tại:
- Chưa áp dụng **mô hình 3 tầng** đầy đủ: lớp UI đang gọi trực tiếp DAO, thiếu tầng Business Logic (Service).
- Vai trò (roles) mới chỉ có **2 loại**: `SINH_VIEN` và `THU_KY` → **thiếu vai trò ADMIN** (Quản trị hệ thống - giám sát hoạt động, quản lý tài khoản).
- Chưa có giao diện **Quản lý tài khoản** (thêm/sửa/xóa/kích hoạt tài khoản, đặt lại mật khẩu).
- Form **Thêm sinh viên** đang tồn tại nhưng cần khẳng định hoạt động đúng theo phân quyền và tạo tài khoản sinh viên tự động đầy đủ.

## 2. Đối tượng người dùng (Users) & Mục tiêu (Goals)

| Vai trò | Người đại diện | Mục tiêu |
|---------|---------------|----------|
| **ADMIN (Quản trị hệ thống)** | Admin trường/phòng tài vụ | Giám sát toàn hệ thống, quản lý tài khoản người dùng (thêm/xóa/sửa/khóa/mở/đặt lại MK), xem mọi báo cáo, có quyền tối cao. |
| **THU_KY (Thư ký khoa)** | Thư ký khoa CNTT / Kinh tế / Điều dưỡng | Quản lý danh sách sinh viên (thêm/sửa/xóa), học phần, đăng ký HP, học kỳ, học phí, công nợ, thanh toán, báo cáo trong phạm vi nghiệp vụ. |
| **SINH_VIEN** | Sinh viên các lớp | Xem thông tin cá nhân, học phí, công nợ, lịch sử thanh toán, gửi yêu cầu thanh toán cho riêng mình. |

## 3. Phạm vi (Scope)

### Cần làm (In-Scope)
1. **Kiến trúc 3 tầng**: Tách riêng 3 layer rõ ràng:
   - **Layer 1 – Model (Dữ liệu)**: `model/*` (Entity / POJO) – giữ nguyên, bổ sung `AuditLog` nếu cần.
   - **Layer 2 – Business Logic (Tầng nghiệp vụ / Service)**: Tạo package `service/*` mới, toàn bộ UI chỉ gọi `Service`, **không gọi DAO trực tiếp**. Service gọi DAO và đóng gói transaction, validation, logic nghiệp vụ.
   - **Layer 3 – Presentation (UI)**: `ui/*` – chỉ gọi `Service`, tự do điều khiển giao diện theo role.
2. **3 Vai trò & Phân quyền UI**: Thêm `VaiTro.ADMIN`; cập nhật `UserSession`, `TaiKhoan`, `TaiKhoanDAO`, `MainFrame` (navigation + enable/disable tính năng theo role).
3. **Quản lý Tài khoản**: Thêm màn hình `TaiKhoanPanel` dành cho ADMIN (CRUD tài khoản, khóa/mở, reset mật khẩu, đổi vai trò).
4. **Thêm sinh viên + Auto tạo tài khoản SV**: Khẳng định chức năng trong `SinhVienPanel` (còn thiếu hoặc chưa đúng sẽ bổ sung), đảm bảo transaction thêm SV → tự tạo tài khoản SV thành công hoặc rollback hết.
5. **Audit / Nhật ký hoạt động** (tối thiểu): ghi log đăng nhập/đăng xuất + thao tác CRUD quan trọng xuống bảng `AuditLog` mới (tương ứng cột "Audit" trong rubric của đề tài).
6. **Seed dữ liệu**: Bổ sung tài khoản `admin` vào `seed.sql`, thêm đủ tài khoản SV cho các SV còn thiếu.
7. **Login hint**: Cập nhật gợi ý đăng nhập bao gồm tài khoản admin.

### Không làm (Out-of-Scope / Non-Goals)
- Không chuyển sang Web/WildFly (dự án là Java Swing Desktop); cột "Wildframe" trong rubric Excel sẽ được ghi chú là "Không áp dụng vì Swing app, không dùng app server; tính tương đương: dùng mô hình 3-tier desktop rõ ràng".
- Không dùng BCrypt cho mật khẩu (giữ plaintext đơn giản để demo; nếu đủ thời gian có thể thêm SHA-256).
- Không thay đổi database engine (giữ MySQL theo `database.properties`).

## 4. Yêu cầu chức năng (Functional Requirements)

**FR-1. Vai trò ADMIN**
- `rule` Enum `VaiTro` có giá trị `ADMIN("Quản trị hệ thống")`.
- `rule` `VaiTro.fromDb("ADMIN")` trả về `ADMIN` (chấp nhận cả "ADMIN", "ADMINISTRATOR").
- `rule` `TaiKhoan.isAdmin()`, `UserSession.isAdmin()` trả về `true` đúng cho role ADMIN.

**FR-2. Tầng Service (Business Layer)**
- `rule` Mỗi DAO có một Service tương ứng (ví dụ: `TaiKhoanService`, `SinhVienService`, `ThanhToanService`, …).
- `rule` Tất cả UI (`SinhVienPanel`, `ThongKePanel`, `ThanhToanPanel`, `LoginDialog`, ...) **không có `import ...dao.*`**, chỉ import `service.*` và `model.*`.
- `rule` Mọi phương thức ghi dữ liệu (insert/update/delete) trong Service **bắt transaction** (`setAutoCommit(false)` → commit/rollback) thay vì giao việc transaction cho từng DAO riêng lẻ.
- `rule` Validation nghiệp vụ (check trùng mã, check ngày hợp lệ, check tồn tại ràng buộc) tách vào Service, không nằm trong UI action handler.

**FR-3. Quản lý Tài khoản (chỉ ADMIN)**
- `rule` Menu "👥 Tài khoản" **chỉ xuất hiện cho role ADMIN** (ẩn đối với THU_KY và SINH_VIEN).
- `rule` Màn hình `TaiKhoanPanel` (JPanel) cho phép: xem danh sách tài khoản, tìm kiếm theo Tên đăng nhập / Họ tên, lọc theo Vai trò / Trạng thái.
- `rule` Thêm mới tài khoản: nhập TenDangNhap (duy nhất), MatKhau (mặc định `123456` nếu để trống), chọn VaiTro (ADMIN/THU_KY/SINH_VIEN), MaSV (nếu SINH_VIEN), HoTen.
- `rule` Sửa tài khoản: đổi HoTen, VaiTro, MaSV, TrangThai (Hoạt động / Khóa).
- `rule` Xóa tài khoản: có cảnh báo; **không cho xóa tài khoản admin cuối cùng** (tránh khóa vĩnh viễn hệ thống).
- `rule` Nút "🔑 Đặt lại mật khẩu": đặt lại mật khẩu thành `123456`.
- `rule` Các thông tin mật khẩu không hiển thị dạng text rõ ra bảng (hiển thị `••••••` hoặc để trống).

**FR-4. Thêm Sinh viên + Tạo tài khoản SV**
- `rule` Form Thêm sinh viên (`SinhVienPanel`) có đủ trường: MaSV, HoTen, NgaySinh (YYYY-MM-DD), GioiTinh (Nam/Nữ), DiaChi, SDT, Email, Lớp (combobox).
- `rule` Sau khi lưu SV thành công → **tự động tạo tài khoản SINH_VIEN** với TenDangNhap = `maSV.toLowerCase()`, MatKhau = `123456`, MaSV = mã sv vừa tạo, HoTen = họ tên sinh viên, TrangThai = Hoạt động.
- `rule` Nếu tạo tài khoản thất bại → rollback toàn bộ (không lưu sinh viên nữa) và báo lỗi rõ ràng.
- `rule` Chỉ **ADMIN và THU_KY** mới nhìn thấy nút Thêm/Sửa/Xóa trong SinhVienPanel; SINH_VIEN chỉ xem được dòng của mình, ẩn form thêm/sửa/xóa.

**FR-5. Phân quyền trên Thanh điều hướng (MainFrame Nav)**
- `rule` ADMIN thấy đủ tất cả 10 mục: Tổng quan | Sinh viên | Học phần | Đăng ký HP | Học kỳ | Học phí | Công nợ | Thanh toán | Báo cáo | **Tài khoản** (quản lý).
- `rule` THU_KY thấy 9 mục (như ADMIN nhưng **không thấy mục Tài khoản** quản lý).
- `rule` SINH_VIEN thấy 5 mục (như cũ): Tổng quan, Học phí, Công nợ, Thanh toán, Đổi mk / đăng xuất.

**FR-6. Audit log (Nhật ký hoạt động)**
- `rule` Tạo bảng `AuditLog(MaLog, ThoiGian, MaTK, TenDangNhap, HanhDong, DoiTuong, ChiTiet, IP_Username)` trong init.sql (audit theo rubric).
- `rule` Ghi log những hành động: Đăng nhập, Đăng xuất, Đổi mật khẩu, Thêm/Sửa/Xóa Tài khoản (ADMIN), Thêm/Sửa/Xóa Sinh viên (THU_KY), Xác nhận/Từ chối Thanh toán, Reset mật khẩu.
- `rule` ADMIN có tab/chức năng "📜 Nhật ký hệ thống" (có thể gộp dưới dạng bảng trong TaiKhoanPanel hoặc màn riêng đơn giản) để xem lịch sử.

**FR-7. Dữ liệu khởi tạo (Seed)**
- `rule` `seed.sql` có thêm tài khoản `admin / 123456` (vai trò ADMIN, họ tên "Quản trị Hệ thống").
- `rule` Các tài khoản SV (sv001 → sv005) vẫn giữ nguyên như cũ.
- `rule` Có sẵn tài khoản `thuky` (như cũ).

**FR-8. LoginDialog**
- `rule` Gợi ý đăng nhập dưới form: "Admin: `admin/123456` | Thư ký: `thuky/123456` | Sinh viên: `sv001/123456`".
- `rule` Đăng nhập sai → báo lỗi; tài khoản bị khóa (TrangThai = 'Khoa') → không vào được, báo "Tài khoản đã bị khóa, vui lòng liên hệ quản trị viên."

## 5. Yêu cầu phi chức năng (Non-Functional)

| ID | Nội dung | Loại |
|----|---------|------|
| NFR-1 | Build (compile) thành công, không có lỗi `cannot find symbol` và warning quan trọng. | rule |
| NFR-2 | Không phá vỡ tính năng cũ: đăng nhập 2 role cũ (THU_KY/SV), xem bảng, CRUD học phí/thanh toán/công nợ… vẫn chạy đúng như trước. | rule |
| NFR-3 | Phân quyền chặt chẽ: SINH_VIEN không thể gọi các method chỉ dành cho Admin/Thư ký được (dùng role check trong Service, không chỉ ở UI). | rule |
| NFR-4 | Màu sắc & chủ đề UI (Theme.java) giữ nguyên như phiên bản hiện tại (đã được người dùng chỉnh sửa trước đó). | rule |
| NFR-5 | Hạn chế viết comment thừa; code rõ ràng, đặt tên hàm/bien theo chuẩn cũ của dự án (tiếng Việt + camelCase). | rubric (đọc: 2=quá rõ, 1=khá, 0=rối) |
| NFR-6 | Tương thích DB hiện tại: không đổi cấu trúc cột của bảng cũ (chỉ ALTER TABLE nếu thực sự cần, ưu tiên CREATE TABLE mới). | rule |

## 6. Ràng buộc / Giả định (Constraints / Assumptions)
- Giữ `MySQL` và `com.mysql.cj.jdbc.Driver` theo `database.properties`.
- Mật khẩu giữ dạng text đơn giản cho demo (không hash) – tránh phức tạp không cần thiết.
- Không đổi UI library (giữ Swing + các `Rounded*`, `Styled*` hiện có).
- Giữ định dạng ngày: `YYYY-MM-DD` để khớp với SQL DATE và các `InputValidator` hiện có.
- "Mô hình đa tầng MVC / M-C-V" trong rubric Excel được hiểu tương đương: **Model (entity) ↔ Controller/Service (business) ↔ View (ui)** 3 tầng rõ ràng, phù hợp ứng dụng Desktop.

## 7. Câu hỏi / Điểm mở (nếu có)
Không – các quyết định mặc định trên phù hợp với mục tiêu bài tập lớn Java Swing. Người dùng có thể phản hồi trong lúc phê duyệt Spec nếu muốn thay đổi.

---

## Tiêu chí Chấp nhận (Acceptance Criteria)

**Loại: rule (đúng/sai khách quan)**

| ID | Nội dung |
|----|---------|
| AC-1 | Mở project → compile bằng `mvn -DskipTests compile` → exit code 0, không compile error. |
| AC-2 | Chạy app, đăng nhập bằng `admin / 123456` → vào thành công. |
| AC-3 | Role ADMIN: thấy đủ 10 mục trong thanh điều hướng (có mục "👥 Tài khoản"). |
| AC-4 | Role THU_KY: thấy 9 mục (không có Tài khoản), có thể thêm/sửa/xóa sinh viên. |
| AC-5 | Role SINH_VIEN: thấy 5 mục, không thấy Thêm/Sửa/Xóa, chỉ xem được dữ liệu của bản thân. |
| AC-6 | Thêm sinh viên (thu ky/admin) → lưu OK → tài khoản có tên đăng nhập = `masv.toLowerCase()`, mật khẩu `123456`, vai trò SINH_VIEN → login bằng tài khoản đó được. |
| AC-7 | Xóa tài khoản admin cuối cùng → hệ thống chặn + thông báo (không xóa được). |
| AC-8 | Đổi trạng thái tài khoản sv001 → "Khóa" → login sv001 báo "Tài khoản đã bị khóa". |
| AC-9 | Không 1 file trong `ui/` có `import com.mycompany.baitaplon.dao.*` (chỉ import `service.*`). |
| AC-10 | Các hành động chính (đăng nhập, thêm SV, thêm TK, đổi MK, xác nhận thanh toán) xuất hiện dòng ghi trong bảng `AuditLog`. |

**Loại: rubric (chấm điểm)**

| ID | Nội dung | Thang điểm | Ngưỡng đạt |
|----|---------|-----------|-----------|
| AC-11 | Độ rõ ràng của mô hình 3 tầng (Model / Service / UI) | 0-2 (0=DAO lẫn UI; 1=Service tồn tại nhưng UI vẫn gọi DAO; 2=UI chỉ gọi Service, Service gọi DAO, tách biệt rõ) | ≥ 2 |
| AC-12 | Mức độ đầy đủ của phân quyền (vào menu đúng role + service check) | 0-2 (0=chưa check; 1=chỉ check ở UI; 2=cả UI ẩn và Service check) | ≥ 2 |
| AC-13 | Mức độ Audit log (ghi đủ hành động quan trọng) | 0-2 (0=không; 1=ghi đăng nhập thôi; 2=ghi đủ 6 loại hành động ở FR-6) | ≥ 1 |
