# Kiến trúc 3 tầng – phiên bản hoàn chỉnh

Project được tổ chức theo 3 tầng logic:

1. **View/Presentation (`ui`)**: Java Swing, chỉ nhận thao tác và hiển thị dữ liệu.
2. **Business (`controller` + `service`)**: Controller là điểm vào từ View; Service thực hiện quy tắc nghiệp vụ như phân quyền, kiểm tra cùng ngành, giới hạn 24 TC/năm, tính học phí, đồng bộ công nợ, transaction và AuditLog.
3. **Data (`dao` + `model`)**: DAO/JDBC thực hiện SQL và transaction; Model biểu diễn dữ liệu.

Luồng chuẩn:

`View → Controller → Service → DAO/Model → MySQL`

Controller không chứa SQL. View không truy cập trực tiếp DAO. Các lớp Service được đặt trong cùng Business Layer với Controller để mô hình tổng thể vẫn là **3 tầng**, đồng thời dễ chứng minh tiêu chí M-C-V khi trình bày.

## Chức năng đăng ký theo năm học

`DangKyHocPhanPanel` cho phép chọn **Sinh viên → Năm học → Học kỳ → Học phần**. Học phần được lọc theo ngành của sinh viên. Hệ thống tính tổng tín chỉ theo năm và từ chối đăng ký nếu vượt **24 tín chỉ/năm**.

## Dữ liệu mẫu

`seed.sql` có dữ liệu nhiều khoa/ngành/lớp, nhiều năm học/học kỳ và nhiều học phần chuyên ngành. `CAP_NHAT_HOC_PHAN_NAM_HOC.sql` dùng để bổ sung học phần cho CSDL đã có dữ liệu mà không xóa dữ liệu cũ.
