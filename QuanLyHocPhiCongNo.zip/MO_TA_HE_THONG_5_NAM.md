# MÔ TẢ HỆ THỐNG QUẢN LÝ HỌC PHÍ – CÔNG NỢ TRONG 5 NĂM

## 1. Phạm vi dữ liệu
Bộ dữ liệu mô phỏng hoạt động từ năm học 2025-2026 đến 2029-2030. Mỗi bảng nghiệp vụ và danh mục có tối thiểu 1.000 bản ghi để phục vụ kiểm thử dữ liệu lớn. Các khóa ngoại được giữ nhất quán giữa Khoa → Ngành → Lớp → Sinh viên và giữa Sinh viên → Đăng ký học phần → Học phí → Công nợ → Thanh toán.

Riêng `NamHocHocPhi` được mở rộng theo cơ chế **phiên bản cấu hình học phí**: mỗi năm có nhiều bản cấu hình lịch sử. Khi tính học phí, hệ thống lấy phiên bản có `MaNam` lớn nhất của đúng năm học. Cách này vừa giữ lịch sử thay đổi đơn giá vừa đáp ứng dữ liệu kiểm thử lớn mà không làm nhân bản kết quả đăng ký học phần.

## 2. Dữ liệu danh mục
`Khoa`, `Nganh`, `Lop`, `SinhVien` mô tả cơ cấu đào tạo. 1.000 sinh viên được phân bố vào các khóa 2020-2024. `HocPhan` chứa 1.000 môn học, số tín chỉ biến thiên từ 2 đến 4. `HocKyNamHoc` chứa các đợt dữ liệu học tập trải đều trong 5 năm để kiểm thử lọc, thống kê và truy vấn lịch sử.

## 3. Nghiệp vụ đăng ký học phần
Sinh viên chọn học phần và học kỳ. Hệ thống kiểm tra trùng bộ ba `MaSV + MaHP + MaHKNH`. Khi đăng ký hợp lệ, bản ghi được lưu vào `DangKyHocPhan`. Tổng số tín chỉ của sinh viên trong học kỳ là đầu vào để tính học phí.

## 4. Nghiệp vụ tính học phí
Hệ thống xác định năm học từ `HocKyNamHoc`, lấy đơn giá tín chỉ mới nhất trong `NamHocHocPhi`, sau đó tính `TongHocPhi = TongTinChi × HocPhiMotTinChi`. Mức miễn giảm được trừ để tạo `PhaiThu`. Dữ liệu mô phỏng có cả sinh viên không miễn giảm và sinh viên được giảm 10% nhằm kiểm thử nhiều tình huống.

## 5. Nghiệp vụ công nợ
Sau khi có học phí phải thu, `CongNo` theo dõi `SoTienNo`, `SoTienDaThu`, `ConLai` và trạng thái. Ba trạng thái được mô phỏng đầy đủ: **Chưa nộp**, **Đang nợ**, **Đã nộp đủ**. Nhờ vậy màn hình lọc công nợ và báo cáo có dữ liệu ở tất cả các trường hợp.

## 6. Nghiệp vụ thanh toán
Sinh viên có thể phát sinh yêu cầu thanh toán bằng QR/chuyển khoản hoặc thanh toán theo hình thức khác. `YeuCauThanhToan` mô phỏng ba trạng thái `CHO_XAC_NHAN`, `DA_XAC_NHAN`, `TU_CHOI`. Thư ký kiểm tra yêu cầu; giao dịch hợp lệ được xác nhận và dùng để cập nhật số đã thu/còn lại. Dữ liệu `ThanhToan` lưu lịch sử tiền, ngày thanh toán, hình thức và người thu.

## 7. Người dùng và phân quyền
`TaiKhoan` có tài khoản sinh viên cùng tài khoản quản trị/thư ký. Vai trò sinh viên phục vụ tra cứu học phí, công nợ và gửi yêu cầu thanh toán; thư ký/quản trị thực hiện quản lý dữ liệu, xác nhận giao dịch và báo cáo. Dữ liệu sinh viên dùng mật khẩu demo `123456`; đây chỉ là dữ liệu kiểm thử, không phải cơ chế bảo mật cho môi trường thật.

## 8. Nhật ký hệ thống
`AuditLog` có tối thiểu 1.000 sự kiện trải trong 5 năm: đăng ký học phần, tính học phí, gửi/xác nhận thanh toán và cập nhật công nợ. Nhật ký hỗ trợ truy vết ai thực hiện, thời gian, hành động, đối tượng và chi tiết.

## 9. Chu trình hoạt động tổng thể
Luồng chính của hệ thống là: **khai báo danh mục đào tạo → tạo sinh viên/tài khoản → cấu hình năm học và đơn giá tín chỉ → sinh viên đăng ký học phần → hệ thống tính học phí → phát sinh công nợ → sinh viên thanh toán/gửi yêu cầu → thư ký xác nhận → cập nhật công nợ → thống kê, báo cáo và ghi AuditLog**.

## 10. Diễn biến dữ liệu 5 năm
Năm 2025-2026 là giai đoạn đầu của tập dữ liệu với đơn giá cơ sở thấp nhất. Các năm 2026-2027, 2027-2028, 2028-2029 và 2029-2030 tăng dần đơn giá tín chỉ trong dữ liệu mô phỏng. Mỗi năm có sinh viên, đăng ký, học phí, công nợ, thanh toán và nhật ký tương ứng, vì vậy chức năng thống kê theo `NamHoc` có thể thể hiện sự thay đổi qua thời gian thay vì chỉ có dữ liệu của một năm.

## 11. Cách nạp dữ liệu
1. Chạy `sql/quanlydaotao.sql` để tạo cấu trúc CSDL.
2. Chạy `sql/DU_LIEU_5_NAM_MOI_BANG_1000.sql` để xóa dữ liệu cũ và sinh bộ dữ liệu lớn.
3. Cuối script có truy vấn kiểm tra `COUNT(*)` cho từng bảng và truy vấn tổng hợp 5 năm.
4. Cấu hình kết nối hiện dùng MySQL database `QuanLyDaoTao`, user `root`, mật khẩu theo `database.properties`.

## 12. Mục đích kiểm thử
Bộ dữ liệu dùng để kiểm thử hiệu năng tải bảng, tìm kiếm, lọc theo năm học/trạng thái, tính học phí, cập nhật công nợ, xử lý thanh toán, báo cáo thống kê và tính toàn vẹn khóa ngoại khi dữ liệu đạt quy mô hàng nghìn dòng.


## Dữ liệu mô phỏng theo Trường Đại học Công nghệ Đông Á (EAUT)
- Danh mục khoa/nhóm đào tạo, ngành và tên học phần trong bộ dữ liệu được xây dựng theo thông tin đào tạo công khai của EAUT và các học phần phù hợp từng khối ngành.
- Ví dụ ngành: Công nghệ thông tin, Công nghệ kỹ thuật ô tô, Điện - Điện tử, Điều khiển và Tự động hóa, Kế toán, Tài chính - Ngân hàng, Quản trị kinh doanh, Marketing, Logistics, Dược học, Điều dưỡng, các ngành ngôn ngữ, Du lịch - Khách sạn...
- Học phần sử dụng tên tự nhiên như Tin học đại cương, Toán rời rạc, Cơ sở dữ liệu, Lập trình Java, Công nghệ phần mềm, Nguyên lý kế toán, Marketing căn bản, Mạch điện, Kỹ thuật ô tô, Dược lý, Điều dưỡng cơ sở, ngoại ngữ...
- Họ tên sinh viên là dữ liệu giả lập theo cấu trúc họ tên Việt Nam, không phải dữ liệu cá nhân hay danh sách sinh viên thật của EAUT.
- Script đã chuyển từ vòng lặp WHILE sang INSERT theo lô để giảm thời gian chạy và hạn chế lỗi MySQL Workbench Error 2013.
