# Chỉnh màu chữ dễ đọc

Phiên bản này tập trung tăng độ tương phản chữ trên toàn bộ giao diện.

- Các thẻ thống kê nền pastel ở **Tổng quan Tài chính** chuyển tiêu đề, số liệu, mô tả và biểu tượng sang chữ đen/xanh đen.
- Các thẻ công nợ pastel ở giao diện **Sinh viên** cũng dùng chữ đen/xanh đen.
- Các nút có nền sáng tự động dùng chữ tối để tránh chữ màu nhạt bị chìm vào nền.
- Các nút nền tối (tím/đỏ...) vẫn giữ chữ sáng khi có độ tương phản tốt.
- Các nút outline sáng như **Năm**, **Kỳ**, **MK**, **ĐX**, **Quay lại**, **Tất cả học kỳ** được ưu tiên chữ tối.
- Giữ nguyên chức năng nghiệp vụ, database và bố cục của phiên bản trước.
