USE QuanLyDaoTao;

-- Bổ sung các học phần chuyên ngành, không xóa dữ liệu cũ.
INSERT IGNORE INTO HocPhan (MaHP, TenHP, SoTinChi, HocPhiMotTinChi, MaNganh) VALUES
('HP251', 'Lập trình Java nâng cao', 3, 600000, 'N001'),
('HP252', 'Thiết kế cơ sở dữ liệu nâng cao', 3, 600000, 'N001'),
('HP253', 'Phân tích dữ liệu với Python', 3, 600000, 'N001'),
('HP254', 'Công nghệ phần mềm', 3, 580000, 'N001'),
('HP255', 'DevOps và CI/CD', 3, 620000, 'N001'),
('HP256', 'Điện toán đám mây', 3, 620000, 'N001'),
('HP257', 'Kiến trúc hệ thống phần mềm', 3, 620000, 'N001'),
('HP258', 'Kiểm thử phần mềm', 3, 580000, 'N001'),
('HP259', 'Phân tích dữ liệu lớn', 4, 620000, 'N001'),
('HP260', 'Chuyên đề phát triển phần mềm', 3, 600000, 'N001'),
('HP261', 'Mạng nơ-ron nhân tạo nâng cao', 3, 680000, 'N002'),
('HP262', 'Khai phá dữ liệu', 3, 650000, 'N002'),
('HP263', 'AI tạo sinh (Generative AI)', 3, 700000, 'N002'),
('HP264', 'MLOps và triển khai mô hình', 3, 680000, 'N002'),
('HP265', 'Hệ khuyến nghị', 3, 650000, 'N002'),
('HP266', 'AI trong xử lý ngôn ngữ', 3, 680000, 'N002'),
('HP267', 'AI trong thị giác máy tính', 3, 680000, 'N002'),
('HP268', 'Đạo đức và trách nhiệm trong AI', 2, 550000, 'N002'),
('HP269', 'Tối ưu hóa cho học máy', 3, 650000, 'N002'),
('HP270', 'Đồ án ứng dụng trí tuệ nhân tạo', 4, 700000, 'N002');
