USE QuanLyDaoTao;

-- Chỉ chạy file này trên cơ sở dữ liệu mới/trống.
INSERT IGNORE INTO Khoa (MaKhoa, TenKhoa, DienThoai, Email) VALUES
('K001', 'Khoa Công nghệ thông tin', '02431234567', 'cntt@university.edu.vn'),
('K002', 'Khoa Kinh tế', '02431234568', 'kt@university.edu.vn'),
('K003', 'Khoa Điều dưỡng', '02431234569', 'dd@university.edu.vn');

INSERT IGNORE INTO Nganh (MaNganh, TenNganh, MaKhoa) VALUES
('N001', 'Công nghệ thông tin', 'K001'),
('N002', 'Trí tuệ nhân tạo', 'K001'),
('N003', 'Kế toán', 'K002'),
('N004', 'Quản trị kinh doanh', 'K002');

INSERT IGNORE INTO Lop (MaLop, TenLop, MaNganh, KhoaHoc) VALUES
('L001', 'D20CNTT01', 'N001', 2020),
('L002', 'D20CNTT02', 'N001', 2020),
('L003', 'D20AI01', 'N002', 2020),
('L004', 'D21KT01', 'N003', 2021);

INSERT IGNORE INTO SinhVien (MaSV, HoTen, NgaySinh, GioiTinh, DiaChi, SDT, Email, MaLop) VALUES
('SV001', 'Nguyễn Văn A', '2002-05-15', 'Nam', 'Hà Nội', '0912345678', 'a@sv.edu.vn', 'L001'),
('SV002', 'Trần Thị B', '2002-08-20', 'Nữ', 'Hải Phòng', '0923456789', 'b@sv.edu.vn', 'L001'),
('SV003', 'Lê Văn C', '2002-12-10', 'Nam', 'Hải Dương', '0934567890', 'c@sv.edu.vn', 'L002'),
('SV004', 'Phạm Thị D', '2003-03-25', 'Nữ', 'Hưng Yên', '0945678901', 'd@sv.edu.vn', 'L003'),
('SV005', 'Hoàng Văn E', '2003-07-01', 'Nam', 'Hà Nội', '0956789012', 'e@sv.edu.vn', 'L004');





INSERT IGNORE INTO HocPhan (MaHP, TenHP, SoTinChi, HocPhiMotTinChi, MaNganh) VALUES
('HP001', 'Lập trình C++', 4, 550000, 'N001'),
('HP002', 'Cơ sở dữ liệu', 3, 550000, 'N001'),
('HP003', 'Toán rời rạc', 3, 450000, 'N001'),
('HP004', 'Lập trình Java', 4, 550000, 'N001'),
('HP005', 'Trí tuệ nhân tạo', 3, 600000, 'N002'),
('HP006', 'Kế toán tài chính', 3, 500000, 'N003'),
('HP007', 'Quản trị marketing', 3, 500000, 'N004');









INSERT IGNORE INTO TaiKhoan (TenDangNhap, MatKhau, VaiTro, MaSV, HoTen, TrangThai) VALUES
('thuky', '123456', 'THU_KY', NULL, 'Nguyễn Văn Thư Ký', 'Hoat dong'),
('sv001', '123456', 'SINH_VIEN', 'SV001', 'Nguyễn Văn A', 'Hoat dong'),
('sv002', '123456', 'SINH_VIEN', 'SV002', 'Trần Thị B', 'Hoat dong'),
('sv003', '123456', 'SINH_VIEN', 'SV003', 'Lê Văn C', 'Hoat dong'),
('sv004', '123456', 'SINH_VIEN', 'SV004', 'Phạm Thị D', 'Hoat dong'),
('sv005', '123456', 'SINH_VIEN', 'SV005', 'Hoàng Văn E', 'Hoat dong');
