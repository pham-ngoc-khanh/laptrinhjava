USE QuanLyDaoTao;

CREATE TABLE IF NOT EXISTS TaiKhoan (
    MaTK INT AUTO_INCREMENT PRIMARY KEY,
    TenDangNhap VARCHAR(50) UNIQUE NOT NULL,
    MatKhau VARCHAR(100) NOT NULL,
    VaiTro VARCHAR(20) NOT NULL,
    MaSV VARCHAR(10) NULL,
    HoTen VARCHAR(100) NOT NULL,
    TrangThai VARCHAR(20) DEFAULT 'Hoat dong',
    FOREIGN KEY (MaSV) REFERENCES SinhVien(MaSV)
);

INSERT IGNORE INTO TaiKhoan (TenDangNhap, MatKhau, VaiTro, MaSV, HoTen) VALUES
('thuky', '123456', 'THU_KY', NULL, 'Nguyen Van Thu Ky'),
('sv001', '123456', 'SINH_VIEN', 'SV001', 'Nguyen Van A'),
('sv002', '123456', 'SINH_VIEN', 'SV002', 'Tran Thi B'),
('sv003', '123456', 'SINH_VIEN', 'SV003', 'Le Van C'),
('sv004', '123456', 'SINH_VIEN', 'SV004', 'Pham Thi D'),
('sv005', '123456', 'SINH_VIEN', 'SV005', 'Hoang Van E');
