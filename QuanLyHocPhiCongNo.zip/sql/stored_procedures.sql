USE QuanLyDaoTao;

DROP PROCEDURE IF EXISTS sp_TraCuuCongNo;
DELIMITER $$
CREATE PROCEDURE sp_TraCuuCongNo(IN p_MaSV VARCHAR(10), IN p_MaHKNH VARCHAR(10))
BEGIN
    SELECT cn.*, sv.HoTen, hk.HocKy, hk.NamHoc
    FROM CongNo cn
    JOIN SinhVien sv ON sv.MaSV = cn.MaSV
    JOIN HocKyNamHoc hk ON hk.MaHKNH = cn.MaHKNH
    WHERE (p_MaSV IS NULL OR p_MaSV = '' OR cn.MaSV = p_MaSV)
      AND (p_MaHKNH IS NULL OR p_MaHKNH = '' OR cn.MaHKNH = p_MaHKNH)
    ORDER BY hk.NamHoc DESC, hk.HocKy DESC, sv.MaSV;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS sp_ThongKeDoanhThuTheoThang;
DELIMITER $$
CREATE PROCEDURE sp_ThongKeDoanhThuTheoThang(IN p_NamHoc VARCHAR(20))
BEGIN
    SELECT DATE_FORMAT(tt.NgayThanhToan, '%Y-%m') AS Thang,
           SUM(tt.SoTien) AS DoanhThu,
           COUNT(*) AS SoGiaoDich
    FROM ThanhToan tt
    JOIN HocKyNamHoc hk ON hk.MaHKNH = tt.MaHKNH
    WHERE p_NamHoc IS NULL OR p_NamHoc = '' OR hk.NamHoc = p_NamHoc
    GROUP BY DATE_FORMAT(tt.NgayThanhToan, '%Y-%m')
    ORDER BY Thang;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS sp_ThongKeTinChiSinhVien;
DELIMITER $$
CREATE PROCEDURE sp_ThongKeTinChiSinhVien(IN p_MaSV VARCHAR(10), IN p_NamHoc VARCHAR(20))
BEGIN
    SELECT hk.NamHoc, hk.HocKy,
           COALESCE(SUM(hp.SoTinChi),0) AS TongTinChi
    FROM DangKyHocPhan dk
    JOIN HocPhan hp ON hp.MaHP = dk.MaHP
    JOIN HocKyNamHoc hk ON hk.MaHKNH = dk.MaHKNH
    WHERE dk.MaSV = p_MaSV
      AND (p_NamHoc IS NULL OR p_NamHoc = '' OR hk.NamHoc = p_NamHoc)
    GROUP BY hk.NamHoc, hk.HocKy
    ORDER BY hk.NamHoc, hk.HocKy;
END$$
DELIMITER ;
