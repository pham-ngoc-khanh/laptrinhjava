USE QuanLyDaoTao;

-- DỮ LIỆU MÔ PHỎNG EAUT 5 NĂM 2025-2026 .. 2029-2030
-- Tên khoa/ngành/học phần tham chiếu thông tin công khai của Trường ĐH Công nghệ Đông Á (EAUT).
-- Tên sinh viên là DỮ LIỆU GIẢ LẬP, không phải danh sách sinh viên thật.
-- Tối ưu INSERT ... SELECT theo lô để tránh Error 2013 do vòng WHILE kéo dài.

SET FOREIGN_KEY_CHECKS=0;
TRUNCATE TABLE AuditLog; TRUNCATE TABLE YeuCauThanhToan; TRUNCATE TABLE ThanhToan;
TRUNCATE TABLE CongNo; TRUNCATE TABLE HocPhi; TRUNCATE TABLE DangKyHocPhan;
TRUNCATE TABLE TaiKhoan; TRUNCATE TABLE SinhVien; TRUNCATE TABLE HocPhan;
TRUNCATE TABLE NamHocHocPhi; TRUNCATE TABLE HocKyNamHoc; TRUNCATE TABLE Lop;
TRUNCATE TABLE Nganh; TRUNCATE TABLE Khoa;
SET FOREIGN_KEY_CHECKS=1;

DROP TEMPORARY TABLE IF EXISTS SoThuTu;
CREATE TEMPORARY TABLE SoThuTu (n INT PRIMARY KEY);
INSERT INTO SoThuTu(n)
SELECT a.d + b.d*10 + c.d*100 + 1
FROM (SELECT 0 d UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) a
CROSS JOIN (SELECT 0 d UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) b
CROSS JOIN (SELECT 0 d UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9) c;

-- 1.000 dòng khoa/đơn vị mô phỏng, luân phiên các nhóm khoa đào tạo phù hợp EAUT.
INSERT INTO Khoa(MaKhoa,TenKhoa,DienThoai,Email)
SELECT CONCAT('K',LPAD(n,4,'0')), CASE MOD(n-1,12) WHEN 0 THEN 'Khoa Công nghệ thông tin' WHEN 1 THEN 'Khoa Cơ khí' WHEN 2 THEN 'Khoa Điện - Điện tử' WHEN 3 THEN 'Khoa Điều khiển và Tự động hóa' WHEN 4 THEN 'Khoa Kinh tế - Quản trị' WHEN 5 THEN 'Khoa Tài chính - Kế toán' WHEN 6 THEN 'Khoa Du lịch - Khách sạn' WHEN 7 THEN 'Khoa Ngoại ngữ' WHEN 8 THEN 'Khoa Dược' WHEN 9 THEN 'Khoa Điều dưỡng' WHEN 10 THEN 'Khoa Xây dựng - Kiến trúc' WHEN 11 THEN 'Khoa Công nghệ thực phẩm' END, CONCAT('024',LPAD(n,8,'0')), CONCAT('khoa',n,'@eaut-demo.edu.vn') FROM SoThuTu;

-- 1.000 dòng ngành: tên ngành lấy theo danh mục đào tạo EAUT, lặp theo bộ dữ liệu kiểm thử.
INSERT INTO Nganh(MaNganh,TenNganh,MaKhoa)
SELECT CONCAT('N',LPAD(n,4,'0')), CASE MOD(n-1,30) WHEN 0 THEN 'Công nghệ thông tin' WHEN 1 THEN 'Thiết kế đồ họa số' WHEN 2 THEN 'Trí tuệ nhân tạo ứng dụng' WHEN 3 THEN 'Công nghệ kỹ thuật điện, điện tử' WHEN 4 THEN 'Công nghệ kỹ thuật bán dẫn' WHEN 5 THEN 'Công nghệ kỹ thuật điều khiển và tự động hóa' WHEN 6 THEN 'Công nghệ kỹ thuật ô tô' WHEN 7 THEN 'Công nghệ kỹ thuật nhiệt' WHEN 8 THEN 'Công nghệ chế tạo máy' WHEN 9 THEN 'Cơ điện tử' WHEN 10 THEN 'Kỹ thuật xây dựng' WHEN 11 THEN 'Kiến trúc' WHEN 12 THEN 'Kiến trúc nội thất' WHEN 13 THEN 'Công nghệ thực phẩm' WHEN 14 THEN 'Kế toán' WHEN 15 THEN 'Tài chính - Ngân hàng' WHEN 16 THEN 'Công nghệ tài chính' WHEN 17 THEN 'Quản trị kinh doanh' WHEN 18 THEN 'Marketing' WHEN 19 THEN 'Logistics và Quản lý chuỗi cung ứng' WHEN 20 THEN 'Quản trị nhân lực' WHEN 21 THEN 'Luật' WHEN 22 THEN 'Dược học' WHEN 23 THEN 'Điều dưỡng' WHEN 24 THEN 'Ngôn ngữ Anh' WHEN 25 THEN 'Ngôn ngữ Trung Quốc' WHEN 26 THEN 'Ngôn ngữ Nhật' WHEN 27 THEN 'Ngôn ngữ Hàn Quốc' WHEN 28 THEN 'Quản trị dịch vụ du lịch và lữ hành' WHEN 29 THEN 'Quản trị khách sạn' END, CONCAT('K',LPAD(n,4,'0')) FROM SoThuTu;

-- Lớp trải đều 5 khóa 2025..2029.
INSERT INTO Lop(MaLop,TenLop,MaNganh,KhoaHoc)
SELECT CONCAT('L',LPAD(n,4,'0')), CONCAT('D',25+MOD(n-1,5),'_',LPAD(n,4,'0')), CONCAT('N',LPAD(n,4,'0')), 2025+MOD(n-1,5) FROM SoThuTu;

-- 1.000 sinh viên GIẢ LẬP với họ tên Việt Nam tự nhiên.
INSERT INTO SinhVien(MaSV,HoTen,NgaySinh,GioiTinh,DiaChi,SDT,Email,MaLop)
SELECT CONCAT('SV',LPAD(n,6,'0')), CONCAT(CASE MOD(FLOOR((n-1)/360),15) WHEN 0 THEN 'Nguyễn' WHEN 1 THEN 'Trần' WHEN 2 THEN 'Lê' WHEN 3 THEN 'Phạm' WHEN 4 THEN 'Hoàng' WHEN 5 THEN 'Huỳnh' WHEN 6 THEN 'Phan' WHEN 7 THEN 'Vũ' WHEN 8 THEN 'Võ' WHEN 9 THEN 'Đặng' WHEN 10 THEN 'Bùi' WHEN 11 THEN 'Đỗ' WHEN 12 THEN 'Hồ' WHEN 13 THEN 'Ngô' WHEN 14 THEN 'Dương' END,' ',CASE MOD(FLOOR((n-1)/30),12) WHEN 0 THEN 'Văn' WHEN 1 THEN 'Đức' WHEN 2 THEN 'Minh' WHEN 3 THEN 'Quang' WHEN 4 THEN 'Hoàng' WHEN 5 THEN 'Hữu' WHEN 6 THEN 'Đình' WHEN 7 THEN 'Ngọc' WHEN 8 THEN 'Thị' WHEN 9 THEN 'Thu' WHEN 10 THEN 'Thanh' WHEN 11 THEN 'Phương' END,' ',CASE MOD(n-1,30) WHEN 0 THEN 'Minh' WHEN 1 THEN 'Đức' WHEN 2 THEN 'Quang' WHEN 3 THEN 'Hoàng' WHEN 4 THEN 'Tuấn' WHEN 5 THEN 'Anh' WHEN 6 THEN 'Khánh' WHEN 7 THEN 'Huy' WHEN 8 THEN 'Nam' WHEN 9 THEN 'Long' WHEN 10 THEN 'Thành' WHEN 11 THEN 'Duy' WHEN 12 THEN 'Hải' WHEN 13 THEN 'Phúc' WHEN 14 THEN 'Tùng' WHEN 15 THEN 'Trang' WHEN 16 THEN 'Linh' WHEN 17 THEN 'Hương' WHEN 18 THEN 'Ngọc' WHEN 19 THEN 'Mai' WHEN 20 THEN 'Thảo' WHEN 21 THEN 'Lan' WHEN 22 THEN 'Thu' WHEN 23 THEN 'Phương' WHEN 24 THEN 'Yến' WHEN 25 THEN 'Vy' WHEN 26 THEN 'Nhung' WHEN 27 THEN 'Hà' WHEN 28 THEN 'Hiền' WHEN 29 THEN 'Quỳnh' END),
       DATE_ADD('2002-01-01',INTERVAL MOD(n*17,1460) DAY), IF(MOD(n,2)=0,'Nữ','Nam'),
       CONCAT('Hà Nội - địa chỉ mô phỏng ',n), CONCAT('09',LPAD(MOD(n*7919,100000000),8,'0')),
       CONCAT('sv',LPAD(n,6,'0'),'@eaut-demo.edu.vn'), CONCAT('L',LPAD(n,4,'0'))
FROM SoThuTu;

-- 1.000 học kỳ/đợt dữ liệu, 200 dòng mỗi năm học.
INSERT INTO HocKyNamHoc(MaHKNH,HocKy,NamHoc,NgayBatDau,NgayKetThuc)
SELECT CONCAT('HK',LPAD(n,6,'0')),1+MOD(n-1,2),CONCAT(2025+FLOOR((n-1)/200),'-',2026+FLOOR((n-1)/200)),
       DATE_ADD(CONCAT(2025+FLOOR((n-1)/200),'-08-01'),INTERVAL MOD(n-1,200) DAY),
       DATE_ADD(DATE_ADD(CONCAT(2025+FLOOR((n-1)/200),'-08-01'),INTERVAL MOD(n-1,200) DAY),INTERVAL 120 DAY)
FROM SoThuTu;

INSERT INTO NamHocHocPhi(MaNam,NamHoc,HocPhiMotTinChi,GhiChu)
SELECT CONCAT('M',LPAD(n,6,'0')),CONCAT(2025+FLOOR((n-1)/200),'-',2026+FLOOR((n-1)/200)),
       450000+FLOOR((n-1)/200)*50000+MOD(n-1,200)*100,
       CONCAT('Cấu hình mô phỏng EAUT - phiên bản ',MOD(n-1,200)+1)
FROM SoThuTu;

-- Học phần có tên thực tế/phù hợp chương trình đại học; lặp để đạt tải 1.000 bản ghi.
INSERT INTO HocPhan(MaHP,TenHP,SoTinChi,HocPhiMotTinChi,MaNganh)
SELECT CONCAT('HP',LPAD(n,6,'0')), CASE MOD(n-1,45) WHEN 0 THEN 'Tin học đại cương' WHEN 1 THEN 'Nhập môn ngành' WHEN 2 THEN 'Toán rời rạc' WHEN 3 THEN 'Cơ sở dữ liệu' WHEN 4 THEN 'Lập trình Java' WHEN 5 THEN 'Công nghệ phần mềm' WHEN 6 THEN 'Mạng máy tính' WHEN 7 THEN 'Hệ quản trị cơ sở dữ liệu' WHEN 8 THEN 'Trí tuệ nhân tạo' WHEN 9 THEN 'An toàn thông tin' WHEN 10 THEN 'Nguyên lý kế toán' WHEN 11 THEN 'Kế toán tài chính' WHEN 12 THEN 'Tài chính doanh nghiệp' WHEN 13 THEN 'Marketing căn bản' WHEN 14 THEN 'Quản trị học' WHEN 15 THEN 'Quản trị nguồn nhân lực' WHEN 16 THEN 'Logistics căn bản' WHEN 17 THEN 'Quản trị chuỗi cung ứng' WHEN 18 THEN 'Kinh tế vi mô' WHEN 19 THEN 'Kinh tế vĩ mô' WHEN 20 THEN 'Mạch điện' WHEN 21 THEN 'Điện tử cơ bản' WHEN 22 THEN 'Vi điều khiển' WHEN 23 THEN 'Điều khiển tự động' WHEN 24 THEN 'Kỹ thuật ô tô' WHEN 25 THEN 'Động cơ đốt trong' WHEN 26 THEN 'Cơ học kỹ thuật' WHEN 27 THEN 'Công nghệ chế tạo máy' WHEN 28 THEN 'Kỹ thuật nhiệt' WHEN 29 THEN 'Nhiệt lạnh' WHEN 30 THEN 'Hóa sinh' WHEN 31 THEN 'Công nghệ thực phẩm' WHEN 32 THEN 'Dược lý' WHEN 33 THEN 'Hóa dược' WHEN 34 THEN 'Điều dưỡng cơ sở' WHEN 35 THEN 'Giải phẫu sinh lý' WHEN 36 THEN 'Tiếng Anh 1' WHEN 37 THEN 'Tiếng Trung 1' WHEN 38 THEN 'Tiếng Nhật 1' WHEN 39 THEN 'Tiếng Hàn 1' WHEN 40 THEN 'Quản trị khách sạn' WHEN 41 THEN 'Nghiệp vụ lữ hành' WHEN 42 THEN 'Pháp luật đại cương' WHEN 43 THEN 'Giải tích' WHEN 44 THEN 'Đại số tuyến tính' END, 2+MOD(n,3), 450000+MOD(n-1,5)*50000, CONCAT('N',LPAD(n,4,'0')) FROM SoThuTu;

INSERT INTO TaiKhoan(TenDangNhap,MatKhau,VaiTro,MaSV,HoTen,TrangThai) VALUES
('admin','123456','ADMIN',NULL,'Quản trị hệ thống','Hoat dong'),
('thuky','123456','THU_KY',NULL,'Thư ký đào tạo','Hoat dong');
INSERT INTO TaiKhoan(TenDangNhap,MatKhau,VaiTro,MaSV,HoTen,TrangThai)
SELECT CONCAT('sv',LPAD(n,6,'0')),'123456','SINH_VIEN',CONCAT('SV',LPAD(n,6,'0')),
       CONCAT(CASE MOD(FLOOR((n-1)/360),15) WHEN 0 THEN 'Nguyễn' WHEN 1 THEN 'Trần' WHEN 2 THEN 'Lê' WHEN 3 THEN 'Phạm' WHEN 4 THEN 'Hoàng' WHEN 5 THEN 'Huỳnh' WHEN 6 THEN 'Phan' WHEN 7 THEN 'Vũ' WHEN 8 THEN 'Võ' WHEN 9 THEN 'Đặng' WHEN 10 THEN 'Bùi' WHEN 11 THEN 'Đỗ' WHEN 12 THEN 'Hồ' WHEN 13 THEN 'Ngô' WHEN 14 THEN 'Dương' END,' ',CASE MOD(FLOOR((n-1)/30),12) WHEN 0 THEN 'Văn' WHEN 1 THEN 'Đức' WHEN 2 THEN 'Minh' WHEN 3 THEN 'Quang' WHEN 4 THEN 'Hoàng' WHEN 5 THEN 'Hữu' WHEN 6 THEN 'Đình' WHEN 7 THEN 'Ngọc' WHEN 8 THEN 'Thị' WHEN 9 THEN 'Thu' WHEN 10 THEN 'Thanh' WHEN 11 THEN 'Phương' END,' ',CASE MOD(n-1,30) WHEN 0 THEN 'Minh' WHEN 1 THEN 'Đức' WHEN 2 THEN 'Quang' WHEN 3 THEN 'Hoàng' WHEN 4 THEN 'Tuấn' WHEN 5 THEN 'Anh' WHEN 6 THEN 'Khánh' WHEN 7 THEN 'Huy' WHEN 8 THEN 'Nam' WHEN 9 THEN 'Long' WHEN 10 THEN 'Thành' WHEN 11 THEN 'Duy' WHEN 12 THEN 'Hải' WHEN 13 THEN 'Phúc' WHEN 14 THEN 'Tùng' WHEN 15 THEN 'Trang' WHEN 16 THEN 'Linh' WHEN 17 THEN 'Hương' WHEN 18 THEN 'Ngọc' WHEN 19 THEN 'Mai' WHEN 20 THEN 'Thảo' WHEN 21 THEN 'Lan' WHEN 22 THEN 'Thu' WHEN 23 THEN 'Phương' WHEN 24 THEN 'Yến' WHEN 25 THEN 'Vy' WHEN 26 THEN 'Nhung' WHEN 27 THEN 'Hà' WHEN 28 THEN 'Hiền' WHEN 29 THEN 'Quỳnh' END),'Hoat dong' FROM SoThuTu;

INSERT INTO DangKyHocPhan(MaSV,MaHP,MaHKNH,NgayDangKy)
SELECT CONCAT('SV',LPAD(n,6,'0')),CONCAT('HP',LPAD(n,6,'0')),CONCAT('HK',LPAD(n,6,'0')),
       DATE_ADD(CONCAT(2025+FLOOR((n-1)/200),'-08-01'),INTERVAL MOD(n-1,200) DAY) FROM SoThuTu;

INSERT INTO HocPhi(MaSV,MaHKNH,TongTinChi,TongHocPhi,MienGiam,PhaiThu,NgayTinh)
SELECT CONCAT('SV',LPAD(n,6,'0')),CONCAT('HK',LPAD(n,6,'0')),2+MOD(n,3),
       (450000+FLOOR((n-1)/200)*50000+19900)*(2+MOD(n,3)),
       IF(MOD(n,10)=0,ROUND((450000+FLOOR((n-1)/200)*50000+19900)*(2+MOD(n,3))*0.10,0),0),
       (450000+FLOOR((n-1)/200)*50000+19900)*(2+MOD(n,3))-IF(MOD(n,10)=0,ROUND((450000+FLOOR((n-1)/200)*50000+19900)*(2+MOD(n,3))*0.10,0),0),
       DATE_ADD(CONCAT(2025+FLOOR((n-1)/200),'-08-03'),INTERVAL MOD(n-1,200) DAY) FROM SoThuTu;

INSERT INTO CongNo(MaSV,MaHKNH,SoTienNo,SoTienDaThu,ConLai,TrangThai,NgayCapNhat)
SELECT hp.MaSV,hp.MaHKNH,hp.PhaiThu,
       CASE MOD(s.n,3) WHEN 0 THEN hp.PhaiThu WHEN 1 THEN 0 ELSE ROUND(hp.PhaiThu/2,0) END,
       hp.PhaiThu-CASE MOD(s.n,3) WHEN 0 THEN hp.PhaiThu WHEN 1 THEN 0 ELSE ROUND(hp.PhaiThu/2,0) END,
       CASE MOD(s.n,3) WHEN 0 THEN 'Đã nộp đủ' WHEN 1 THEN 'Chưa nộp' ELSE 'Đang nợ' END,
       DATE_ADD(hp.NgayTinh,INTERVAL 30 DAY)
FROM HocPhi hp JOIN SoThuTu s ON hp.MaSV=CONCAT('SV',LPAD(s.n,6,'0'));

INSERT INTO ThanhToan(MaSV,MaHKNH,SoTien,HinhThucThanhToan,NgayThanhToan,NguoiThu,GhiChu)
SELECT cn.MaSV,cn.MaHKNH,GREATEST(cn.SoTienDaThu,100000),
       CASE MOD(s.n,3) WHEN 0 THEN 'Chuyển khoản' WHEN 1 THEN 'Tiền mặt' ELSE 'QR' END,
       cn.NgayCapNhat,'Thư ký đào tạo','Giao dịch mô phỏng dữ liệu EAUT 5 năm'
FROM CongNo cn JOIN SoThuTu s ON cn.MaSV=CONCAT('SV',LPAD(s.n,6,'0'));

INSERT INTO YeuCauThanhToan(MaSV,MaHKNH,SoTien,HinhThucThanhToan,NoiDung,NgayGui,TrangThai,NguoiXuLy,NgayXuLy,LyDoTuChoi)
SELECT cn.MaSV,cn.MaHKNH,GREATEST(cn.SoTienDaThu,100000),'QR',CONCAT('Yêu cầu thanh toán học phí #',s.n),
       TIMESTAMP(cn.NgayCapNhat,'09:00:00'),
       CASE MOD(s.n,10) WHEN 0 THEN 'CHO_XAC_NHAN' WHEN 1 THEN 'TU_CHOI' ELSE 'DA_XAC_NHAN' END,
       IF(MOD(s.n,10)=0,NULL,'Thư ký đào tạo'),IF(MOD(s.n,10)=0,NULL,TIMESTAMP(cn.NgayCapNhat,'10:00:00')),
       IF(MOD(s.n,10)=1,'Thông tin giao dịch không hợp lệ',NULL)
FROM CongNo cn JOIN SoThuTu s ON cn.MaSV=CONCAT('SV',LPAD(s.n,6,'0'));

INSERT INTO AuditLog(ThoiGian,MaTK,TenDangNhap,HanhDong,DoiTuong,ChiTiet,NguoiThucHien)
SELECT TIMESTAMP(DATE_ADD(CONCAT(2025+FLOOR((n-1)/200),'-09-01'),INTERVAL MOD(n-1,200) DAY),'08:00:00'),
       2+n,CONCAT('sv',LPAD(n,6,'0')),
       CASE MOD(n,5) WHEN 0 THEN 'DANG_KY_HP' WHEN 1 THEN 'TINH_HOC_PHI' WHEN 2 THEN 'GUI_THANH_TOAN' WHEN 3 THEN 'XAC_NHAN_THANH_TOAN' ELSE 'CAP_NHAT_CONG_NO' END,
       CASE MOD(n,4) WHEN 0 THEN 'DangKyHocPhan' WHEN 1 THEN 'HocPhi' WHEN 2 THEN 'ThanhToan' ELSE 'CongNo' END,
       CONCAT('Nhật ký nghiệp vụ mô phỏng EAUT #',n),'Hệ thống' FROM SoThuTu;

DROP TEMPORARY TABLE SoThuTu;

-- Kiểm tra số lượng: tất cả phải >= 1000
SELECT 'Khoa' Bang, COUNT(*) SoBanGhi FROM Khoa UNION ALL
SELECT 'Nganh',COUNT(*) FROM Nganh UNION ALL SELECT 'Lop',COUNT(*) FROM Lop UNION ALL
SELECT 'SinhVien',COUNT(*) FROM SinhVien UNION ALL SELECT 'HocKyNamHoc',COUNT(*) FROM HocKyNamHoc UNION ALL
SELECT 'NamHocHocPhi',COUNT(*) FROM NamHocHocPhi UNION ALL SELECT 'HocPhan',COUNT(*) FROM HocPhan UNION ALL
SELECT 'DangKyHocPhan',COUNT(*) FROM DangKyHocPhan UNION ALL SELECT 'HocPhi',COUNT(*) FROM HocPhi UNION ALL
SELECT 'CongNo',COUNT(*) FROM CongNo UNION ALL SELECT 'ThanhToan',COUNT(*) FROM ThanhToan UNION ALL
SELECT 'YeuCauThanhToan',COUNT(*) FROM YeuCauThanhToan UNION ALL SELECT 'TaiKhoan',COUNT(*) FROM TaiKhoan UNION ALL
SELECT 'AuditLog',COUNT(*) FROM AuditLog;

SELECT hk.NamHoc,COUNT(DISTINCT hp.MaSV) SoSinhVien,COUNT(DISTINCT dk.MaDKHP) SoLuotDangKy,
       SUM(hp.TongTinChi) TongTinChi,SUM(hp.PhaiThu) TongPhaiThu,SUM(cn.SoTienDaThu) TongDaThu,SUM(cn.ConLai) TongCongNo
FROM HocPhi hp JOIN HocKyNamHoc hk ON hk.MaHKNH=hp.MaHKNH
JOIN CongNo cn ON cn.MaSV=hp.MaSV AND cn.MaHKNH=hp.MaHKNH
LEFT JOIN DangKyHocPhan dk ON dk.MaSV=hp.MaSV AND dk.MaHKNH=hp.MaHKNH
GROUP BY hk.NamHoc ORDER BY hk.NamHoc;
