# Cập nhật giao diện chống tràn / lấn chữ

Bản này đã chỉnh lại toàn bộ giao diện Java Swing theo hướng responsive:

- Các trang chính có cuộn dọc khi chiều cao màn hình không đủ.
- Các nhóm nút/bộ lọc tự xuống dòng thay vì chồng lấn nhau.
- Bảng dữ liệu tự tính độ rộng cột và có cuộn ngang khi nhiều cột.
- Nút tự tính kích thước theo nội dung; khi không đủ chỗ sẽ hiển thị dấu `...` thay vì vẽ tràn.
- Dashboard và các thẻ thống kê tự đổi số cột theo chiều rộng cửa sổ.
- Thanh tiêu đề, thanh trạng thái và menu trái đã giới hạn kích thước để tránh đè chữ.
- Trang thanh toán tự chuyển từ 2 cột sang xếp dọc khi cửa sổ hẹp.
- Trang thanh toán hỗ trợ QR VietQR/NAPAS 247 và tiền mặt; QR dùng đúng ảnh được cung cấp.
- Trang chi tiết sinh viên, học phí, công nợ, học kỳ, học phần, đăng ký học phần, báo cáo và thanh toán đều đã chỉnh bố cục để không lấn chiếm.

## Chạy nhanh

Có thể chạy file `dist/QuanLyHocPhiCongNo.jar` bằng Java 21 hoặc mở project bằng NetBeans.
