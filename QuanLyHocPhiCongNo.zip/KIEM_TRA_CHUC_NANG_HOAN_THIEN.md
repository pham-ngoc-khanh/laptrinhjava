# KIỂM TRA CHỨC NĂNG – QUẢN LÝ HỌC PHÍ VÀ CÔNG NỢ SINH VIÊN

## 1. Phạm vi đã rà soát

Đề tài: **Xây dựng ứng dụng desktop quản lý học phí và công nợ sinh viên sử dụng Java Swing, JDBC và MySQL**.

Bản này đã rà soát luồng nghiệp vụ từ đăng nhập → sinh viên/học phần/học kỳ → đăng ký học phần → tính học phí → sinh công nợ → thanh toán → xác nhận → báo cáo.

## 2. Ma trận chức năng

| Nhóm | Chức năng | Trạng thái |
|---|---|---|
| Tài khoản | Đăng nhập phân quyền Sinh viên / Thư ký | Có |
| Tài khoản | Đổi mật khẩu, đăng xuất | Có |
| Sinh viên | Danh sách, tìm kiếm, thêm, sửa, xóa có kiểm tra dữ liệu tài chính | Có |
| Sinh viên | Tự tạo tài khoản sinh viên khi thêm mới | Có |
| Sinh viên | Xem chi tiết học phí, công nợ, lịch sử thanh toán | Có |
| Học phần | Thêm, sửa, xóa; chặn xóa khi đã có đăng ký | Có |
| Học kỳ | Thêm, sửa, xóa; kiểm tra dữ liệu phụ thuộc | Có |
| Đăng ký HP | Đăng ký / hủy đăng ký / tìm kiếm / xuất CSV | Có |
| Đăng ký HP | Tự đồng bộ học phí và công nợ | Có |
| Học phí | Tính tổng tín chỉ, tổng học phí, miễn giảm, phải thu | Có |
| Công nợ | Theo dõi phải thu, đã thu, còn lại, trạng thái | Có |
| Công nợ | Tìm kiếm/lọc theo trạng thái | Có |
| Thanh toán SV | QR VietQR/NAPAS + Tiền mặt | Có |
| Thanh toán SV | Gửi thông báo đã thanh toán cho Thư ký | Có |
| Thanh toán SV | Hủy yêu cầu còn đang chờ | Có |
| Thanh toán SV | Xem trạng thái chờ / hoàn tất / từ chối / đã hủy | Có |
| Thanh toán SV | Xem ngày xử lý, người xử lý, lý do từ chối | Có |
| Thanh toán SV | Nút gửi xác nhận được ghim cố định, không rơi khỏi màn hình | Đã sửa |
| Thư ký | Danh sách yêu cầu chờ xác nhận | Có |
| Thư ký | Tìm nhanh theo MSSV / họ tên | Đã bổ sung |
| Thư ký | Nút **ĐÃ NHẬN TIỀN & HOÀN TẤT** luôn ở phía trên bảng | Đã sửa |
| Thư ký | Xác nhận: tạo phiếu thu + cập nhật công nợ + hoàn tất cho SV | Có |
| Thư ký | Từ chối kèm lý do | Có |
| Thư ký | Ghi nhận thanh toán trực tiếp | Có |
| Thanh toán | Lịch sử thanh toán chính thức + xuất CSV | Có |
| Báo cáo | Tổng hợp tài chính theo khoa/năm học, doanh thu theo tháng | Có |
| Báo cáo | Xuất báo cáo | Có |
| Giao diện | Bảng tự cuộn ngang, không ép cột đè chữ | Có |
| Giao diện | Trang dài cuộn dọc | Có |
| Giao diện | Form/thẻ thống kê tự đổi số cột theo chiều rộng | Có |
| Giao diện | Nhóm nút tự xuống dòng khi cửa sổ hẹp | Có |
| Giao diện | Nút tự bảo vệ kích thước theo nội dung | Có |
| Giao diện | Giảm icon/emoji trên nút để tránh ô vuông thiếu font | Đã sửa |

## 3. Các lỗi nghiệp vụ quan trọng đã khắc phục

1. **Nút gửi thanh toán của sinh viên bị nằm dưới màn hình**: nội dung thanh toán cuộn riêng; thanh hành động được ghim cố định phía dưới tab.
2. **Thư ký không thấy nút xác nhận**: nút `ĐÃ NHẬN TIỀN & HOÀN TẤT` được đưa lên trên bảng chờ xác nhận.
3. **Sinh viên không biết đã hoàn tất chưa**: thanh trạng thái gần nhất hiển thị ngay trên màn Thanh toán; lịch sử yêu cầu có ngày xử lý, người xử lý và trạng thái `Đã nhận tiền - Hoàn tất`.
4. **Sinh viên mở nhầm học kỳ không có công nợ**: mặc định ưu tiên học kỳ còn nợ.
5. **Gửi nhiều yêu cầu vượt số còn nợ**: hệ thống trừ tổng yêu cầu đang chờ khỏi số tiền còn được phép gửi.
6. **Ghi nhận trực tiếp trùng với yêu cầu đang chờ**: chặn ghi nhận trực tiếp nếu cùng sinh viên/học kỳ còn yêu cầu chờ xác nhận.
7. **Thanh toán vượt công nợ**: chặn ở DAO trong transaction.
8. **Sửa học phí/miễn giảm xuống thấp hơn số tiền đã thu**: chặn để tránh công nợ âm/sai số liệu.
9. **Hủy đăng ký học phần khi đã phát sinh thanh toán**: chặn để bảo toàn chứng từ.
10. **Hủy đăng ký khi đang có yêu cầu thanh toán chờ**: chặn cho đến khi xử lý/hủy yêu cầu.
11. **Xóa sinh viên làm mất chứng từ đã thu**: bản mới chặn xóa sinh viên đã có lịch sử thanh toán; chặn khi còn yêu cầu chờ.
12. **Xóa học kỳ còn dữ liệu thanh toán/yêu cầu**: kiểm tra đầy đủ bảng phụ thuộc.

## 4. Luồng thanh toán chuẩn

### Sinh viên
1. Mở **Thanh toán học phí**.
2. Hệ thống ưu tiên chọn học kỳ đang còn nợ.
3. Chọn **Chuyển khoản (QR)** hoặc **Tiền mặt**.
4. Nhập số tiền và ghi chú.
5. Bấm **GỬI XÁC NHẬN ĐÃ THANH TOÁN** (nút luôn nằm ở thanh cố định dưới màn hình).
6. Theo dõi ngay dòng **Trạng thái gần nhất** hoặc tab **Yêu cầu của tôi**.

### Thư ký
1. Mở **Thanh toán & xác nhận → Chờ xác nhận**.
2. Có thể tìm theo MSSV/họ tên.
3. Chọn đúng yêu cầu.
4. Nếu đã đối soát được tiền, bấm **ĐÃ NHẬN TIỀN & HOÀN TẤT**.
5. Hệ thống chạy transaction: cập nhật công nợ → tạo ThanhToan → đổi yêu cầu sang `DA_XAC_NHAN`.
6. Nếu chưa nhận được tiền, bấm **Từ chối** và nhập lý do.

## 5. Các tình huống cần test trên máy có MySQL

- Thanh toán QR toàn bộ công nợ.
- Thanh toán QR một phần.
- Thanh toán tiền mặt một phần/toàn bộ.
- Thư ký từ chối yêu cầu và sinh viên xem được lý do.
- Sinh viên hủy yêu cầu đang chờ.
- Gửi số tiền lớn hơn công nợ (phải bị chặn).
- Gửi hai yêu cầu có tổng vượt công nợ (phải bị chặn).
- Ghi nhận trực tiếp khi đang có yêu cầu chờ (phải bị chặn).
- Xác nhận xong: kiểm tra đồng thời bảng `YeuCauThanhToan`, `ThanhToan`, `CongNo`.
- Thử hủy đăng ký sau khi đã thanh toán (phải bị chặn).
- Thử xóa sinh viên đã có chứng từ (phải bị chặn).
- Thu nhỏ cửa sổ ở nhiều kích thước: nút thao tác phải vẫn nhìn thấy hoặc tự xuống dòng; bảng dùng cuộn ngang.

## 6. Kết quả kiểm tra kỹ thuật trong môi trường đóng gói

- Toàn bộ mã nguồn đã biên dịch bằng **JDK 21**.
- Kiểm tra `javac -Xlint:all`: không có lỗi biên dịch; chỉ còn các cảnh báo Swing/Serializable không ảnh hưởng chạy chương trình.
- JAR đóng gói có MySQL Connector/J và main class chạy ứng dụng.
- Môi trường đóng gói không có MySQL Server nên phần test end-to-end với database thật cần chạy trên máy đã cài MySQL của người dùng.

## 7. Chức năng mở rộng (không bắt buộc với đề tài)

Nếu triển khai thực tế quy mô lớn có thể bổ sung: quản lý Khoa/Ngành/Lớp bằng giao diện riêng, reset mật khẩu, phân quyền nhiều cấp hơn, in biên lai theo mẫu PDF, sao lưu/phục hồi CSDL và nhật ký thao tác. Các mục này không phải điều kiện cốt lõi để hoàn thành đề tài hiện tại.
