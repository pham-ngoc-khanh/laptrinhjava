# QUẢN LÝ HỌC PHÍ VÀ CÔNG NỢ SINH VIÊN

Ứng dụng desktop Java Swing + JDBC + MySQL, project Maven mở được bằng Apache NetBeans.

## 1. Yêu cầu

- Windows 10/11
- JDK 21
- MySQL Server 8.x đang chạy
- MySQL Workbench (không bắt buộc, dùng để xem dữ liệu)
- Apache NetBeans (nếu muốn mở/chỉnh sửa source)

## 2. Cấu hình MySQL

Cấu hình nằm tại:

`src/main/resources/database.properties`

Ứng dụng đã được cấu hình theo MySQL trên máy hiện tại. Nếu sau này đổi tài khoản/mật khẩu, chỉ sửa file này.

Ứng dụng sẽ tự tạo database `QuanLyDaoTao` và các bảng khi chạy lần đầu nếu tài khoản MySQL có quyền tạo database. Nếu database hoàn toàn trống, chương trình tự nạp dữ liệu mẫu.

## 3. Chạy nhanh bằng JAR

Mở thư mục `dist` và chạy:

`CHAY_UNG_DUNG.bat`

Hoặc mở Command Prompt tại thư mục đó và chạy:

`java -jar QuanLyHocPhiCongNo.jar`

## 4. Chạy bằng NetBeans

1. Mở NetBeans.
2. Chọn **File > Open Project**.
3. Chọn thư mục project này.
4. Chờ Maven nhận dependency `mysql-connector-j`.
5. Kiểm tra JDK của project là **Java 21**.
6. Đảm bảo MySQL Server đang chạy.
7. Bấm **Run Project (F6)**.

## 5. Tài khoản mẫu

- Thư ký: `thuky` / `123456`
- Sinh viên mẫu: `sv001` / `123456`

Sinh viên mới được tạo trong màn hình **Sinh viên** sẽ tự có tài khoản với tên đăng nhập là mã sinh viên viết thường và mật khẩu mặc định `123456`.

Nên đổi mật khẩu sau lần đăng nhập đầu tiên bằng nút **Đổi mật khẩu**.

## 6. Chức năng đã hoàn thiện

### Tài khoản và phân quyền
- Đăng nhập Thư ký / Sinh viên.
- Phân quyền menu và dữ liệu theo vai trò.
- Đổi mật khẩu.
- Tự tạo tài khoản khi thêm sinh viên mới.

### Sinh viên
- Thêm, sửa, xóa, tìm kiếm sinh viên.
- Kiểm tra ngày sinh, số điện thoại, email.
- Tìm nhanh từ thanh trên cùng.
- Xuất danh sách CSV mở bằng Excel.

### Học phần
- Thêm, sửa, xóa học phần.
- Kiểm tra số tín chỉ và học phí/tín chỉ.
- Không cho xóa học phần đang được đăng ký.
- Khi thay đổi học phần, hệ thống tính lại học phí/công nợ liên quan.

### Học kỳ - năm học
- Thêm, sửa, xóa học kỳ.
- Kiểm tra ngày bắt đầu/kết thúc.
- Không xóa học kỳ đang có dữ liệu liên quan.

### Đăng ký học phần
- Thêm/hủy đăng ký học phần.
- Chống đăng ký trùng.
- Tự tính lại học phí và công nợ sau đăng ký.
- Không cho hủy đăng ký nếu học kỳ đã phát sinh thanh toán.
- Sinh viên chỉ xem các học phần của chính mình.
- Xuất CSV.

### Học phí
- Tính học phí từ số tín chỉ và đơn giá học phần.
- Hỗ trợ miễn/giảm học phí.
- Đồng bộ công nợ tự động.
- Không cho giảm học phí xuống thấp hơn số tiền đã thu.

### Công nợ
- Theo dõi phải thu, đã thu, còn lại và trạng thái.
- Tự cập nhật sau thanh toán.
- Chống nộp vượt số tiền còn nợ.

### Thanh toán QR / tiền mặt và xác nhận từ Thư ký
- Sinh viên có màn hình **Thanh toán học phí** riêng.
- Hỗ trợ **quét QR chuyển khoản** bằng đúng ảnh QR đã tích hợp trong ứng dụng.
- Hỗ trợ **Tiền mặt**: sinh viên nộp trực tiếp rồi gửi thông báo cho Thư ký.
- Sau khi thanh toán, sinh viên bấm **TÔI ĐÃ THANH TOÁN - GỬI XÁC NHẬN**.
- Tài khoản Thư ký có tab **Chờ xác nhận (n)**, hiển thị rõ MSSV, họ tên, học kỳ, số tiền, hình thức, thời gian và tin nhắn.
- Thư ký có thể **Xác nhận đã nhận tiền** hoặc **Từ chối** kèm lý do.
- Chỉ khi Thư ký xác nhận, hệ thống mới tạo phiếu thanh toán và cập nhật công nợ; việc này chạy trong **cùng một transaction** để tránh lệch dữ liệu.
- Sinh viên theo dõi được trạng thái: **Chờ xác nhận / Đã xác nhận / Từ chối**.
- Vẫn có mục **Ghi nhận trực tiếp** cho Thư ký khi thu tiền tại quầy hoặc tự đối soát giao dịch.
- Bảng dữ liệu dùng thanh cuộn ngang khi cần, giao diện thanh toán tách tab để tránh tràn chữ/lấn chiếm.

### Báo cáo - thống kê
- Dashboard dùng dữ liệu thật từ MySQL.
- Tổng phải thu, đã thu, còn nợ.
- Báo cáo theo khoa.
- Doanh thu theo tháng/năm học.
- Xuất dữ liệu báo cáo CSV.
- In phiếu/xác nhận thanh toán qua hộp thoại Print của Windows (có thể chọn Microsoft Print to PDF).

## 7. Lưu ý trước khi bàn giao

- Đảm bảo MySQL Server đang chạy trước khi mở ứng dụng.
- Nên tạo một user MySQL riêng cho ứng dụng thay vì dùng `root` khi triển khai thật.
- Tài khoản ứng dụng mẫu đang lưu mật khẩu dạng văn bản để phù hợp phạm vi bài tập. Nếu dùng cho hệ thống thật, cần nâng cấp sang băm mật khẩu (BCrypt/Argon2) và có quy trình sao lưu/khôi phục dữ liệu.

---

## BẢN HOÀN THIỆN GIAO DIỆN + THANH TOÁN

- Nút gửi xác nhận của sinh viên được ghim cố định ở cuối tab Thanh toán, không còn bị khuất.
- Tài khoản Thư ký có nút **ĐÃ NHẬN TIỀN & HOÀN TẤT** ngay phía trên bảng chờ xác nhận.
- Sinh viên có dòng trạng thái gần nhất và xem ngày/người xử lý trong `Yêu cầu của tôi`.
- Thư ký có ô tìm nhanh MSSV/họ tên ở danh sách chờ.
- Các bảng dùng cuộn ngang khi nhiều cột; trang dài cuộn dọc; nhóm nút tự xuống dòng.
- Xem thêm `KIEM_TRA_CHUC_NANG_HOAN_THIEN.md` để test đầy đủ luồng nghiệp vụ.
