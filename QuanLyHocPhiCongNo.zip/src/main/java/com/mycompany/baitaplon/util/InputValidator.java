package com.mycompany.baitaplon.util;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.regex.Pattern;

public final class InputValidator {
    private static final Pattern EMAIL = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern PHONE = Pattern.compile("^(0|\\+84)[0-9]{9,10}$");
    private InputValidator() {}

    public static boolean isValidDate(String value) {
        if (value == null || value.isBlank()) return true;
        try { LocalDate.parse(value.trim()); return true; }
        catch (DateTimeParseException ex) { return false; }
    }

    public static boolean isValidEmail(String value) {
        return value == null || value.isBlank() || EMAIL.matcher(value.trim()).matches();
    }

    public static boolean isValidPhone(String value) {
        if (value == null || value.isBlank()) return true;
        String normalized = value.replaceAll("[ .-]", "");
        return PHONE.matcher(normalized).matches();
    }
}
