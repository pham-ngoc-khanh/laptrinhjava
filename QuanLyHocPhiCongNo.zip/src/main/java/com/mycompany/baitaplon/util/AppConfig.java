package com.mycompany.baitaplon.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class AppConfig {
    private static final Properties PROPS = new Properties();

    static {
        try (InputStream in = AppConfig.class.getResourceAsStream("/database.properties")) {
            if (in != null) PROPS.load(in);
        } catch (IOException ignored) {
        }
    }

    private AppConfig() {}

    public static String dbUrl() {
        return envOrProp("QLHP_DB_URL", "db.url",
                "jdbc:mysql://localhost:3306/QuanLyDaoTao?createDatabaseIfNotExist=true&useSSL=false&serverTimezone=Asia/Bangkok&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=UTF-8");
    }

    public static String dbUser() {
        return envOrProp("QLHP_DB_USER", "db.user", "root");
    }

    public static String dbPassword() {
        return envOrProp("QLHP_DB_PASSWORD", "db.password", "");
    }

    private static String envOrProp(String env, String key, String fallback) {
        String value = System.getenv(env);
        if (value != null && !value.isBlank()) return value;
        return PROPS.getProperty(key, fallback).trim();
    }
}
