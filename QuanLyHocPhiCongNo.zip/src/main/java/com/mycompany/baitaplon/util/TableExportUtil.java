package com.mycompany.baitaplon.util;

import javax.swing.*;
import javax.swing.table.TableModel;
import java.awt.Component;
import java.io.*;
import java.nio.charset.StandardCharsets;

public final class TableExportUtil {
    private TableExportUtil() {}

    public static void exportCsv(Component parent, JTable table, String defaultName) {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Chọn nơi lưu file CSV");
        chooser.setSelectedFile(new File(defaultName.endsWith(".csv") ? defaultName : defaultName + ".csv"));
        if (chooser.showSaveDialog(parent) != JFileChooser.APPROVE_OPTION) return;
        File file = chooser.getSelectedFile();
        if (!file.getName().toLowerCase().endsWith(".csv")) file = new File(file.getParentFile(), file.getName() + ".csv");
        if (file.exists() && JOptionPane.showConfirmDialog(parent, "File đã tồn tại. Ghi đè?", "Xác nhận", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        try (Writer writer = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8)) {
            writer.write('\ufeff'); // BOM để Excel hiển thị tiếng Việt đúng
            TableModel m = table.getModel();
            for (int c = 0; c < m.getColumnCount(); c++) {
                if (c > 0) writer.write(',');
                writer.write(csv(m.getColumnName(c)));
            }
            writer.write("\r\n");
            for (int r = 0; r < m.getRowCount(); r++) {
                for (int c = 0; c < m.getColumnCount(); c++) {
                    if (c > 0) writer.write(',');
                    Object v = m.getValueAt(r, c);
                    writer.write(csv(v == null ? "" : v.toString().replaceAll("<[^>]+>", "")));
                }
                writer.write("\r\n");
            }
            JOptionPane.showMessageDialog(parent, "Đã xuất file:\n" + file.getAbsolutePath(), "Xuất dữ liệu", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(parent, "Không thể xuất file: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private static String csv(String value) {
        String s = value == null ? "" : value;
        return '"' + s.replace("\"", "\"\"") + '"';
    }
}
