package com.mycompany.baitaplon.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Tạo một Connection mới cho mỗi thao tác. Không dùng Connection dùng chung để
 * tránh lỗi transaction bị commit/close chéo giữa các DAO.
 */
public final class DatabaseConnection {
    private DatabaseConnection() {}

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("Không tìm thấy MySQL Connector/J. Hãy chạy project bằng Maven/NetBeans để tải dependency.", e);
        }
        return DriverManager.getConnection(AppConfig.dbUrl(), AppConfig.dbUser(), AppConfig.dbPassword());
    }

    public static boolean testConnection() {
        try (Connection ignored = getConnection()) {
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    /** Giữ lại để tương thích mã cũ; connection hiện được đóng bằng try-with-resources. */
    public static void closeConnection() {
        // no-op
    }
}
