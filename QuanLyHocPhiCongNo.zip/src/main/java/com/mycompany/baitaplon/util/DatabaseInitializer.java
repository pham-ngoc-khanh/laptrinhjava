package com.mycompany.baitaplon.util;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.*;

public final class DatabaseInitializer {
    private DatabaseInitializer() {}

    public static void initialize() throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection(); Statement st = conn.createStatement()) {
            executeScript(st, loadScript("/db/init.sql"));
            executeScript(st, loadScript("/db/seed.sql"));
            ensureDefaultAccounts(conn);
        }
    }

    private static boolean accountExists(Connection conn, String tenDN) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("SELECT MaTK FROM TaiKhoan WHERE TenDangNhap=?")) {
            ps.setString(1, tenDN);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }

    private static void insertAccount(Connection conn, String tenDN, String mk, String vt, String maSV, String hoTen, String tt) throws SQLException {
        String sql = "INSERT INTO TaiKhoan(TenDangNhap,MatKhau,VaiTro,MaSV,HoTen,TrangThai) VALUES(?,?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, tenDN); ps.setString(2, mk); ps.setString(3, vt);
            ps.setString(4, maSV); ps.setString(5, hoTen); ps.setString(6, tt);
            ps.executeUpdate();
        }
    }

    private static void ensureDefaultAccounts(Connection conn) throws SQLException {
        if (!accountExists(conn, "admin")) {
            insertAccount(conn, "admin", "123456", "ADMIN", null, "Quản trị Hệ thống", "Hoat dong");
        }
        if (!accountExists(conn, "thuky")) {
            insertAccount(conn, "thuky", "123456", "THU_KY", null, "Nguyễn Văn Thư Ký", "Hoat dong");
        }
        if (!accountExists(conn, "sv001")) {
            insertAccount(conn, "sv001", "123456", "SINH_VIEN", "SV001", "Nguyễn Văn A", "Hoat dong");
        }
    }

    private static void executeScript(Statement st, String script) throws SQLException {
        for (String raw : script.split(";")) {
            String sql = raw.trim();
            if (!sql.isEmpty()) st.execute(sql);
        }
    }

    private static String loadScript(String resource) throws SQLException {
        InputStream in = DatabaseInitializer.class.getResourceAsStream(resource);
        if (in == null) throw new SQLException("Không tìm thấy script CSDL: " + resource);
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                String t = line.trim();
                if (!t.startsWith("--") && !t.isEmpty()) sb.append(line).append('\n');
            }
        } catch (IOException e) { throw new SQLException("Không đọc được script CSDL", e); }
        return sb.toString();
    }
}
