package com.mycompany.baitaplon.service;

import com.mycompany.baitaplon.dao.HocPhanDAO;
import com.mycompany.baitaplon.model.HocPhan;
import com.mycompany.baitaplon.util.UserSession;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HocPhanService {

    private final HocPhanDAO dao;
    private final AuditService auditService = new AuditService();
    private void audit(String action, String entity, String detail) {
        try { auditService.ghi(action, entity, detail); } catch (Exception ignore) {}
    }

    public HocPhanService() {
        this.dao = new HocPhanDAO();
    }

    public List<HocPhan> getAll() throws SQLException {
        return dao.getAll();
    }

    public HocPhan getById(String maHP) throws SQLException {
        return dao.getById(maHP);
    }

    public List<HocPhan> search(String kw) throws SQLException {
        if (kw == null || kw.trim().isEmpty()) {
            return dao.getAll();
        }
        String key = kw.trim().toLowerCase();
        List<HocPhan> all = dao.getAll();
        List<HocPhan> result = new ArrayList<>();
        for (HocPhan hp : all) {
            boolean match = false;
            if (hp.getMaHP() != null && hp.getMaHP().toLowerCase().contains(key)) match = true;
            if (!match && hp.getTenHP() != null && hp.getTenHP().toLowerCase().contains(key)) match = true;
            if (!match && hp.getMaNganh() != null && hp.getMaNganh().toLowerCase().contains(key)) match = true;
            if (!match && hp.getTenNganh() != null && hp.getTenNganh().toLowerCase().contains(key)) match = true;
            if (!match && String.valueOf(hp.getSoTinChi()).contains(key)) match = true;
            if (match) result.add(hp);
        }
        return result;
    }

    public boolean insert(HocPhan hp) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Bạn không có quyền thêm học phần.");
        }
        boolean ok = dao.insert(hp);
        if (ok) audit("THEM_HOC_PHAN", "HocPhan", String.format("%s - %s (%d tc)", hp.getMaHP(), hp.getTenHP(), hp.getSoTinChi()));
        return ok;
    }

    public boolean update(HocPhan hp) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Bạn không có quyền cập nhật học phần.");
        }
        boolean ok = dao.update(hp);
        if (ok) audit("SUA_HOC_PHAN", "HocPhan", String.format("%s - %s", hp.getMaHP(), hp.getTenHP()));
        return ok;
    }

    public boolean delete(String maHP) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Bạn không có quyền xóa học phần.");
        }
        boolean ok = dao.delete(maHP);
        if (ok) audit("XOA_HOC_PHAN", "HocPhan", "Xóa " + maHP);
        return ok;
    }
}
