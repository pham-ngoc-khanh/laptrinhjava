package com.mycompany.baitaplon.service;

import com.mycompany.baitaplon.dao.DangKyHocPhanDAO;
import com.mycompany.baitaplon.dao.HocPhanDAO;
import com.mycompany.baitaplon.model.DangKyHocPhan;
import com.mycompany.baitaplon.model.HocPhan;
import com.mycompany.baitaplon.util.DatabaseConnection;
import com.mycompany.baitaplon.util.UserSession;
import java.sql.*;
import java.util.List;

public class DangKyHocPhanService {
    public static final int TONG_TIN_CHI_BAT_BUOC_1_NAM = 24;

    private final DangKyHocPhanDAO dao = new DangKyHocPhanDAO();
    private final HocPhanDAO hocPhanDAO = new HocPhanDAO();
    private final SinhVienService sinhVienService = new SinhVienService();
    private final AuditService auditService = new AuditService();
    private void audit(String action, String entity, String detail) {
        try { auditService.ghi(action, entity, detail); } catch (Exception ignore) {}
    }

    public List<DangKyHocPhan> getAll() throws SQLException {
        if (UserSession.isSinhVien()) {
            throw new IllegalStateException("Sinh viên chỉ xem được đăng ký học phần của bản thân.");
        }
        return dao.getAll();
    }

    public DangKyHocPhan getById(int maDKHP) throws SQLException {
        if (UserSession.isSinhVien()) {
            String maSV = UserSession.getMaSV();
            for (DangKyHocPhan dk : dao.getByMaSV(maSV)) {
                if (dk.getMaDKHP() == maDKHP) {
                    return dk;
                }
            }
            throw new IllegalStateException("Sinh viên chỉ xem được đăng ký học phần của bản thân.");
        }
        for (DangKyHocPhan dk : dao.getAll()) {
            if (dk.getMaDKHP() == maDKHP) {
                return dk;
            }
        }
        return null;
    }

    public List<DangKyHocPhan> search(String keyword) throws SQLException {
        if (UserSession.isSinhVien()) {
            throw new IllegalStateException("Sinh viên chỉ xem được đăng ký học phần của bản thân.");
        }
        return dao.search(keyword);
    }

    public List<DangKyHocPhan> getBySinhVien(String maSV) throws SQLException {
        if (UserSession.isSinhVien()) {
            String currentMaSV = UserSession.getMaSV();
            if (!currentMaSV.equals(maSV)) {
                throw new IllegalStateException("Sinh viên chỉ xem được đăng ký học phần của bản thân.");
            }
        }
        return dao.getByMaSV(maSV);
    }

    public int getTongTinChiTheoNamHoc(String maSV, String namHoc) throws SQLException {
        if (maSV == null || namHoc == null) return 0;
        String sql = "SELECT COALESCE(SUM(hp.SoTinChi),0) FROM DangKyHocPhan dk " +
                "JOIN HocPhan hp ON dk.MaHP=hp.MaHP " +
                "JOIN HocKyNamHoc hk ON dk.MaHKNH=hk.MaHKNH " +
                "WHERE dk.MaSV=? AND hk.NamHoc=?";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, maSV);
            ps.setString(2, namHoc);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        }
        return 0;
    }

    public int getTongTinChiTheoMaHKNH(String maSV, String maHKNH) throws SQLException {
        if (maSV == null || maHKNH == null) return 0;
        String sql = "SELECT COALESCE(SUM(hp.SoTinChi),0) FROM DangKyHocPhan dk " +
                "JOIN HocPhan hp ON dk.MaHP=hp.MaHP WHERE dk.MaSV=? AND dk.MaHKNH=?";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, maSV); ps.setString(2, maHKNH);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) return rs.getInt(1); }
        }
        return 0;
    }

    public boolean insert(String maSV, String maHP, String maHKNH, Date ngayDangKy) throws SQLException {
        if (UserSession.isSinhVien()) {
            String ownMa = UserSession.getMaSV();
            if (!ownMa.equals(maSV)) throw new IllegalStateException("Sinh viên chỉ được đăng ký học phần cho chính mình.");
        } else if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Chỉ admin hoặc thủ ký mới được thêm đăng ký học phần cho sinh viên khác.");
        }
        if (maSV == null || maSV.isBlank()) throw new IllegalArgumentException("Mã sinh viên không được rỗng.");
        if (maHP == null || maHP.isBlank()) throw new IllegalArgumentException("Mã học phần không được rỗng.");
        if (maHKNH == null || maHKNH.isBlank()) throw new IllegalArgumentException("Mã học kỳ năm học không được rỗng.");

        HocPhan hp = hocPhanDAO.getById(maHP);
        if (hp == null) throw new IllegalArgumentException("Học phần " + maHP + " không tồn tại.");
        String maNganhHP = hp.getMaNganh();
        String maNganhSV = sinhVienService.getMaNganhByMaSV(maSV);
        if (maNganhHP != null && maNganhSV != null && !maNganhHP.equals(maNganhSV)) {
            throw new IllegalStateException(String.format(
                    "Không thể đăng ký học phần khác ngành!\n"
                            + "• Học phần: %s - %s\n"
                            + "  → Thuộc ngành: %s\n"
                            + "• Sinh viên %s\n"
                            + "  → Thuộc ngành: %s\n"
                            + "Sinh viên chỉ được đăng ký học phần CÙNG NGÀNH với mình.",
                    hp.getMaHP(), hp.getTenHP(), maNganhHP,
                    maSV, maNganhSV));
        }
        int soTCThem = hp.getSoTinChi();

        String namHoc = null;
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT NamHoc FROM HocKyNamHoc WHERE MaHKNH=?")) {
            ps.setString(1, maHKNH);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) namHoc = rs.getString(1); }
        }
        if (namHoc == null) throw new IllegalArgumentException("Học kỳ " + maHKNH + " không tồn tại trong hệ thống.");

        int tcNamHienTai = getTongTinChiTheoNamHoc(maSV, namHoc);
        int tcKyHienTai = getTongTinChiTheoMaHKNH(maSV, maHKNH);
        int tongSauKhiThem = tcNamHienTai + soTCThem;

        if (tongSauKhiThem > TONG_TIN_CHI_BAT_BUOC_1_NAM) {
            throw new IllegalStateException(String.format(
                    "Vượt quá định mức %d tín chỉ / năm học!\n"
                            + "• Năm học %s: hiện có %d tín chỉ\n"
                            + "• Thêm học phần %s (%d tín chỉ) → tổng %d / %d (vượt %d tín chỉ)\n"
                            + "Vui lòng chọn học phần khác hoặc điều chỉnh lại đăng ký.",
                    TONG_TIN_CHI_BAT_BUOC_1_NAM, namHoc, tcNamHienTai,
                    hp.getTenHP(), soTCThem, tongSauKhiThem, TONG_TIN_CHI_BAT_BUOC_1_NAM,
                    tongSauKhiThem - TONG_TIN_CHI_BAT_BUOC_1_NAM));
        }

        boolean ok = dao.insert(maSV, maHP, maHKNH, ngayDangKy);
        if (ok) {
            int tcMoiNam = getTongTinChiTheoNamHoc(maSV, namHoc);
            int tcMoiKy = tcKyHienTai + soTCThem;
            String detail = String.format("%s đăng ký %s @ %s (tc %d). Năm %s: %d/%d tín chỉ. Kỳ %s: %d tín chỉ.",
                    maSV, maHP, maHKNH, soTCThem, namHoc, tcMoiNam, TONG_TIN_CHI_BAT_BUOC_1_NAM, maHKNH, tcMoiKy);
            audit("THEM_DANG_KY_HP", "DangKyHocPhan", detail);
        }
        return ok;
    }

    public boolean update(DangKyHocPhan dk) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Chỉ admin hoặc thủ ký mới được sửa đăng ký học phần.");
        }
        throw new UnsupportedOperationException("Đăng ký học phần không hỗ trợ sửa trực tiếp. Hãy hủy và đăng ký lại.");
    }

    public boolean delete(int maDKHP) throws SQLException {
        if (UserSession.isSinhVien()) {
            String ownMa = UserSession.getMaSV();
            DangKyHocPhan dk = dao.getById(maDKHP);
            if (dk == null || !ownMa.equals(dk.getMaSV())) throw new IllegalStateException("Sinh viên chỉ được hủy đăng ký học phần của chính mình.");
        } else if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Chỉ admin hoặc thủ ký mới được xóa đăng ký học phần.");
        }
        boolean ok = dao.delete(maDKHP);
        if (ok) audit("XOA_DANG_KY_HP", "DangKyHocPhan", "Xóa đăng ký #" + maDKHP);
        return ok;
    }
}
