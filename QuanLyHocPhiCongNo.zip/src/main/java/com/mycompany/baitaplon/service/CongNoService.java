package com.mycompany.baitaplon.service;

import com.mycompany.baitaplon.dao.CongNoDAO;
import com.mycompany.baitaplon.model.CongNo;
import com.mycompany.baitaplon.model.SinhVien;
import com.mycompany.baitaplon.util.UserSession;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public class CongNoService {
    private final CongNoDAO dao = new CongNoDAO();
    private final AuditService auditService = new AuditService();
    private void audit(String action, String entity, String detail) {
        try { auditService.ghi(action, entity, detail); } catch (Exception ignore) {}
    }

    public List<CongNo> getAll() throws SQLException {
        if (UserSession.isSinhVien()) {
            throw new IllegalStateException("Sinh viên chỉ xem được công nợ của bản thân.");
        }
        return dao.getAll();
    }

    public CongNo getById(int maCongNo) throws SQLException {
        if (UserSession.isSinhVien()) {
            String maSV = UserSession.getMaSV();
            for (CongNo cn : dao.getByMaSV(maSV)) {
                if (cn.getMaCongNo() == maCongNo) {
                    return cn;
                }
            }
            throw new IllegalStateException("Sinh viên chỉ xem được công nợ của bản thân.");
        }
        for (CongNo cn : dao.getAll()) {
            if (cn.getMaCongNo() == maCongNo) {
                return cn;
            }
        }
        return null;
    }

    public List<CongNo> search(String keyword) throws SQLException {
        if (UserSession.isSinhVien()) {
            throw new IllegalStateException("Sinh viên chỉ xem được công nợ của bản thân.");
        }
        return dao.searchBySV(keyword);
    }

    public List<CongNo> getBySinhVien(String maSV) throws SQLException {
        if (UserSession.isSinhVien()) {
            String currentMaSV = UserSession.getMaSV();
            if (!currentMaSV.equals(maSV)) {
                throw new IllegalStateException("Sinh viên chỉ xem được công nợ của bản thân.");
            }
        }
        return dao.getByMaSV(maSV);
    }

    public boolean capNhatCongNo(SinhVien sv, String hocKy, BigDecimal soTienThu) throws SQLException {
        return capNhatCongNo(sv.getMaSV(), hocKy, soTienThu);
    }

    public boolean capNhatCongNo(String maSV, String maHKNH, BigDecimal soTienThu) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Chỉ admin hoặc thủ ký mới được cập nhật công nợ.");
        }
        if (maSV == null || maSV.isBlank()) throw new IllegalArgumentException("Mã sinh viên không được rỗng.");
        if (maHKNH == null || maHKNH.isBlank()) throw new IllegalArgumentException("Mã học kỳ năm học không được rỗng.");
        boolean ok = dao.capNhatCongNo(maSV, maHKNH, soTienThu);
        if (ok) audit("CAP_NHAT_CONG_NO", "CongNo", String.format("%s @ %s đã thu %s", maSV, maHKNH, soTienThu == null ? "null" : soTienThu.toPlainString()));
        return ok;
    }

    public boolean insert(CongNo cn) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Chỉ admin hoặc thủ ký mới được thêm công nợ.");
        }
        throw new UnsupportedOperationException("Công nợ được đồng bộ tự động từ học phí. Không hỗ trợ thêm trực tiếp.");
    }

    public boolean update(CongNo cn) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Chỉ admin hoặc thủ ký mới được sửa công nợ.");
        }
        throw new UnsupportedOperationException("Công nợ chỉ được cập nhật qua thanh toán. Sử dụng capNhatCongNo.");
    }

    public boolean delete(int maCongNo) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Chỉ admin hoặc thủ ký mới được xóa công nợ.");
        }
        throw new UnsupportedOperationException("Công nợ không được xóa trực tiếp. Công nợ sẽ tự động xóa khi hủy học kỳ tương ứng.");
    }
}
