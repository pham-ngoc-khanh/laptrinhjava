package com.mycompany.baitaplon.service;

import com.mycompany.baitaplon.dao.HocPhiDAO;
import com.mycompany.baitaplon.model.HocPhi;
import com.mycompany.baitaplon.model.SinhVien;
import com.mycompany.baitaplon.util.UserSession;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public class HocPhiService {
    private final HocPhiDAO dao = new HocPhiDAO();
    private final AuditService auditService = new AuditService();
    private void audit(String action, String entity, String detail) {
        try { auditService.ghi(action, entity, detail); } catch (Exception ignore) {}
    }

    public List<HocPhi> getAll() throws SQLException {
        if (UserSession.isSinhVien()) {
            throw new IllegalStateException("Sinh viên chỉ xem được học phí của bản thân.");
        }
        return dao.getAll();
    }

    public HocPhi getById(int maHPPhi) throws SQLException {
        if (UserSession.isSinhVien()) {
            String maSV = UserSession.getMaSV();
            for (HocPhi hp : dao.getByMaSV(maSV)) {
                if (hp.getMaHPPhi() == maHPPhi) {
                    return hp;
                }
            }
            throw new IllegalStateException("Sinh viên chỉ xem được học phí của bản thân.");
        }
        for (HocPhi hp : dao.getAll()) {
            if (hp.getMaHPPhi() == maHPPhi) {
                return hp;
            }
        }
        return null;
    }

    public List<HocPhi> search(String keyword) throws SQLException {
        if (UserSession.isSinhVien()) {
            throw new IllegalStateException("Sinh viên chỉ xem được học phí của bản thân.");
        }
        return dao.getByMaSV(keyword);
    }

    public List<HocPhi> getBySinhVien(String maSV) throws SQLException {
        if (UserSession.isSinhVien()) {
            String currentMaSV = UserSession.getMaSV();
            if (!currentMaSV.equals(maSV)) {
                throw new IllegalStateException("Sinh viên chỉ xem được học phí của bản thân.");
            }
        }
        return dao.getByMaSV(maSV);
    }

    public boolean tinhHocPhi(SinhVien sv, String hocKy) throws SQLException {
        return tinhHocPhi(sv.getMaSV(), hocKy);
    }

    public boolean tinhHocPhi(String maSV, String maHKNH) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Chỉ admin hoặc thủ ký mới được tính học phí.");
        }
        if (maSV == null || maSV.isBlank()) throw new IllegalArgumentException("Mã sinh viên không được rỗng.");
        if (maHKNH == null || maHKNH.isBlank()) throw new IllegalArgumentException("Mã học kỳ năm học không được rỗng.");
        boolean ok = dao.tinhHocPhi(maSV, maHKNH);
        if (ok) audit("TINH_HOC_PHI", "HocPhi", String.format("%s @ %s", maSV, maHKNH));
        return ok;
    }

    public boolean insert(HocPhi hp) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Chỉ admin hoặc thủ ký mới được thêm học phí.");
        }
        throw new UnsupportedOperationException("Học phí được tính tự động từ đăng ký học phần. Không hỗ trợ thêm trực tiếp.");
    }

    public boolean updateMienGiam(String maSV, String maHKNH, BigDecimal mienGiam) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Chỉ admin hoặc thủ ký mới được sửa học phí.");
        }
        boolean ok = dao.updateMienGiam(maSV, maHKNH, mienGiam);
        if (ok) audit("MIEN_GIAM_HP", "HocPhi", String.format("%s @ %s giảm %s", maSV, maHKNH, mienGiam == null ? "null" : mienGiam.toPlainString()));
        return ok;
    }

    public boolean update(HocPhi hp) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Chỉ admin hoặc thủ ký mới được sửa học phí.");
        }
        throw new UnsupportedOperationException("Học phí chỉ được điều chỉnh qua miễn giảm. Sử dụng updateMienGiam.");
    }

    public boolean delete(int maHPPhi) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Chỉ admin hoặc thủ ký mới được xóa học phí.");
        }
        throw new UnsupportedOperationException("Học phí không được xóa trực tiếp. Hãy hủy đăng ký học phần tương ứng.");
    }
}
