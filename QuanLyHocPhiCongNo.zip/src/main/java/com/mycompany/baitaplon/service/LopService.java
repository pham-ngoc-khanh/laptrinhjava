package com.mycompany.baitaplon.service;

import com.mycompany.baitaplon.dao.LopDAO;
import com.mycompany.baitaplon.model.Lop;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LopService {

    private final LopDAO dao;

    public LopService() {
        this.dao = new LopDAO();
    }

    public List<Lop> getAll() throws SQLException {
        return dao.getAll();
    }

    public Lop getById(String id) throws SQLException {
        return dao.getById(id);
    }

    public List<Lop> search(String kw) throws SQLException {
        if (kw == null || kw.trim().isEmpty()) {
            return dao.getAll();
        }
        String key = kw.trim().toLowerCase();
        List<Lop> all = dao.getAll();
        List<Lop> result = new ArrayList<>();
        for (Lop l : all) {
            boolean match = false;
            if (l.getMaLop() != null && l.getMaLop().toLowerCase().contains(key)) match = true;
            if (!match && l.getTenLop() != null && l.getTenLop().toLowerCase().contains(key)) match = true;
            if (!match && l.getMaNganh() != null && l.getMaNganh().toLowerCase().contains(key)) match = true;
            if (!match && String.valueOf(l.getKhoaHoc()).contains(key)) match = true;
            if (match) result.add(l);
        }
        return result;
    }
}
