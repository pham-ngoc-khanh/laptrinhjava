package com.mycompany.baitaplon.service;

import com.mycompany.baitaplon.dao.NamHocHocPhiDAO;
import com.mycompany.baitaplon.model.NamHocHocPhi;
import com.mycompany.baitaplon.util.UserSession;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public class NamHocHocPhiService {
    private final NamHocHocPhiDAO dao = new NamHocHocPhiDAO();
    private final AuditService auditService = new AuditService();
    private void audit(String action, String entity, String detail) {
        try { auditService.ghi(action, entity, detail); } catch (Exception ignore) {}
    }

    public List<NamHocHocPhi> getAll() throws SQLException {
        requireLogin();
        return dao.getAll();
    }

    public NamHocHocPhi getByNamHoc(String namHoc) throws SQLException {
        requireLogin();
        return dao.getByNamHoc(namHoc);
    }

    public BigDecimal getGiaMotTinChi(String namHoc) throws SQLException {
        return dao.getGiaMotTinChi(namHoc);
    }

    private static void requireLogin() {
        if (!UserSession.isLoggedIn()) {
            throw new IllegalStateException("Vui lòng đăng nhập để sử dụng chức năng này.");
        }
    }
}
