package com.mycompany.baitaplon.service;

import com.mycompany.baitaplon.dao.CongNoDAO;
import com.mycompany.baitaplon.dao.SinhVienDAO;
import com.mycompany.baitaplon.dao.YeuCauThanhToanDAO;
import com.mycompany.baitaplon.model.YeuCauThanhToan;
import com.mycompany.baitaplon.util.DatabaseConnection;
import com.mycompany.baitaplon.util.UserSession;

import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class YeuCauThanhToanService {

    private final YeuCauThanhToanDAO yeuCauDAO = new YeuCauThanhToanDAO();
    private final SinhVienDAO sinhVienDAO = new SinhVienDAO();
    private final CongNoDAO congNoDAO = new CongNoDAO();
    private final AuditService auditService = new AuditService();
    private void audit(String action, String entity, String detail) {
        try { auditService.ghi(action, entity, detail); } catch (Exception ignore) {}
    }

    private static final String BASE =
            "SELECT yc.*, sv.HoTen, hk.HocKy, hk.NamHoc FROM YeuCauThanhToan yc " +
            "LEFT JOIN SinhVien sv ON yc.MaSV=sv.MaSV " +
            "LEFT JOIN HocKyNamHoc hk ON yc.MaHKNH=hk.MaHKNH ";

    public List<YeuCauThanhToan> getAll() throws SQLException {
        if (UserSession.isSinhVien()) {
            return getByMaSV(UserSession.getMaSV());
        }
        requireThuKyOrAdmin();
        return query(BASE + "ORDER BY yc.NgayGui DESC, yc.MaYeuCau DESC", null);
    }

    public List<YeuCauThanhToan> getPending() throws SQLException {
        if (UserSession.isSinhVien()) {
            String sql = BASE + "WHERE yc.TrangThai='CHO_XAC_NHAN' AND yc.MaSV=? ORDER BY yc.NgayGui ASC, yc.MaYeuCau ASC";
            return query(sql, new Object[]{UserSession.getMaSV()});
        }
        requireThuKyOrAdmin();
        return yeuCauDAO.getPending();
    }

    public YeuCauThanhToan getById(int maYeuCau) throws SQLException {
        requireNotGuest();
        String sql = BASE + "WHERE yc.MaYeuCau=?";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, maYeuCau);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    YeuCauThanhToan yc = map(rs);
                    if (UserSession.isSinhVien() && !yc.getMaSV().equals(UserSession.getMaSV())) {
                        throw new IllegalStateException("Bạn không có quyền xem yêu cầu thanh toán của sinh viên khác.");
                    }
                    return yc;
                }
                return null;
            }
        }
    }

    public List<YeuCauThanhToan> search(String kw) throws SQLException {
        requireNotGuest();
        if (kw == null || kw.isBlank()) return getAll();
        String pattern = "%" + kw.trim() + "%";
        StringBuilder sql = new StringBuilder(BASE + "WHERE (yc.MaSV LIKE ? OR sv.HoTen LIKE ? OR yc.MaYeuCau LIKE ?) ");
        List<Object> args = new ArrayList<>();
        args.add(pattern); args.add(pattern); args.add(pattern);
        if (UserSession.isSinhVien()) {
            sql.append("AND yc.MaSV=? ");
            args.add(UserSession.getMaSV());
        } else {
            requireThuKyOrAdmin();
        }
        sql.append("ORDER BY yc.NgayGui DESC, yc.MaYeuCau DESC");
        return query(sql.toString(), args.toArray());
    }

    public List<YeuCauThanhToan> getByMaSV(String maSV) throws SQLException {
        requireNotGuest();
        if (UserSession.isSinhVien()) {
            if (!maSV.equals(UserSession.getMaSV())) {
                throw new IllegalStateException("Bạn không có quyền xem yêu cầu thanh toán của sinh viên khác.");
            }
            return yeuCauDAO.getByMaSV(maSV);
        }
        requireThuKyOrAdmin();
        return yeuCauDAO.getByMaSV(maSV);
    }

    public boolean insertYeuCau(YeuCauThanhToan yc) throws SQLException {
        requireNotGuest();
        if (yc == null) throw new SQLException("Thông tin yêu cầu không được rỗng.");
        if (yc.getSoTien() == null || yc.getSoTien().signum() <= 0) {
            throw new SQLException("Số tiền phải lớn hơn 0.");
        }
        if (yc.getHinhThucThanhToan() == null || yc.getHinhThucThanhToan().isBlank()) {
            throw new SQLException("Hình thức thanh toán không được rỗng.");
        }
        if (yc.getMaSV() == null || yc.getMaSV().isBlank()) {
            throw new SQLException("Mã sinh viên không được rỗng.");
        }
        if (sinhVienDAO.getById(yc.getMaSV()) == null) {
            throw new SQLException("Sinh viên có mã " + yc.getMaSV() + " không tồn tại.");
        }
        if (UserSession.isSinhVien()) {
            if (!yc.getMaSV().equals(UserSession.getMaSV())) {
                throw new IllegalStateException("Bạn chỉ có thể gửi yêu cầu thanh toán cho chính mình.");
            }
        } else {
            requireThuKyOrAdmin();
        }
        if (yc.getTrangThai() == null || yc.getTrangThai().isBlank()) {
            yc.setTrangThai("CHO_XAC_NHAN");
        }
        boolean ok = yeuCauDAO.createRequest(yc);
        if (ok) audit("GUI_YEU_CAU_TT", "YeuCauThanhToan", String.format("%s @ %s: %s %s", yc.getMaSV(), yc.getMaHKNH(), yc.getHinhThucThanhToan(), yc.getSoTien() == null ? "" : yc.getSoTien().toPlainString()));
        return ok;
    }

    public boolean xacNhanThanhToan(int maYC, String ketQua, String lyDo) throws SQLException {
        requireThuKyOrAdmin();
        if (maYC <= 0) throw new SQLException("Mã yêu cầu không hợp lệ.");
        if (ketQua == null || ketQua.isBlank()) {
            throw new SQLException("Kết quả xử lý không được rỗng.");
        }
        String nguoiXuLy = UserSession.getHoTen();
        boolean ok;
        switch (ketQua) {
            case "DA_XAC_NHAN":
                ok = yeuCauDAO.confirm(maYC, nguoiXuLy);
                if (ok) audit("XAC_NHAN_THANH_TOAN", "YeuCauThanhToan", "Xác nhận yêu cầu #" + maYC);
                return ok;
            case "TU_CHOI":
                if (lyDo == null || lyDo.isBlank()) {
                    throw new SQLException("Vui lòng nhập lý do từ chối.");
                }
                ok = yeuCauDAO.reject(maYC, lyDo, nguoiXuLy);
                if (ok) audit("TU_CHOI_THANH_TOAN", "YeuCauThanhToan", "Từ chối yêu cầu #" + maYC + " Lý do: " + lyDo);
                return ok;
            case "HUY":
                if (lyDo == null || lyDo.isBlank()) {
                    lyDo = "Hủy bởi thủ ký";
                }
                ok = yeuCauDAO.reject(maYC, lyDo, nguoiXuLy);
                if (ok) audit("HUY_YEU_CAU_TT", "YeuCauThanhToan", "Hủy yêu cầu #" + maYC + " Lý do: " + lyDo);
                return ok;
            default:
                throw new SQLException("Kết quả xử lý không hợp lệ: " + ketQua);
        }
    }

    public boolean kiemTraSoDuHopLe(String maSV, String maHKNH, BigDecimal soTien) throws SQLException {
        if (maSV == null || maHKNH == null || soTien == null || soTien.signum() <= 0) return false;
        BigDecimal dangCho = yeuCauDAO.getPendingAmount(maSV, maHKNH);
        BigDecimal conLai = null;
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT ConLai FROM CongNo WHERE MaSV=? AND MaHKNH=?")) {
            ps.setString(1, maSV);
            ps.setString(2, maHKNH);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) conLai = rs.getBigDecimal(1);
            }
        }
        if (conLai == null || conLai.signum() <= 0) return false;
        BigDecimal toiDa = conLai.subtract(dangCho);
        return toiDa.signum() > 0 && soTien.compareTo(toiDa) <= 0;
    }

    public int getPendingCount() throws SQLException {
        requireThuKyOrAdmin();
        return yeuCauDAO.getPendingCount();
    }

    public boolean cancelPending(int maYeuCau, String maSV) throws SQLException {
        requireNotGuest();
        if (maYeuCau <= 0) return false;
        if (UserSession.isSinhVien()) {
            String currentMaSV = UserSession.getMaSV();
            if (currentMaSV == null || (maSV != null && !maSV.equals(currentMaSV))) {
                throw new IllegalStateException("Bạn chỉ có thể hủy yêu cầu thanh toán của mình.");
            }
        }
        return yeuCauDAO.cancelPending(maYeuCau, UserSession.isSinhVien() ? UserSession.getMaSV() : maSV);
    }

    private List<YeuCauThanhToan> query(String sql, Object[] args) throws SQLException {
        List<YeuCauThanhToan> list = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            if (args != null) for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    private YeuCauThanhToan map(ResultSet rs) throws SQLException {
        YeuCauThanhToan yc = new YeuCauThanhToan();
        yc.setMaYeuCau(rs.getInt("MaYeuCau"));
        yc.setMaSV(rs.getString("MaSV"));
        yc.setHoTenSV(rs.getString("HoTen"));
        yc.setMaHKNH(rs.getString("MaHKNH"));
        yc.setTenHKNH("HK " + rs.getInt("HocKy") + " - " + rs.getString("NamHoc"));
        yc.setSoTien(rs.getBigDecimal("SoTien"));
        yc.setHinhThucThanhToan(rs.getString("HinhThucThanhToan"));
        yc.setNoiDung(rs.getString("NoiDung"));
        Timestamp gui = rs.getTimestamp("NgayGui");
        Timestamp xuLy = rs.getTimestamp("NgayXuLy");
        yc.setNgayGui(gui == null ? "" : gui.toLocalDateTime().toString().replace('T', ' ').substring(0, 16));
        yc.setTrangThai(rs.getString("TrangThai"));
        yc.setNguoiXuLy(rs.getString("NguoiXuLy"));
        yc.setNgayXuLy(xuLy == null ? "" : xuLy.toLocalDateTime().toString().replace('T', ' ').substring(0, 16));
        yc.setLyDoTuChoi(rs.getString("LyDoTuChoi"));
        return yc;
    }

    private static void requireNotGuest() {
        if (!UserSession.isLoggedIn()) {
            throw new IllegalStateException("Vui lòng đăng nhập để sử dụng chức năng này.");
        }
    }

    private static void requireThuKyOrAdmin() {
        if (!UserSession.isThuKy() && !UserSession.isAdmin()) {
            throw new IllegalStateException("Chức năng này chỉ dành cho Thư ký khoa hoặc Quản trị viên.");
        }
    }
}
