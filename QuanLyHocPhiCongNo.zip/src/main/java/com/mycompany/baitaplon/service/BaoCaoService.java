package com.mycompany.baitaplon.service;

import com.mycompany.baitaplon.dao.BaoCaoDAO;
import com.mycompany.baitaplon.util.UserSession;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BaoCaoService {

    private final BaoCaoDAO baoCaoDAO = new BaoCaoDAO();

    public Map<String, Object> thongKeTongQuan() throws SQLException {
        requireThuKyOrAdmin();
        return thongKeTongQuan(null);
    }

    public Map<String, Object> thongKeTongQuan(String namHoc) throws SQLException {
        requireThuKyOrAdmin();
        Map<String, Object> result = new HashMap<>();
        result.put("namHocList", getNamHoc());
        result.put("namHocDuocChon", namHoc);
        result.put("baoCaoTheoKhoa", baoCaoCongNoTheoKhoa(namHoc));
        result.put("baoCaoDoanhThuTheoThang", baoCaoDoanhThuTheoThang(namHoc));
        result.put("soSinhVien", demSinhVien(namHoc));
        return result;
    }

    public List<String> getNamHoc() throws SQLException {
        requireThuKyOrAdmin();
        return baoCaoDAO.getNamHoc();
    }

    public List<BaoCaoDAO.KhoaRow> baoCaoCongNoTheoKhoa() throws SQLException {
        requireThuKyOrAdmin();
        return baoCaoDAO.getByKhoa(null);
    }

    public List<BaoCaoDAO.KhoaRow> baoCaoCongNoTheoKhoa(String namHoc) throws SQLException {
        requireThuKyOrAdmin();
        return baoCaoDAO.getByKhoa(namHoc);
    }

    public List<BaoCaoDAO.ThangRow> baoCaoDoanhThuTheoThang() throws SQLException {
        requireThuKyOrAdmin();
        return baoCaoDAO.getTheoThang(null);
    }

    public List<BaoCaoDAO.ThangRow> baoCaoDoanhThuTheoThang(String namHoc) throws SQLException {
        requireThuKyOrAdmin();
        return baoCaoDAO.getTheoThang(namHoc);
    }

    public int demSinhVien() throws SQLException {
        requireThuKyOrAdmin();
        return baoCaoDAO.countStudents(null);
    }

    public int demSinhVien(String namHoc) throws SQLException {
        requireThuKyOrAdmin();
        return baoCaoDAO.countStudents(namHoc);
    }

    private static void requireThuKyOrAdmin() {
        if (UserSession.isSinhVien()) {
            throw new IllegalStateException("Báo cáo và thống kê chỉ dành cho Thư ký khoa hoặc Quản trị viên.");
        }
        if (!UserSession.isThuKy() && !UserSession.isAdmin()) {
            throw new IllegalStateException("Vui lòng đăng nhập với quyền Thư ký khoa hoặc Quản trị viên.");
        }
    }
}
