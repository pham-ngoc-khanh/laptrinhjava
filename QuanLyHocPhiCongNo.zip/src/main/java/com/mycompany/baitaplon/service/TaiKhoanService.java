package com.mycompany.baitaplon.service;

import com.mycompany.baitaplon.dao.TaiKhoanDAO;
import com.mycompany.baitaplon.model.TaiKhoan;
import com.mycompany.baitaplon.model.VaiTro;
import com.mycompany.baitaplon.util.UserSession;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TaiKhoanService {

    private final TaiKhoanDAO dao;

    public TaiKhoanService() {
        this.dao = new TaiKhoanDAO();
    }

    public TaiKhoan authenticate(String u, String p) throws SQLException {
        return dao.authenticate(u, p);
    }

    public boolean changePassword(String username, String oldPass, String newPass) throws SQLException {
        return dao.changePassword(username, oldPass, newPass);
    }

    public List<TaiKhoan> getAll() throws SQLException {
        if (UserSession.isAdmin()) {
            return dao.getAll();
        }
        if (UserSession.isThuKy()) {
            List<TaiKhoan> all = dao.getAll();
            List<TaiKhoan> res = new ArrayList<>();
            for (TaiKhoan t : all) if (t.getVaiTro() == VaiTro.SINH_VIEN) res.add(t);
            return res;
        }
        throw new IllegalStateException("Bạn không có quyền xem danh sách tài khoản.");
    }

    public List<TaiKhoan> search(String kw) throws SQLException {
        if (UserSession.isAdmin()) {
            return dao.search(kw);
        }
        if (UserSession.isThuKy()) {
            List<TaiKhoan> all = dao.search(kw);
            List<TaiKhoan> res = new ArrayList<>();
            for (TaiKhoan t : all) if (t.getVaiTro() == VaiTro.SINH_VIEN) res.add(t);
            return res;
        }
        throw new IllegalStateException("Bạn không có quyền tìm kiếm tài khoản.");
    }

    public TaiKhoan getById(int id) throws SQLException {
        if (!UserSession.isLoggedIn()) {
            throw new IllegalStateException("Bạn chưa đăng nhập.");
        }
        TaiKhoan current = UserSession.get();
        if (UserSession.isAdmin()) return dao.getById(id);
        if (current.getMaTK() == id) return dao.getById(id);
        if (UserSession.isThuKy()) {
            TaiKhoan tk = dao.getById(id);
            if (tk != null && tk.getVaiTro() == VaiTro.SINH_VIEN) return tk;
            throw new IllegalStateException("Bạn chỉ có thể xem chi tiết tài khoản Sinh viên.");
        }
        throw new IllegalStateException("Bạn không có quyền xem tài khoản này.");
    }

    public int insert(TaiKhoan tk) throws SQLException {
        if (tk.getTenDangNhap() == null || tk.getTenDangNhap().trim().length() < 3) {
            throw new IllegalStateException("Tên đăng nhập phải có ít nhất 3 ký tự.");
        }
        if (tk.getHoTen() == null || tk.getHoTen().trim().isEmpty()) {
            throw new IllegalStateException("Họ tên không được để trống.");
        }
        if (dao.getByTenDN(tk.getTenDangNhap()) != null) {
            throw new IllegalStateException("Tên đăng nhập đã tồn tại.");
        }
        if (tk.getMatKhau() == null || tk.getMatKhau().trim().isEmpty()) {
            tk.setMatKhau("123456");
        }
        if (UserSession.isThuKy()) {
            if (tk.getVaiTro() != VaiTro.SINH_VIEN) {
                throw new IllegalStateException("Thư ký chỉ có thể thêm tài khoản Sinh viên.");
            }
            return dao.insert(tk);
        }
        if (UserSession.isAdmin()) return dao.insert(tk);
        throw new IllegalStateException("Bạn không có quyền thêm tài khoản.");
    }

    public boolean update(TaiKhoan tk) throws SQLException {
        if (tk.getTenDangNhap() == null || tk.getTenDangNhap().trim().isEmpty()) {
            throw new IllegalStateException("Tên đăng nhập không được để trống.");
        }
        if (tk.getHoTen() == null || tk.getHoTen().trim().isEmpty()) {
            throw new IllegalStateException("Họ tên không được để trống.");
        }
        if (UserSession.isThuKy()) {
            TaiKhoan exist = dao.getById(tk.getMaTK());
            if (exist == null) throw new IllegalStateException("Tài khoản không tồn tại.");
            if (exist.getVaiTro() != VaiTro.SINH_VIEN) {
                throw new IllegalStateException("Thư ký chỉ có thể cập nhật tài khoản Sinh viên.");
            }
            if (tk.getVaiTro() != VaiTro.SINH_VIEN) {
                throw new IllegalStateException("Thư ký không thể đổi vai trò tài khoản Sinh viên.");
            }
            return dao.update(tk);
        }
        if (UserSession.isAdmin()) return dao.update(tk);
        throw new IllegalStateException("Bạn không có quyền cập nhật tài khoản.");
    }

    public boolean delete(int maTK) throws SQLException {
        TaiKhoan tk = dao.getById(maTK);
        if (tk == null) throw new IllegalStateException("Tài khoản không tồn tại.");
        if (tk.isAdmin() && dao.kiemTraAdminCuoiCung()) {
            throw new IllegalStateException("Không thể xóa tài khoản quản trị cuối cùng của hệ thống! Cần giữ ít nhất 1 tài khoản admin hoạt động.");
        }
        if (UserSession.isThuKy()) {
            if (tk.getVaiTro() != VaiTro.SINH_VIEN) {
                throw new IllegalStateException("Thư ký chỉ có thể xóa tài khoản Sinh viên.");
            }
            return dao.delete(maTK);
        }
        if (UserSession.isAdmin()) return dao.delete(maTK);
        throw new IllegalStateException("Bạn không có quyền xóa tài khoản.");
    }

    public boolean resetPassword(int maTK) throws SQLException {
        if (UserSession.isThuKy()) {
            TaiKhoan tk = dao.getById(maTK);
            if (tk == null) throw new IllegalStateException("Tài khoản không tồn tại.");
            if (tk.getVaiTro() != VaiTro.SINH_VIEN) {
                throw new IllegalStateException("Thư ký chỉ được đặt lại mật khẩu tài khoản Sinh viên.");
            }
            return dao.resetPassword(maTK);
        }
        if (UserSession.isAdmin()) return dao.resetPassword(maTK);
        throw new IllegalStateException("Bạn không có quyền đặt lại mật khẩu.");
    }

    public boolean updateTrangThai(int maTK, String tt) throws SQLException {
        TaiKhoan tk = dao.getById(maTK);
        if (tk != null && tk.isAdmin() && "Khoa".equalsIgnoreCase(tt) && dao.kiemTraAdminCuoiCung()) {
            throw new IllegalStateException("Không thể khóa quản trị cuối cùng!");
        }
        if (UserSession.isThuKy()) {
            if (tk == null) throw new IllegalStateException("Tài khoản không tồn tại.");
            if (tk.getVaiTro() != VaiTro.SINH_VIEN) {
                throw new IllegalStateException("Thư ký chỉ được cập nhật trạng thái tài khoản Sinh viên.");
            }
            return dao.updateTrangThai(maTK, tt);
        }
        if (UserSession.isAdmin()) return dao.updateTrangThai(maTK, tt);
        throw new IllegalStateException("Bạn không có quyền cập nhật trạng thái tài khoản.");
    }
}
