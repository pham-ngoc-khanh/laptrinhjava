package com.mycompany.baitaplon.service;

import com.mycompany.baitaplon.dao.SinhVienDAO;
import com.mycompany.baitaplon.dao.ThanhToanDAO;
import com.mycompany.baitaplon.model.ThanhToan;
import com.mycompany.baitaplon.util.DatabaseConnection;
import com.mycompany.baitaplon.util.UserSession;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ThanhToanService {

    private final ThanhToanDAO thanhToanDAO = new ThanhToanDAO();
    private final SinhVienDAO sinhVienDAO = new SinhVienDAO();
    private final AuditService auditService = new AuditService();
    private void audit(String action, String entity, String detail) {
        try { auditService.ghi(action, entity, detail); } catch (Exception ignore) {}
    }

    private static final String BASE = "SELECT tt.*, sv.HoTen, hk.HocKy, hk.NamHoc FROM ThanhToan tt " +
            "LEFT JOIN SinhVien sv ON tt.MaSV=sv.MaSV LEFT JOIN HocKyNamHoc hk ON tt.MaHKNH=hk.MaHKNH ";

    public List<ThanhToan> getAll() throws SQLException {
        if (UserSession.isSinhVien()) {
            return getByMaSV(UserSession.getMaSV());
        }
        requireThuKyOrAdmin();
        return thanhToanDAO.getAll();
    }

    public ThanhToan getById(int maThanhToan) throws SQLException {
        requireNotGuest();
        String sql = BASE + "WHERE tt.MaThanhToan=?";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, maThanhToan);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    ThanhToan tt = map(rs);
                    if (UserSession.isSinhVien() && !tt.getMaSV().equals(UserSession.getMaSV())) {
                        throw new IllegalStateException("Bạn không có quyền xem phiếu thanh toán của sinh viên khác.");
                    }
                    return tt;
                }
                return null;
            }
        }
    }

    public List<ThanhToan> search(String kw) throws SQLException {
        requireNotGuest();
        if (kw == null || kw.isBlank()) return getAll();
        String pattern = "%" + kw.trim() + "%";
        StringBuilder sql = new StringBuilder(BASE + "WHERE (tt.MaSV LIKE ? OR sv.HoTen LIKE ? OR tt.MaThanhToan LIKE ?) ");
        List<Object> args = new ArrayList<>();
        args.add(pattern); args.add(pattern); args.add(pattern);
        if (UserSession.isSinhVien()) {
            sql.append("AND tt.MaSV=? ");
            args.add(UserSession.getMaSV());
        } else {
            requireThuKyOrAdmin();
        }
        sql.append("ORDER BY tt.NgayThanhToan DESC, tt.MaThanhToan DESC");
        return query(sql.toString(), args.toArray());
    }

    public List<ThanhToan> getByMaSV(String maSV) throws SQLException {
        requireNotGuest();
        if (UserSession.isSinhVien()) {
            if (!maSV.equals(UserSession.getMaSV())) {
                throw new IllegalStateException("Bạn không có quyền xem thanh toán của sinh viên khác.");
            }
            return thanhToanDAO.getByMaSV(maSV);
        }
        requireThuKyOrAdmin();
        return thanhToanDAO.getByMaSV(maSV);
    }

    public boolean insert(ThanhToan tt) throws SQLException {
        requireThuKyOrAdmin();
        validateThanhToan(tt);
        boolean ok = thanhToanDAO.thanhToan(tt);
        if (ok) audit("THU_THANH_TOAN", "ThanhToan", String.format("%s @ %s: %s %s", tt.getMaSV(), tt.getMaHKNH(), tt.getHinhThucThanhToan(), tt.getSoTien() == null ? "" : tt.getSoTien().toPlainString()));
        return ok;
    }

    public boolean update(ThanhToan tt) throws SQLException {
        requireThuKyOrAdmin();
        if (tt == null || tt.getMaThanhToan() <= 0) {
            throw new SQLException("Mã thanh toán không hợp lệ.");
        }
        validateThanhToan(tt);
        String sql = "UPDATE ThanhToan SET MaSV=?, MaHKNH=?, SoTien=?, HinhThucThanhToan=?, NgayThanhToan=?, NguoiThu=?, GhiChu=? WHERE MaThanhToan=?";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, tt.getMaSV());
            ps.setString(2, tt.getMaHKNH());
            ps.setBigDecimal(3, tt.getSoTien());
            ps.setString(4, tt.getHinhThucThanhToan());
            ps.setDate(5, Date.valueOf(tt.getNgayThanhToan()));
            ps.setString(6, tt.getNguoiThu());
            ps.setString(7, tt.getGhiChu());
            ps.setInt(8, tt.getMaThanhToan());
            boolean ok = ps.executeUpdate() == 1;
            if (ok) audit("SUA_THANH_TOAN", "ThanhToan", "Cập nhật #" + tt.getMaThanhToan());
            return ok;
        }
    }

    public boolean delete(int maThanhToan) throws SQLException {
        requireThuKyOrAdmin();
        String sql = "DELETE FROM ThanhToan WHERE MaThanhToan=?";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, maThanhToan);
            boolean ok = ps.executeUpdate() == 1;
            if (ok) audit("XOA_THANH_TOAN", "ThanhToan", "Xóa #" + maThanhToan);
            return ok;
        }
    }

    private void validateThanhToan(ThanhToan tt) throws SQLException {
        if (tt == null) throw new SQLException("Thông tin thanh toán không được rỗng.");
        if (tt.getSoTien() == null || tt.getSoTien().signum() <= 0) {
            throw new SQLException("Số tiền thanh toán phải lớn hơn 0.");
        }
        if (tt.getMaSV() == null || tt.getMaSV().isBlank()) {
            throw new SQLException("Mã sinh viên không được rỗng.");
        }
        if (sinhVienDAO.getById(tt.getMaSV()) == null) {
            throw new SQLException("Sinh viên có mã " + tt.getMaSV() + " không tồn tại.");
        }
        if (tt.getNgayThanhToan() == null || tt.getNgayThanhToan().isBlank()) {
            throw new SQLException("Ngày thanh toán không được rỗng.");
        }
    }

    private List<ThanhToan> query(String sql, Object[] args) throws SQLException {
        List<ThanhToan> list = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            if (args != null) for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    private ThanhToan map(ResultSet rs) throws SQLException {
        ThanhToan tt = new ThanhToan();
        tt.setMaThanhToan(rs.getInt("MaThanhToan"));
        tt.setMaSV(rs.getString("MaSV"));
        tt.setHoTenSV(rs.getString("HoTen"));
        tt.setMaHKNH(rs.getString("MaHKNH"));
        tt.setTenHKNH("HK " + rs.getInt("HocKy") + " - " + rs.getString("NamHoc"));
        tt.setSoTien(rs.getBigDecimal("SoTien"));
        tt.setHinhThucThanhToan(rs.getString("HinhThucThanhToan"));
        tt.setNgayThanhToan(rs.getString("NgayThanhToan"));
        tt.setNguoiThu(rs.getString("NguoiThu"));
        tt.setGhiChu(rs.getString("GhiChu"));
        return tt;
    }

    private static void requireNotGuest() {
        if (!UserSession.isLoggedIn()) {
            throw new IllegalStateException("Vui lòng đăng nhập để sử dụng chức năng này.");
        }
    }

    private static void requireThuKyOrAdmin() {
        if (!UserSession.isThuKy() && !UserSession.isAdmin()) {
            throw new IllegalStateException("Chức năng này chỉ dành cho Thư ký khoa hoặc Quản trị viên.");
        }
    }
}
