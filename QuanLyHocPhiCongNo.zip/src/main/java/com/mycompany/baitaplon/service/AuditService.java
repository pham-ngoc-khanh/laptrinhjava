package com.mycompany.baitaplon.service;

import com.mycompany.baitaplon.dao.AuditDAO;
import com.mycompany.baitaplon.model.AuditLog;
import com.mycompany.baitaplon.model.TaiKhoan;
import com.mycompany.baitaplon.util.UserSession;
import java.sql.SQLException;
import java.util.List;

public class AuditService {

    private final AuditDAO auditDAO;

    public AuditService() {
        this.auditDAO = new AuditDAO();
    }

    public boolean ghi(String hanhDong, String doiTuong, String chiTiet) throws SQLException {
        TaiKhoan tk = UserSession.get();
        Integer maTK = tk != null ? tk.getMaTK() : null;
        String tenDangNhap = tk != null ? tk.getTenDangNhap() : null;
        String hoTen = UserSession.getHoTen();
        AuditLog al = new AuditLog(maTK, tenDangNhap, hanhDong, doiTuong, chiTiet, hoTen);
        return auditDAO.insert(al);
    }

    public List<AuditLog> getAll() throws SQLException {
        return auditDAO.getAll();
    }

    public List<AuditLog> search(String kw) throws SQLException {
        return auditDAO.searchByKeyword(kw);
    }
}
