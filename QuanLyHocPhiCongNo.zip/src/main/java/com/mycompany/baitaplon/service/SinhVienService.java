package com.mycompany.baitaplon.service;

import com.mycompany.baitaplon.dao.SinhVienDAO;
import com.mycompany.baitaplon.model.Lop;
import com.mycompany.baitaplon.model.SinhVien;
import com.mycompany.baitaplon.util.UserSession;
import java.sql.SQLException;
import java.util.List;
import java.util.regex.Pattern;

public class SinhVienService {
    private final SinhVienDAO dao = new SinhVienDAO();
    private final LopService lopService = new LopService();
    private final AuditService auditService = new AuditService();
    private static final Pattern MA_SV_PATTERN = Pattern.compile("^[A-Za-z0-9_-]{3,10}$");
    private void audit(String action, String entity, String detail) {
        try { auditService.ghi(action, entity, detail); } catch (Exception ignore) {}
    }

    public List<SinhVien> getAll() throws SQLException {
        if (UserSession.isSinhVien()) {
            throw new IllegalStateException("Sinh viên chỉ xem được dữ liệu của bản thân.");
        }
        return dao.getAll();
    }

    public SinhVien getById(String maSV) throws SQLException {
        return dao.getById(maSV);
    }

    public String getMaNganhByMaSV(String maSV) throws SQLException {
        if (maSV == null) return null;
        SinhVien sv = dao.getById(maSV);
        if (sv == null || sv.getMaLop() == null) return null;
        Lop lop = lopService.getById(sv.getMaLop());
        return (lop != null) ? lop.getMaNganh() : null;
    }

    public String getTenNganhByMaSV(String maSV) throws SQLException {
        if (maSV == null) return null;
        SinhVien sv = dao.getById(maSV);
        if (sv == null || sv.getMaLop() == null) return null;
        Lop lop = lopService.getById(sv.getMaLop());
        return (lop != null) ? lop.getMaNganh() : null;
    }

    public List<SinhVien> search(String keyword) throws SQLException {
        if (UserSession.isSinhVien()) {
            throw new IllegalStateException("Sinh viên chỉ xem được dữ liệu của bản thân.");
        }
        return dao.search(keyword);
    }

    public boolean insert(SinhVien sv) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Chỉ admin hoặc thủ ký mới được thêm sinh viên.");
        }
        validateSinhVien(sv);
        if (dao.getById(sv.getMaSV()) != null) {
            throw new IllegalArgumentException("Mã sinh viên đã tồn tại.");
        }
        boolean ok = dao.insert(sv);
        if (ok) audit("THEM_SINH_VIEN", "SinhVien", String.format("%s - %s lop %s", sv.getMaSV(), sv.getHoTen(), sv.getMaLop()));
        return ok;
    }

    public boolean update(SinhVien sv) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Chỉ admin hoặc thủ ký mới được sửa sinh viên.");
        }
        validateSinhVien(sv);
        if (dao.getById(sv.getMaSV()) == null) {
            throw new IllegalArgumentException("Mã sinh viên không tồn tại.");
        }
        boolean ok = dao.update(sv);
        if (ok) audit("SUA_SINH_VIEN", "SinhVien", String.format("%s - %s lop %s", sv.getMaSV(), sv.getHoTen(), sv.getMaLop()));
        return ok;
    }

    public boolean delete(String maSV) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Chỉ admin hoặc thủ ký mới được xóa sinh viên.");
        }
        boolean ok = dao.delete(maSV);
        if (ok) audit("XOA_SINH_VIEN", "SinhVien", "Xóa maSV " + maSV);
        return ok;
    }

    private void validateSinhVien(SinhVien sv) {
        if (sv.getMaSV() == null || !MA_SV_PATTERN.matcher(sv.getMaSV()).matches()) {
            throw new IllegalArgumentException("Mã sinh viên không hợp lệ (3-10 ký tự, chữ, số, gạch dưới hoặc gạch ngang).");
        }
        if (sv.getHoTen() == null || sv.getHoTen().isBlank()) {
            throw new IllegalArgumentException("Họ tên không được rỗng.");
        }
        if (sv.getNgaySinh() != null && !sv.getNgaySinh().isBlank()) {
            if (!sv.getNgaySinh().matches("^\\d{4}-\\d{2}-\\d{2}$")) {
                throw new IllegalArgumentException("Ngày sinh không hợp lệ (định dạng yyyy-mm-dd).");
            }
        }
        if (sv.getMaLop() == null || sv.getMaLop().isBlank()) {
            throw new IllegalArgumentException("Mã lớp không được rỗng.");
        }
    }
}
