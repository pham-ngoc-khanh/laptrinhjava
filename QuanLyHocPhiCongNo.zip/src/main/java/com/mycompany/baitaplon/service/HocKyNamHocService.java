package com.mycompany.baitaplon.service;

import com.mycompany.baitaplon.dao.HocKyNamHocDAO;
import com.mycompany.baitaplon.model.HocKyNamHoc;
import com.mycompany.baitaplon.util.UserSession;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class HocKyNamHocService {

    private final HocKyNamHocDAO dao;
    private final AuditService auditService = new AuditService();
    private void audit(String action, String entity, String detail) {
        try { auditService.ghi(action, entity, detail); } catch (Exception ignore) {}
    }

    public HocKyNamHocService() {
        this.dao = new HocKyNamHocDAO();
    }

    public List<HocKyNamHoc> getAll() throws SQLException {
        return dao.getAll();
    }

    public HocKyNamHoc getById(String id) throws SQLException {
        if (id == null) return null;
        List<HocKyNamHoc> all = dao.getAll();
        for (HocKyNamHoc h : all) {
            if (id.equals(h.getMaHKNH())) return h;
        }
        return null;
    }

    public List<HocKyNamHoc> search(String kw) throws SQLException {
        if (kw == null || kw.trim().isEmpty()) {
            return dao.getAll();
        }
        String key = kw.trim().toLowerCase();
        List<HocKyNamHoc> all = dao.getAll();
        List<HocKyNamHoc> result = new ArrayList<>();
        for (HocKyNamHoc h : all) {
            boolean match = false;
            if (h.getMaHKNH() != null && h.getMaHKNH().toLowerCase().contains(key)) match = true;
            if (!match && String.valueOf(h.getHocKy()).contains(key)) match = true;
            if (!match && h.getNamHoc() != null && h.getNamHoc().toLowerCase().contains(key)) match = true;
            if (!match && h.getNgayBatDau() != null && h.getNgayBatDau().toLowerCase().contains(key)) match = true;
            if (!match && h.getNgayKetThuc() != null && h.getNgayKetThuc().toLowerCase().contains(key)) match = true;
            if (match) result.add(h);
        }
        return result;
    }

    public boolean insert(HocKyNamHoc h) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Bạn không có quyền thêm học kỳ năm học.");
        }
        boolean ok = dao.insert(h);
        if (ok) audit("THEM_HOC_KY", "HocKyNamHoc", String.format("%s HK%d - %s", h.getMaHKNH(), h.getHocKy(), h.getNamHoc()));
        return ok;
    }

    public boolean update(HocKyNamHoc h) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Bạn không có quyền cập nhật học kỳ năm học.");
        }
        boolean ok = dao.update(h);
        if (ok) audit("SUA_HOC_KY", "HocKyNamHoc", String.format("%s HK%d - %s", h.getMaHKNH(), h.getHocKy(), h.getNamHoc()));
        return ok;
    }

    public boolean delete(String ma) throws SQLException {
        if (!UserSession.isAdmin() && !UserSession.isThuKy()) {
            throw new IllegalStateException("Bạn không có quyền xóa học kỳ năm học.");
        }
        boolean ok = dao.delete(ma);
        if (ok) audit("XOA_HOC_KY", "HocKyNamHoc", "Xóa " + ma);
        return ok;
    }
}
