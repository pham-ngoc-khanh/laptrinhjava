package com.mycompany.baitaplon;

import com.mycompany.baitaplon.ui.LoginDialog;
import com.mycompany.baitaplon.ui.MainFrame;
import com.mycompany.baitaplon.ui.Theme;
import com.mycompany.baitaplon.util.DatabaseInitializer;
import javax.swing.*;
import java.awt.*;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;

public class Baitaplon {
    public static void main(String[] args) {
        setupGlobalExceptionHandler();
        SwingUtilities.invokeLater(() -> {
            configureSwing();
            try {
                DatabaseInitializer.initialize();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null,
                        "Không thể khởi tạo/kết nối MySQL.\n\n" +
                        "Kiểm tra MySQL Server đang chạy và cấu hình trong:\n" +
                        "src/main/resources/database.properties\n\n" +
                        "Chi tiết: " + shortMessage(e),
                        "Lỗi kết nối cơ sở dữ liệu", JOptionPane.ERROR_MESSAGE);
                return;
            }

            LoginDialog login = new LoginDialog(null);
            login.setVisible(true);
            if (!login.isAuthenticated()) return;
            try {
                MainFrame frame = new MainFrame();
                frame.setVisible(true);
            } catch (Throwable t) {
                showFatalError("Khởi tạo giao diện chính", t);
            }
        });
    }

    private static void setupGlobalExceptionHandler() {
        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            System.err.println("=== UNCAUGHT EXCEPTION on thread " + thread.getName() + " ===");
            throwable.printStackTrace(System.err);
            try {
                if (SwingUtilities.isEventDispatchThread()) {
                    showFatalError("Lỗi không mong muốn trên luồng " + thread.getName(), throwable);
                } else {
                    SwingUtilities.invokeLater(() -> showFatalError("Lỗi không mong muốn trên luồng " + thread.getName(), throwable));
                }
            } catch (Throwable ex) { ex.printStackTrace(); }
        });
    }

    public static void showFatalError(String context, Throwable t) {
        StringWriter sw = new StringWriter();
        t.printStackTrace(new PrintWriter(sw));
        String stack = sw.toString();
        String shortMsg = t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage();
        JOptionPane.showMessageDialog(null,
                "❌ " + context + "\n\n"
                + "• Loại lỗi: " + t.getClass().getSimpleName() + "\n"
                + "• Nội dung: " + shortMsg + "\n\n"
                + "Stack trace:\n" + stack.substring(0, Math.min(3000, stack.length())),
                "Lỗi hệ thống - Vui lòng chụp ảnh và gửi giáo viên",
                JOptionPane.ERROR_MESSAGE);
    }

    private static void configureSwing() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}
        UIManager.put("Label.font", Theme.FONT_BODY);
        UIManager.put("Button.font", Theme.FONT_BODY);
        UIManager.put("OptionPane.messageFont", Theme.FONT_BODY);
        UIManager.put("OptionPane.buttonFont", Theme.FONT_BODY.deriveFont(Font.BOLD));
        UIManager.put("ToolTip.font", Theme.FONT_SMALL);
    }

    private static String shortMessage(Throwable t) {
        String m = t.getMessage();
        if (m == null || m.isBlank()) return t.getClass().getSimpleName();
        return m.length() > 350 ? m.substring(0, 350) + "..." : m;
    }
}
