package com.mycompany.baitaplon.ui;

import com.mycompany.baitaplon.controller.HocPhiController;
import com.mycompany.baitaplon.controller.HocKyNamHocController;
import com.mycompany.baitaplon.controller.SinhVienController;
import com.mycompany.baitaplon.controller.AuditController;
import com.mycompany.baitaplon.controller.DangKyHocPhanController;
import com.mycompany.baitaplon.service.DangKyHocPhanService;
import com.mycompany.baitaplon.controller.NamHocHocPhiController;
import com.mycompany.baitaplon.model.HocPhi;
import com.mycompany.baitaplon.model.HocKyNamHoc;
import com.mycompany.baitaplon.model.SinhVien;
import com.mycompany.baitaplon.util.UserSession;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.math.BigDecimal;
import java.util.List;

public class HocPhiPanel extends JPanel {
    private RoundedCombo<String> cboSV, cboHKNH;
    private RoundedButton bTinh, bLamMoi, bMienGiam;
    private StyledTable table;
    private DefaultTableModel model;
    private JLabel lblGiaHocPhiInfo;
    private final HocPhiController hpService = new HocPhiController();
    private final SinhVienController svService = new SinhVienController();
    private final HocKyNamHocController hkService = new HocKyNamHocController();
    private final AuditController auditService = new AuditController();
    private final NamHocHocPhiController namHocPhiController = new NamHocHocPhiController();
    private final DangKyHocPhanController dangKyService = new DangKyHocPhanController();
    private List<SinhVien> dsSV;
    private List<HocKyNamHoc> dsHK;

    public HocPhiPanel() {
        super(new BorderLayout(14, 14));
        setOpaque(false);
        setBorder(new EmptyBorder(6, 6, 6, 6));
        add(createTopPanel(), BorderLayout.NORTH);
        add(createTablePanel(), BorderLayout.CENTER);
        loadData();
        loadCombos();
    }

    private JLabel makeLbl(String s) { JLabel l = new JLabel(s); l.setFont(Theme.FONT_LABEL); l.setForeground(Theme.TEXT_SECONDARY); return l; }

    private JPanel createTopPanel() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(20, 22, 18, 22));
        card.setTopAccent(Theme.WARNING);
        JPanel p = new JPanel(new WrapLayout(FlowLayout.LEFT, 14, 8)); p.setOpaque(false);

        JPanel g1 = new JPanel(); g1.setLayout(new BoxLayout(g1, BoxLayout.Y_AXIS)); g1.setOpaque(false);
        g1.add(makeLbl("🎓 Sinh viên")); g1.add(Box.createVerticalStrut(4));
        cboSV = new RoundedCombo<>(); UiUtils.makeFlexible(cboSV,200,300,36);
        g1.add(cboSV);

        JPanel g2 = new JPanel(); g2.setLayout(new BoxLayout(g2, BoxLayout.Y_AXIS)); g2.setOpaque(false);
        g2.add(makeLbl("📅 Học kỳ - Năm học")); g2.add(Box.createVerticalStrut(4));
        cboHKNH = new RoundedCombo<>(); UiUtils.makeFlexible(cboHKNH,190,260,36);
        g2.add(cboHKNH);

        bTinh = new RoundedButton("TÍNH HỌC PHÍ", "success");
        bTinh.setPreferredSize(new Dimension(200, 40));
        bLamMoi = new RoundedButton("Làm mới", "warning");
        bLamMoi.setPreferredSize(new Dimension(140, 40));
        bMienGiam = new RoundedButton("Miễn giảm", "purple");
        bMienGiam.setPreferredSize(new Dimension(145, 40));
        bTinh.addActionListener(e -> tinhHocPhi());
        bLamMoi.addActionListener(e -> loadData());
        bMienGiam.addActionListener(e -> capNhatMienGiam());

        p.add(g1); p.add(g2); p.add(Box.createHorizontalStrut(8));
        JPanel bp = new JPanel(); bp.setLayout(new BoxLayout(bp, BoxLayout.Y_AXIS)); bp.setOpaque(false);
        bp.add(Box.createVerticalStrut(18));
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); row.setOpaque(false);
        row.add(bTinh); row.add(bMienGiam); row.add(bLamMoi); bp.add(row);
        p.add(bp);

        card.add(p, BorderLayout.CENTER);
        JPanel wrap = new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(card);
        return wrap;
    }

    private JPanel createTablePanel() {
        JPanel container = new JPanel(new BorderLayout(0, 10)); container.setOpaque(false);

        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(12, 12, 12, 12));
        card.setTopAccent(Theme.DANGER);
        String[] cols = {"Mã HPPhi", "Mã SV", "Họ tên", "Học kỳ", "Tổng TC", "Tổng học phí", "Miễn giảm", "Phải thu", "Ngày tính"};
        model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new StyledTable(); table.setModel(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getColumnModel().getColumn(0).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setPreferredWidth(90);
        table.getColumnModel().getColumn(2).setPreferredWidth(200);
        table.getColumnModel().getColumn(3).setPreferredWidth(150);
        table.getColumnModel().getColumn(4).setPreferredWidth(80);
        table.getColumnModel().getColumn(5).setPreferredWidth(140);
        table.getColumnModel().getColumn(6).setPreferredWidth(110);
        table.getColumnModel().getColumn(7).setPreferredWidth(140);
        table.getColumnModel().getColumn(8).setPreferredWidth(110);
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        sp.getViewport().setOpaque(false); sp.setOpaque(false); UiUtils.tuneScrollPane(sp);
        card.add(sp, BorderLayout.CENTER);
        container.add(card, BorderLayout.CENTER);

        CardPanel infoCard = new CardPanel(new BorderLayout());
        infoCard.setBorder(new EmptyBorder(12, 18, 12, 18));
        infoCard.setTopAccent(Theme.INFO);
        lblGiaHocPhiInfo = new JLabel("<html><b>💡 Thông tin học phí theo năm học:</b> Chọn Sinh viên và Học kỳ rồi nhấn <b>TÍNH HỌC PHÍ</b> để xem chi tiết giá 1 tín chỉ áp dụng cho năm học tương ứng (5 năm học 2025 → 2030 có mức giá khác nhau: 450k → 500k → 550k → 620k → 700k).</html>");
        lblGiaHocPhiInfo.setFont(Theme.FONT_LABEL.deriveFont(Font.PLAIN, 13f));
        lblGiaHocPhiInfo.setForeground(Theme.TEXT_SECONDARY);
        lblGiaHocPhiInfo.setBorder(BorderFactory.createEmptyBorder(2, 4, 2, 4));
        infoCard.add(lblGiaHocPhiInfo, BorderLayout.WEST);
        container.add(infoCard, BorderLayout.SOUTH);

        JPanel wrap = new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(container);
        return wrap;
    }

    private void loadData() {
        try {
            List<HocPhi> list;
            if (UserSession.isSinhVien()) {
                list = hpService.getBySinhVien(UserSession.getMaSV());
            } else {
                list = hpService.getAll();
            }
            model.setRowCount(0);
            for (HocPhi hp : list) model.addRow(new Object[]{hp.getMaHPPhi(), hp.getMaSV(), hp.getHoTenSV(),
                hp.getTenHKNH(), hp.getTongTinChi(), money(hp.getTongHocPhi()), money(hp.getMienGiam()), money(hp.getPhaiThu()), hp.getNgayTinh()});
        } catch (SQLException | IllegalStateException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    public void refreshData() { loadCombos(); loadData(); resetGiaHocPhiInfo(); }

    private void resetGiaHocPhiInfo() {
        if (lblGiaHocPhiInfo == null) return;
        lblGiaHocPhiInfo.setText("<html><b>💡 Thông tin học phí theo năm học:</b> Chọn Sinh viên và Học kỳ rồi nhấn <b>TÍNH HỌC PHÍ</b> để xem chi tiết giá 1 tín chỉ áp dụng cho năm học tương ứng (5 năm học 2025 → 2030 có mức giá khác nhau: 450k → 500k → 550k → 620k → 700k).</html>");
        lblGiaHocPhiInfo.setForeground(Theme.TEXT_SECONDARY);
    }

    public void configureForRole() {
        if (UserSession.isSinhVien()) {
            bTinh.setVisible(false);
            bMienGiam.setVisible(false);
            cboSV.setEnabled(false);
            String maSV = UserSession.getMaSV();
            for (int i = 0; i < cboSV.getItemCount(); i++) {
                if (cboSV.getItemAt(i).startsWith(maSV + " - ")) {
                    cboSV.setSelectedIndex(i);
                    break;
                }
            }
        }
    }

    private void loadCombos() {
        try {
            cboSV.removeAllItems();
            if (UserSession.isSinhVien()) {
                String ma = UserSession.getMaSV();
                SinhVien sv = svService.getById(ma);
                if (sv != null) {
                    dsSV = java.util.Collections.singletonList(sv);
                    cboSV.addItem(sv.getMaSV() + " - " + sv.getHoTen());
                } else dsSV = java.util.Collections.emptyList();
            } else {
                dsSV = svService.getAll();
                for (SinhVien sv : dsSV) cboSV.addItem(sv.getMaSV() + " - " + sv.getHoTen());
            }
            dsHK = hkService.getAll(); cboHKNH.removeAllItems();
            for (HocKyNamHoc hk : dsHK) cboHKNH.addItem(hk.getMaHKNH() + " - " + hk.toString());
        } catch (Exception e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    private String money(BigDecimal value) { return String.format("%,.0f VND", value == null ? BigDecimal.ZERO : value); }

    private void capNhatMienGiam() {
        int row = table.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Chọn một dòng học phí cần cập nhật miễn giảm."); return; }
        String maSV = String.valueOf(model.getValueAt(row, 1));
        String hkDisplay = String.valueOf(model.getValueAt(row, 3));
        String maHK = null;
        try {
            for (HocKyNamHoc hk : hkService.getAll()) {
                String display = "HK " + hk.getHocKy() + " - " + hk.getNamHoc();
                if (display.equals(hkDisplay)) { maHK = hk.getMaHKNH(); break; }
            }
        } catch (SQLException | IllegalStateException e) { JOptionPane.showMessageDialog(this, e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE); return; }
        if (maHK == null) { JOptionPane.showMessageDialog(this, "Không xác định được học kỳ."); return; }
        String input = JOptionPane.showInputDialog(this, "Nhập số tiền miễn/giảm (VND):", "0");
        if (input == null) return;
        try {
            BigDecimal value = new BigDecimal(input.trim().replace(",", ""));
            hpService.updateMienGiam(maSV, maHK, value);
            try { auditService.ghi("MIEN_GIAM_HP", "HocPhi", maSV + " @" + maHK + " = " + value); } catch (Exception ignore) {}
            JOptionPane.showMessageDialog(this, "✅ Đã cập nhật miễn giảm và đồng bộ công nợ.");
            loadData();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Số tiền không hợp lệ.");
        } catch (SQLException | IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void tinhHocPhi() {
        if (cboSV.getSelectedIndex() < 0 || cboHKNH.getSelectedIndex() < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn Sinh viên và Học kỳ"); return;
        }
        String maSV = cboSV.getSelectedItem().toString().split(" - ")[0];
        String maHKNH = cboHKNH.getSelectedItem().toString().split(" - ")[0];
        try {
            if (hpService.tinhHocPhi(maSV, maHKNH)) {
                try { auditService.ghi("TINH_HOC_PHI", "HocPhi", "Tính học phí " + maSV + " @" + maHKNH); } catch (Exception ignore) {}
                loadData();
                capNhatThongTinGiaHocPhi(maSV, maHKNH);
                JOptionPane.showMessageDialog(this, "✅ Tính học phí thành công!");
            } else {
                resetGiaHocPhiInfo();
                JOptionPane.showMessageDialog(this, "⚠ Sinh viên chưa đăng ký học phần nào trong học kỳ này");
            }
        } catch (SQLException | IllegalStateException e) {
            resetGiaHocPhiInfo();
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
        }
    }

    private void capNhatThongTinGiaHocPhi(String maSV, String maHKNH) {
        try {
            String namHoc = null;
            int tongTCKy = dangKyService.getTongTinChiTheoMaHKNH(maSV, maHKNH);
            for (HocKyNamHoc hk : hkService.getAll()) {
                if (hk.getMaHKNH().equals(maHKNH)) { namHoc = hk.getNamHoc(); break; }
            }
            if (namHoc == null) { resetGiaHocPhiInfo(); return; }

            BigDecimal giaMotTC = namHocPhiController.getGiaMotTinChi(namHoc);
            if (giaMotTC == null) {
                lblGiaHocPhiInfo.setText("<html><b style='color:#ef4444'>🚨 Lỗi:</b> Chưa cấu hình học phí 1 tín chỉ cho năm học " + namHoc + ".</html>");
                lblGiaHocPhiInfo.setForeground(Theme.DANGER);
                return;
            }
            int tongTCNam = dangKyService.getTongTinChiTheoNamHoc(maSV, namHoc);
            int maxTC = DangKyHocPhanService.TONG_TIN_CHI_BAT_BUOC_1_NAM;
            BigDecimal tongHPKy = giaMotTC.multiply(BigDecimal.valueOf(tongTCKy));

            StringBuilder sb = new StringBuilder();
            sb.append("<html>");
            sb.append("<b>💡 Chi tiết tính học phí:</b> ");
            sb.append(String.format("• Năm học <b style='color:#2563eb'>%s</b> áp dụng giá 1 tín chỉ = <b style='color:#2563eb'>%,.0f VND</b>. ", namHoc, giaMotTC));
            sb.append(String.format("• Học kỳ này: <b>%d tín chỉ</b> → Tổng học phí kỳ = <b style='color:#dc2626'>%,.0f VND</b> (%,d × %,d). ",
                    tongTCKy, tongHPKy, tongTCKy, giaMotTC.longValue()));

            if (tongTCNam >= maxTC) {
                sb.append(String.format("✅ Tổng tín chỉ cả năm: <b style='color:#10b981'>%d / %d (đủ chuẩn %d tín chỉ)</b>.", tongTCNam, maxTC, maxTC));
                lblGiaHocPhiInfo.setForeground(new Color(16, 185, 129));
            } else {
                int thieu = maxTC - tongTCNam;
                sb.append(String.format("⚠ Tổng tín chỉ cả năm mới <b style='color:#f59e0b'>%d / %d</b> → <b style='color:#f59e0b'>còn thiếu %d tín chỉ</b> để đủ chuẩn %d tín chỉ/năm.",
                        tongTCNam, maxTC, thieu, maxTC));
                lblGiaHocPhiInfo.setForeground(new Color(245, 158, 11));
            }
            sb.append("</html>");
            lblGiaHocPhiInfo.setText(sb.toString());
        } catch (SQLException | IllegalStateException e) {
            lblGiaHocPhiInfo.setText("<html><b style='color:#ef4444'>⚠ Lỗi cập nhật thông tin:</b> " + e.getMessage() + "</html>");
            lblGiaHocPhiInfo.setForeground(Theme.DANGER);
        }
    }
}
