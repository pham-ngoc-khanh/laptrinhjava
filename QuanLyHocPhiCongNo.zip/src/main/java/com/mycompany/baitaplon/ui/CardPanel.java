package com.mycompany.baitaplon.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class CardPanel extends JPanel {
    private int radius = Theme.RADIUS;
    private Color cardBg = Theme.SURFACE;
    private boolean drawShadow = true;
    private Color topAccent = null;

    public CardPanel() {
        super(new BorderLayout(0, 0));
        setOpaque(false);
    }

    public CardPanel(LayoutManager mgr) {
        super(mgr);
        setOpaque(false);
    }

    public void setRadius(int r) { this.radius = r; }
    public void setCardBackground(Color c) { this.cardBg = c; }
    public void setTopAccent(Color c) { this.topAccent = c; }
    public void setDrawShadow(boolean v) { this.drawShadow = v; }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int pad = drawShadow ? Theme.SHADOW_PAD : 0;
        int x = pad, y = pad;
        int w = getWidth() - pad * 2;
        int h = getHeight() - pad * 2;

        if (drawShadow) {
            g2.setColor(new Color(0,0,0, 35));
            g2.fill(new RoundRectangle2D.Float(x, y + 3, w, h, radius, radius));
            g2.setColor(new Color(0,0,0, 15));
            g2.fill(new RoundRectangle2D.Float(x, y + 1, w, h, radius, radius));
        }

        g2.setColor(cardBg);
        g2.fill(new RoundRectangle2D.Float(x, y, w, h, radius, radius));

        if (topAccent != null) {
            g2.setPaint(new GradientPaint(x, y, topAccent, x + w, y, Theme.mix(topAccent, Color.WHITE, 0.7)));
            g2.fill(new RoundRectangle2D.Float(x, y, w, 5, radius, radius));
            g2.fillRect(x, y + 2, w, 3);
        }

        g2.setColor(new Color(255,255,255, 80));
        g2.draw(new RoundRectangle2D.Float(x + 0.5f, y + 0.5f, w - 1, h - 1, radius, radius));

        g2.dispose();
        super.paintComponent(g);
    }
}
