package com.mycompany.baitaplon.ui;

import com.mycompany.baitaplon.controller.AuditController;
import com.mycompany.baitaplon.controller.TaiKhoanController;
import com.mycompany.baitaplon.model.TaiKhoan;
import com.mycompany.baitaplon.util.UserSession;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.sql.SQLException;

public class LoginDialog extends JDialog {
    private RoundedField txtUser;
    private JPasswordField txtPass;
    private boolean authenticated = false;
    private final TaiKhoanController taiKhoanService = new TaiKhoanController();
    private final AuditController auditService = new AuditController();

    public LoginDialog(Frame owner) {
        super(owner, "Đăng nhập", true);
        setUndecorated(true);
        Rectangle usable = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        setSize(Math.min(500, Math.max(420, usable.width - 40)), Math.min(540, Math.max(480, usable.height - 40)));
        setMinimumSize(new Dimension(420, 480));
        setLocationRelativeTo(owner);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setContentPane(buildUI());
    }

    private JPanel buildUI() {
        JPanel root = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(0, 0, 0, 50));
                g2.fill(new RoundRectangle2D.Float(4, 6, getWidth() - 8, getHeight() - 8, 20, 20));
                g2.setColor(Theme.BG);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 20, 20));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        root.setOpaque(false);
        root.setBorder(new EmptyBorder(0, 0, 0, 0));

        JPanel header = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, Theme.PRIMARY, getWidth(), 0, Theme.SECONDARY);
                g2.setPaint(gp);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 20, 20));
                g2.fillRect(0, getHeight() - 20, getWidth(), 20);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        header.setOpaque(false);
        header.setPreferredSize(new Dimension(0, 120));
        header.setBorder(new EmptyBorder(24, 28, 20, 28));

        JLabel logo = new JLabel("🎓");
        logo.setFont(Theme.FONT_ICON.deriveFont(36f));
        logo.setForeground(Color.WHITE);

        JPanel titles = new JPanel();
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
        titles.setOpaque(false);
        JLabel t1 = new JLabel("ĐĂNG NHẬP HỆ THỐNG");
        t1.setFont(Theme.FONT_H2.deriveFont(Font.BOLD, 20f));
        t1.setForeground(Color.WHITE);
        JLabel t2 = new JLabel("Quản lý học phí và công nợ");
        t2.setToolTipText(t2.getText());
        t2.setFont(Theme.FONT_SMALL);
        t2.setForeground(new Color(255, 255, 255, 220));
        titles.add(t1);
        titles.add(Box.createVerticalStrut(4));
        titles.add(t2);

        header.add(logo, BorderLayout.WEST);
        header.add(titles, BorderLayout.CENTER);

        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setOpaque(false);
        body.setBorder(new EmptyBorder(28, 36, 24, 36));

        JLabel lblUser = makeLbl("👤 Tên đăng nhập");
        txtUser = new RoundedField(20);
        txtUser.setPlaceholder("Nhập tên đăng nhập");
        txtUser.setPreferredSize(new Dimension(0, 38));
        txtUser.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        JLabel lblPass = makeLbl("🔒 Mật khẩu");
        txtPass = new JPasswordField();
        txtPass.setFont(Theme.FONT_BODY);
        txtPass.setBorder(new EmptyBorder(8, 12, 8, 12));
        txtPass.setPreferredSize(new Dimension(0, 38));
        txtPass.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));

        RoundedButton btnLogin = new RoundedButton("ĐĂNG NHẬP", "primary");
        btnLogin.setAlignmentX(Component.CENTER_ALIGNMENT);
        btnLogin.setPreferredSize(new Dimension(200, 42));
        btnLogin.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        btnLogin.addActionListener(e -> doLogin());

        JLabel hint = new JLabel("<html><center>Admin: <b>admin</b> / <b>123456</b><br>Thư ký khoa: <b>thuky</b> / <b>123456</b><br>Sinh viên: <b>sv001</b> / <b>123456</b></center></html>");
        hint.setFont(Theme.FONT_SMALL);
        hint.setForeground(Theme.TEXT_MUTED);
        hint.setAlignmentX(Component.CENTER_ALIGNMENT);

        body.add(lblUser);
        body.add(Box.createVerticalStrut(6));
        body.add(txtUser);
        body.add(Box.createVerticalStrut(16));
        body.add(lblPass);
        body.add(Box.createVerticalStrut(6));
        body.add(txtPass);
        body.add(Box.createVerticalStrut(24));
        body.add(btnLogin);
        body.add(Box.createVerticalStrut(16));
        body.add(hint);

        getRootPane().setDefaultButton(btnLogin);
        txtPass.addActionListener(e -> doLogin());

        root.add(header, BorderLayout.NORTH);
        root.add(body, BorderLayout.CENTER);
        return root;
    }

    private JLabel makeLbl(String text) {
        JLabel l = new JLabel(text);
        l.setFont(Theme.FONT_LABEL);
        l.setForeground(Theme.TEXT_SECONDARY);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    private void doLogin() {
        String user = txtUser.getText().trim();
        String pass = new String(txtPass.getPassword());
        if (user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập tên đăng nhập và mật khẩu.", "Thiếu thông tin", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            TaiKhoan tk = taiKhoanService.authenticate(user, pass);
            if (tk == null) {
                try { auditService.ghi("DANG_NHAP", "TaiKhoan", "Thất bại: sai tên đăng nhập hoặc mật khẩu (" + user + ")"); } catch (Exception ignore) {}
                JOptionPane.showMessageDialog(this, "Tên đăng nhập hoặc mật khẩu không đúng.", "Đăng nhập thất bại", JOptionPane.ERROR_MESSAGE);
                txtPass.setText("");
                return;
            }
            if ("Khoa".equalsIgnoreCase(tk.getTrangThai())) {
                try { auditService.ghi("DANG_NHAP", "TaiKhoan", "Thất bại: tài khoản " + user + " đã bị khóa"); } catch (Exception ignore) {}
                JOptionPane.showMessageDialog(this, "Tài khoản đã bị khóa, vui lòng liên hệ quản trị viên.", "Không thể đăng nhập", JOptionPane.WARNING_MESSAGE);
                txtPass.setText("");
                return;
            }
            try { auditService.ghi("DANG_NHAP", "TaiKhoan", "Thành công bởi " + user + " (" + tk.getVaiTro() + ")"); } catch (Exception ignore) {}
            UserSession.set(tk);
            authenticated = true;
            dispose();
        } catch (SQLException | IllegalStateException e) {
            String msg = e.getMessage();
            if (msg != null && msg.toLowerCase().contains("khóa")) {
                try { auditService.ghi("DANG_NHAP", "TaiKhoan", "Thất bại: tài khoản " + user + " khóa (" + msg + ")"); } catch (Exception ignore) {}
                JOptionPane.showMessageDialog(this, "Tài khoản đã bị khóa, vui lòng liên hệ quản trị viên.", "Không thể đăng nhập", JOptionPane.WARNING_MESSAGE);
                txtPass.setText("");
                return;
            }
            try { auditService.ghi("DANG_NHAP", "TaiKhoan", "Lỗi " + user + ": " + msg); } catch (Exception ignore) {}
            JOptionPane.showMessageDialog(this, "Lỗi kết nối CSDL: " + msg, "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isAuthenticated() {
        return authenticated;
    }
}
