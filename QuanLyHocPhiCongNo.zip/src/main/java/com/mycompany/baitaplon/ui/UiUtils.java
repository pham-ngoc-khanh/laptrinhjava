package com.mycompany.baitaplon.ui;

import javax.swing.*;
import java.awt.*;

public final class UiUtils {
    private UiUtils() {}

    public static JScrollPane pageScroll(JComponent content) {
        ScrollablePage page = new ScrollablePage(content);
        JScrollPane sp = new JScrollPane(page,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        sp.setBorder(BorderFactory.createEmptyBorder());
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.getVerticalScrollBar().setUnitIncrement(18);
        sp.getHorizontalScrollBar().setUnitIncrement(18);
        return sp;
    }

    public static void tuneScrollPane(JScrollPane sp) {
        if (sp == null) return;
        sp.getVerticalScrollBar().setUnitIncrement(18);
        sp.getHorizontalScrollBar().setUnitIncrement(18);
        sp.getViewport().setBackground(Color.WHITE);
    }

    public static String htmlWrap(String text, int widthPx) {
        if (text == null) text = "";
        String safe = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
        return "<html><div style='width:" + Math.max(120, widthPx) + "px'>" + safe + "</div></html>";
    }

    public static void makeFlexible(JComponent c, int minWidth, int prefWidth, int height) {
        if (c == null) return;
        c.setMinimumSize(new Dimension(Math.max(1, minWidth), height));
        c.setPreferredSize(new Dimension(Math.max(minWidth, prefWidth), height));
        c.setMaximumSize(new Dimension(Integer.MAX_VALUE, height));
    }
}
