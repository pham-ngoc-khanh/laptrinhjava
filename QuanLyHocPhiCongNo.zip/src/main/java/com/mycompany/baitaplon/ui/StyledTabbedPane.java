package com.mycompany.baitaplon.ui;

import javax.swing.*;
import javax.swing.plaf.ComponentUI;
import javax.swing.plaf.basic.BasicTabbedPaneUI;
import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;

public class StyledTabbedPane extends JTabbedPane {
    public StyledTabbedPane() {
        super();
        setFont(Theme.FONT_H3);
        setBackground(Theme.BG);
        setForeground(Theme.TEXT_SECONDARY);
        setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
        setUI(new BasicTabbedPaneUI() {
            @Override
            protected void paintTabArea(Graphics g, int tabPlacement, int selectedIndex) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Theme.BG);
                g2.fillRect(0, 0, tabPane.getWidth(), calculateTabAreaHeight(tabPlacement, runCount, maxTabHeight));
                g2.dispose();
                super.paintTabArea(g, tabPlacement, selectedIndex);
            }

            @Override
            protected void paintTabBackground(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (isSelected) {
                    GradientPaint gp = new GradientPaint(x, y, Theme.PRIMARY, x, y + h, Theme.PRIMARY_DARK);
                    g2.setPaint(gp);
                    g2.fill(new RoundRectangle2D.Float(x + 4, y + 4, w - 8, h, Theme.RADIUS, Theme.RADIUS));
                } else {
                    g2.setColor(Theme.SURFACE);
                    g2.fill(new RoundRectangle2D.Float(x + 4, y + 6, w - 8, h - 4, Theme.RADIUS, Theme.RADIUS));
                }
                g2.dispose();
            }

            @Override
            protected void paintTabBorder(Graphics g, int tabPlacement, int tabIndex, int x, int y, int w, int h, boolean isSelected) { }

            @Override
            protected void paintText(Graphics g, int tabPlacement, Font font, FontMetrics metrics, int tabIndex, String title, Rectangle textRect, boolean isSelected) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setFont(font.deriveFont(isSelected ? Font.BOLD : Font.PLAIN).deriveFont(13f));
                if (isSelected) g2.setColor(Color.WHITE);
                else g2.setColor(Theme.TEXT_SECONDARY);
                FontMetrics fm = g2.getFontMetrics();
                Rectangle2D sb = fm.getStringBounds(title, g2);
                int tw = fm.stringWidth(title);
                int tx = textRect.x + (textRect.width - tw) / 2;
                int ty = textRect.y + (textRect.height - fm.getHeight()) / 2 + fm.getAscent();
                g2.drawString(title, tx, ty);
                g2.dispose();
            }

            @Override
            protected int calculateTabHeight(int tabPlacement, int tabIndex, int fontHeight) {
                return 44;
            }

            @Override
            protected int calculateTabWidth(int tabPlacement, int tabIndex, FontMetrics metrics) {
                return super.calculateTabWidth(tabPlacement, tabIndex, metrics) + 30;
            }

            @Override protected Insets getTabInsets(int tabPlacement, int tabIndex) {
                return new Insets(2, 14, 2, 14);
            }

            @Override protected void paintContentBorder(Graphics g, int tabPlacement, int selectedIndex) { }
        });
    }
}
