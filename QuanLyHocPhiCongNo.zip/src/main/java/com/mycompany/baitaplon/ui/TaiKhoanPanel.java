package com.mycompany.baitaplon.ui;

import com.mycompany.baitaplon.model.AuditLog;
import com.mycompany.baitaplon.model.TaiKhoan;
import com.mycompany.baitaplon.model.VaiTro;
import com.mycompany.baitaplon.controller.AuditController;
import com.mycompany.baitaplon.controller.TaiKhoanController;
import com.mycompany.baitaplon.util.UserSession;
import com.mycompany.baitaplon.util.InputValidator;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TaiKhoanPanel extends JPanel {
    private final TaiKhoanController tkService = new TaiKhoanController();
    private final AuditController auditService = new AuditController();

    private RoundedField txtTenDN, txtHoTen, txtMaSV, txtSearch;
    private RoundedCombo<String> cboVaiTro, cboTrangThai, cboLocVaiTro, cboLocTrangThai;
    private StyledTable table, auditTable;
    private DefaultTableModel model, auditModel;
    private RoundedButton bThem, bSua, bXoa, bResetMK, bTim, bLamMoi, bAuditSearch;
    private JPanel formPanel;
    private JTabbedPane tabs;

    private int selectedMaTK = -1;

    public TaiKhoanPanel() {
        super(new BorderLayout(14, 14));
        setOpaque(false);
        setBorder(new EmptyBorder(6, 6, 6, 6));

        tabs = new JTabbedPane();
        tabs.setFont(Theme.FONT_LABEL.deriveFont(Font.BOLD, 13f));
        tabs.setBackground(Color.WHITE);
        tabs.setOpaque(true);
        tabs.setBorder(new EmptyBorder(0, 0, 0, 0));

        JPanel tabTaiKhoan = new JPanel(new BorderLayout(10, 10));
        tabTaiKhoan.setOpaque(false);
        tabTaiKhoan.add(createTopPanel(), BorderLayout.NORTH);
        tabTaiKhoan.add(createTablePanel(), BorderLayout.CENTER);
        tabTaiKhoan.add(createButtonPanel(), BorderLayout.SOUTH);

        JPanel tabAudit = new JPanel(new BorderLayout(10, 10));
        tabAudit.setOpaque(false);
        tabAudit.add(createAuditTopPanel(), BorderLayout.NORTH);
        tabAudit.add(createAuditTablePanel(), BorderLayout.CENTER);

        tabs.addTab("👥 Quản lý tài khoản", tabTaiKhoan);
        tabs.addTab("📜 Nhật ký hệ thống", tabAudit);
        add(tabs, BorderLayout.CENTER);

        refreshData();
        loadAuditData();
        configureForRole();
    }

    public void refreshData() {
        loadData();
    }

    public void configureForRole() {
        if (UserSession.isAdmin()) {
            if (bThem != null) { bThem.setVisible(true); bThem.setEnabled(true); }
            if (bSua != null) { bSua.setVisible(true); bSua.setEnabled(true); }
            if (bXoa != null) { bXoa.setVisible(true); bXoa.setEnabled(true); }
            if (bResetMK != null) { bResetMK.setVisible(true); bResetMK.setEnabled(true); }
            if (formPanel != null) formPanel.setVisible(true);
            cboVaiTro.setEnabled(true);
            if (cboVaiTro.getItemCount() < 3) {
                cboVaiTro.removeAllItems();
                cboVaiTro.addItem("SINH_VIEN - Sinh viên");
                cboVaiTro.addItem("THU_KY - Thư ký khoa");
                cboVaiTro.addItem("ADMIN - Quản trị hệ thống");
            }
            if (cboLocVaiTro.getItemCount() < 4) {
                cboLocVaiTro.removeAllItems();
                cboLocVaiTro.addItem("🌐 Tất cả vai trò");
                cboLocVaiTro.addItem("SINH_VIEN - Sinh viên");
                cboLocVaiTro.addItem("THU_KY - Thư ký khoa");
                cboLocVaiTro.addItem("ADMIN - Quản trị hệ thống");
            }
            cboLocVaiTro.setEnabled(true);
        } else if (UserSession.isThuKy()) {
            cboVaiTro.removeAllItems();
            cboVaiTro.addItem("SINH_VIEN - Sinh viên");
            cboVaiTro.setEnabled(false);
            cboLocVaiTro.removeAllItems();
            cboLocVaiTro.addItem("SINH_VIEN - Sinh viên");
            cboLocVaiTro.setEnabled(false);
        } else {
            formPanel.setVisible(false);
            cboVaiTro.setEnabled(false);
            if (bThem != null) bThem.setVisible(false);
            if (bSua != null) bSua.setVisible(false);
            if (bXoa != null) bXoa.setVisible(false);
            if (bResetMK != null) bResetMK.setVisible(false);
        }
        setButtonsBySelectedRole(null);
    }

    private void setButtonsBySelectedRole(VaiTro vt) {
        if (UserSession.isThuKy()) {
            boolean isSV = vt != null && vt == VaiTro.SINH_VIEN;
            if (bSua != null) bSua.setEnabled(isSV);
            if (bXoa != null) bXoa.setEnabled(isSV);
            if (bResetMK != null) bResetMK.setEnabled(isSV);
        }
    }

    private JLabel makeLbl(String s) {
        JLabel l = new JLabel(s);
        l.setFont(Theme.FONT_LABEL);
        l.setForeground(Theme.TEXT_SECONDARY);
        return l;
    }

    private JPanel createTopPanel() {
        JPanel wrapOuter = new JPanel(new BorderLayout(0, 10));
        wrapOuter.setOpaque(false);

        formPanel = new JPanel(new BorderLayout());
        formPanel.setOpaque(false);
        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(20, 24, 18, 24));
        card.setTopAccent(Theme.INFO);

        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 14);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; p.add(makeLbl("Tên đăng nhập"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.4;
        txtTenDN = new RoundedField(18); txtTenDN.setPlaceholder("VD: thuky2, sv999, admin..."); p.add(txtTenDN, gbc);
        gbc.weightx = 0;

        gbc.gridx = 2; gbc.gridy = 0; p.add(makeLbl("Họ và tên"), gbc);
        gbc.gridx = 3; gbc.weightx = 0.6;
        txtHoTen = new RoundedField(22); txtHoTen.setPlaceholder("Họ tên đầy đủ"); p.add(txtHoTen, gbc);
        gbc.weightx = 0;

        gbc.gridx = 0; gbc.gridy = 1; p.add(makeLbl("Vai trò"), gbc);
        gbc.gridx = 1;
        cboVaiTro = new RoundedCombo<>(new String[]{"SINH_VIEN - Sinh viên", "THU_KY - Thư ký khoa", "ADMIN - Quản trị hệ thống"});
        UiUtils.makeFlexible(cboVaiTro, 190, 250, 36);
        p.add(cboVaiTro, gbc);

        gbc.gridx = 2; gbc.gridy = 1; p.add(makeLbl("Mã SV (nếu là Sinh viên)"), gbc);
        gbc.gridx = 3;
        txtMaSV = new RoundedField(18); txtMaSV.setPlaceholder("Bỏ trống nếu TK là Admin/Thư ký"); p.add(txtMaSV, gbc);

        gbc.gridx = 0; gbc.gridy = 2; p.add(makeLbl("Trạng thái"), gbc);
        gbc.gridx = 1;
        cboTrangThai = new RoundedCombo<>(new String[]{"Hoat dong", "Khoa"});
        UiUtils.makeFlexible(cboTrangThai, 160, 220, 36);
        p.add(cboTrangThai, gbc);

        card.add(p, BorderLayout.CENTER);

        JPanel actionBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actionBar.setOpaque(false);
        actionBar.setBorder(new EmptyBorder(8, 0, 0, 0));
        bThem = new RoundedButton("➕ Thêm tài khoản mới", "primary");
        bSua = new RoundedButton("💾 Lưu cập nhật", "purple");
        bXoa = new RoundedButton("🗑 Xóa tài khoản", "danger");
        bResetMK = new RoundedButton("🔑 Đặt MK = 123456", "success");
        Dimension bd = new Dimension(200, 40);
        bThem.setPreferredSize(bd); bSua.setPreferredSize(bd); bXoa.setPreferredSize(new Dimension(210, 40)); bResetMK.setPreferredSize(new Dimension(220, 40));
        bThem.addActionListener(e -> them());
        bSua.addActionListener(e -> sua());
        bXoa.addActionListener(e -> xoa());
        bResetMK.addActionListener(e -> resetMatKhau());
        actionBar.add(bThem); actionBar.add(bSua); actionBar.add(bXoa); actionBar.add(bResetMK);
        card.add(actionBar, BorderLayout.SOUTH);

        formPanel.add(card, BorderLayout.CENTER);
        wrapOuter.add(formPanel, BorderLayout.NORTH);

        CardPanel filterCard = new CardPanel(new BorderLayout());
        filterCard.setBorder(new EmptyBorder(16, 24, 16, 24));
        filterCard.setTopAccent(Theme.PRIMARY);
        JPanel fp = new JPanel(new WrapLayout(FlowLayout.LEFT, 14, 8));
        fp.setOpaque(false);

        JPanel g1 = new JPanel(); g1.setLayout(new BoxLayout(g1, BoxLayout.Y_AXIS)); g1.setOpaque(false);
        g1.add(makeLbl("🔍 Tìm kiếm (Tên DN / Họ tên)")); g1.add(Box.createVerticalStrut(4));
        txtSearch = new RoundedField(28); txtSearch.setPlaceholder("Nhập từ khóa...");
        UiUtils.makeFlexible(txtSearch, 220, 320, 36);
        g1.add(txtSearch);

        JPanel g2 = new JPanel(); g2.setLayout(new BoxLayout(g2, BoxLayout.Y_AXIS)); g2.setOpaque(false);
        g2.add(makeLbl("🎭 Lọc theo Vai trò")); g2.add(Box.createVerticalStrut(4));
        cboLocVaiTro = new RoundedCombo<>(new String[]{"🌐 Tất cả vai trò", "SINH_VIEN - Sinh viên", "THU_KY - Thư ký khoa", "ADMIN - Quản trị hệ thống"});
        UiUtils.makeFlexible(cboLocVaiTro, 180, 240, 36);
        g2.add(cboLocVaiTro);

        JPanel g3 = new JPanel(); g3.setLayout(new BoxLayout(g3, BoxLayout.Y_AXIS)); g3.setOpaque(false);
        g3.add(makeLbl("🔒 Lọc theo Trạng thái")); g3.add(Box.createVerticalStrut(4));
        cboLocTrangThai = new RoundedCombo<>(new String[]{"🌐 Tất cả", "Hoat dong", "Khoa"});
        UiUtils.makeFlexible(cboLocTrangThai, 160, 220, 36);
        g3.add(cboLocTrangThai);

        bTim = new RoundedButton("Áp dụng lọc", "primary");
        bTim.setPreferredSize(new Dimension(140, 40));
        bLamMoi = new RoundedButton("Làm mới", "warning");
        bLamMoi.setPreferredSize(new Dimension(130, 40));
        bTim.addActionListener(e -> loc());
        bLamMoi.addActionListener(e -> { clearForm(); cboLocVaiTro.setSelectedIndex(0); cboLocTrangThai.setSelectedIndex(0); loadData(); });

        fp.add(g1); fp.add(g2); fp.add(g3);
        JPanel bp = new JPanel(); bp.setLayout(new BoxLayout(bp, BoxLayout.Y_AXIS)); bp.setOpaque(false);
        bp.add(Box.createVerticalStrut(18));
        JPanel brow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); brow.setOpaque(false);
        brow.add(bTim); brow.add(bLamMoi);
        bp.add(brow);
        fp.add(bp);

        filterCard.add(fp, BorderLayout.CENTER);
        wrapOuter.add(filterCard, BorderLayout.CENTER);
        return wrapOuter;
    }

    private JPanel createTablePanel() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(16, 14, 16, 14));

        String[] cols = {"Mã TK", "Tên đăng nhập", "Vai trò", "Mã SV", "Họ tên", "Trạng thái"};
        model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new StyledTable();
        table.setModel(model);
        int[] widths = {60, 180, 200, 110, 260, 130};
        for (int i = 0; i < widths.length; i++) table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override public void mouseClicked(java.awt.event.MouseEvent e) { fillForm(); }
        });
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        sp.getViewport().setOpaque(false); sp.setOpaque(false); UiUtils.tuneScrollPane(sp);
        card.add(sp, BorderLayout.CENTER);
        return card;
    }

    private JPanel createButtonPanel() {
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        JLabel tip = new JLabel("💡  Mẹo: Tạo tài khoản Sinh viên cần nhập Mã SV trùng với mã sinh viên đã có trong danh sách.");
        tip.setFont(Theme.FONT_SMALL);
        tip.setForeground(Theme.TEXT_MUTED);
        tip.setBorder(new EmptyBorder(6, 14, 8, 14));
        wrap.add(tip, BorderLayout.WEST);
        return wrap;
    }

    // === Audit tab ===
    private RoundedField txtAuditSearch;
    private JPanel createAuditTopPanel() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(16, 22, 14, 22));
        card.setTopAccent(Theme.WARNING);
        JPanel p = new JPanel(new WrapLayout(FlowLayout.LEFT, 14, 8));
        p.setOpaque(false);
        JPanel g = new JPanel(); g.setLayout(new BoxLayout(g, BoxLayout.Y_AXIS)); g.setOpaque(false);
        g.add(makeLbl("🔍 Tìm nhật ký (người dùng / hành động / chi tiết)")); g.add(Box.createVerticalStrut(4));
        txtAuditSearch = new RoundedField(40); txtAuditSearch.setPlaceholder("VD: admin, DANG_NHAP, THU_KY, sinh viên...");
        UiUtils.makeFlexible(txtAuditSearch, 280, 480, 36);
        g.add(txtAuditSearch);
        bAuditSearch = new RoundedButton("Tìm nhật ký", "primary");
        bAuditSearch.setPreferredSize(new Dimension(150, 40));
        bAuditSearch.addActionListener(e -> locAudit());
        p.add(g);
        JPanel bp = new JPanel(); bp.setLayout(new BoxLayout(bp, BoxLayout.Y_AXIS)); bp.setOpaque(false);
        bp.add(Box.createVerticalStrut(20));
        JPanel bpRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); bpRow.setOpaque(false);
        bpRow.add(bAuditSearch);
        bp.add(bpRow);
        p.add(bp);
        card.add(p, BorderLayout.CENTER);
        return card;
    }

    private JPanel createAuditTablePanel() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(16, 14, 16, 14));
        String[] cols = {"Mã log", "Thời gian", "Mã TK", "Tên đăng nhập", "Hành động", "Đối tượng", "Chi tiết", "Người thực hiện"};
        auditModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        auditTable = new StyledTable();
        auditTable.setModel(auditModel);
        int[] widths = {60, 150, 60, 130, 140, 110, 320, 140};
        for (int i = 0; i < widths.length; i++) auditTable.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        auditTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane sp = new JScrollPane(auditTable);
        sp.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        sp.getViewport().setOpaque(false); sp.setOpaque(false); UiUtils.tuneScrollPane(sp);
        card.add(sp, BorderLayout.CENTER);
        return card;
    }

    // === Logic load/loc ===
    private void loadData() {
        try {
            fillTable(tkService.getAll());
        } catch (SQLException | IllegalStateException e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void fillTable(List<TaiKhoan> list) {
        model.setRowCount(0);
        if (list == null) return;
        for (TaiKhoan tk : list) {
            String vt = tk.getVaiTro() == null ? "" : tk.getVaiTro().name() + " - " + tk.getVaiTro().getTenHienThi();
            model.addRow(new Object[]{
                tk.getMaTK(), tk.getTenDangNhap(), vt,
                tk.getMaSV() == null ? "" : tk.getMaSV(),
                tk.getHoTen(), tk.getTrangThai()
            });
        }
    }

    private void loc() {
        try {
            String kw = txtSearch.getText().trim();
            List<TaiKhoan> list = kw.isEmpty() ? tkService.getAll() : tkService.search(kw);
            String locVT = (String) cboLocVaiTro.getSelectedItem();
            String locTT = (String) cboLocTrangThai.getSelectedItem();
            list = list.stream().filter(tk -> {
                boolean ok = true;
                if (locVT != null && !locVT.startsWith("🌐")) {
                    String ten = locVT.split(" - ")[0];
                    ok &= tk.getVaiTro() != null && ten.equals(tk.getVaiTro().name());
                }
                if (locTT != null && !locTT.startsWith("🌐")) {
                    ok &= locTT.equals(tk.getTrangThai());
                }
                return ok;
            }).toList();
            fillTable(list);
        } catch (SQLException | IllegalStateException e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
        }
    }

    private void fillForm() {
        int row = table.getSelectedRow();
        if (row < 0) { setButtonsBySelectedRole(null); return; }
        try {
            int maTK = Integer.parseInt(String.valueOf(model.getValueAt(row, 0)));
            TaiKhoan tk = tkService.getById(maTK);
            if (tk == null) { setButtonsBySelectedRole(null); return; }
            selectedMaTK = maTK;
            txtTenDN.setText(tk.getTenDangNhap());
            txtHoTen.setText(tk.getHoTen());
            txtMaSV.setText(tk.getMaSV() == null ? "" : tk.getMaSV());
            if (tk.getVaiTro() != null) {
                String label = tk.getVaiTro().name() + " - " + tk.getVaiTro().getTenHienThi();
                boolean found = false;
                for (int i = 0; i < cboVaiTro.getItemCount(); i++) {
                    if (label.equals(cboVaiTro.getItemAt(i))) { cboVaiTro.setSelectedIndex(i); found = true; break; }
                }
                if (!found && UserSession.isThuKy()) {
                    cboVaiTro.setSelectedIndex(0);
                }
            }
            String tt = tk.getTrangThai() == null ? "Hoat dong" : tk.getTrangThai();
            cboTrangThai.setSelectedItem(tt);
            setButtonsBySelectedRole(tk.getVaiTro());
        } catch (SQLException | IllegalStateException e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
            setButtonsBySelectedRole(null);
        }
    }

    private void clearForm() {
        for (RoundedField f : new RoundedField[]{txtTenDN, txtHoTen, txtMaSV, txtSearch}) f.setText("");
        if (cboVaiTro.getItemCount() > 0) cboVaiTro.setSelectedIndex(0);
        if (cboTrangThai.getItemCount() > 0) cboTrangThai.setSelectedIndex(0);
        table.clearSelection(); selectedMaTK = -1;
        setButtonsBySelectedRole(null);
    }

    private TaiKhoan getForm() {
        String tenDN = txtTenDN.getText().trim();
        String hoTen = txtHoTen.getText().trim();
        String maSV = txtMaSV.getText().trim().toUpperCase();
        if (tenDN.isEmpty()) { JOptionPane.showMessageDialog(this, "Nhập Tên đăng nhập"); return null; }
        if (tenDN.length() < 3) { JOptionPane.showMessageDialog(this, "Tên đăng nhập phải ≥ 3 ký tự"); return null; }
        if (hoTen.isEmpty()) { JOptionPane.showMessageDialog(this, "Nhập Họ và tên"); return null; }
        TaiKhoan tk = new TaiKhoan();
        tk.setMaTK(selectedMaTK);
        tk.setTenDangNhap(tenDN.toLowerCase());
        tk.setHoTen(hoTen);
        tk.setMaSV(maSV.isEmpty() ? null : maSV);
        String vt = (String) cboVaiTro.getSelectedItem();
        if (vt != null) {
            VaiTro v = VaiTro.fromDb(vt.split(" - ")[0]);
            tk.setVaiTro(v);
            if (v == VaiTro.SINH_VIEN && (maSV.isEmpty())) {
                JOptionPane.showMessageDialog(this, "Tài khoản Sinh viên cần nhập Mã SV tương ứng.");
                return null;
            }
        }
        tk.setTrangThai((String) cboTrangThai.getSelectedItem());
        return tk;
    }

    private void them() {
        TaiKhoan tk = getForm(); if (tk == null) return;
        try {
            selectedMaTK = -1; tk.setMaTK(-1);
            int ma = tkService.insert(tk);
            if (ma > 0) {
                try { auditService.ghi("THEM_TAIKHOAN", "TaiKhoan", String.format("Tạo tk #%d %s (%s)", ma, tk.getTenDangNhap(), tk.getVaiTro())); } catch (Exception ignore) {}
                String ht = tk.getHoTen() == null ? "" : " - " + tk.getHoTen();
                String vt = tk.getVaiTro() == null ? "" : " (Vai trò: " + tk.getVaiTro().getTenHienThi() + ")";
                String msg = "✅ Đã tạo tài khoản thành công\n"
                    + "• Mã TK: #" + ma + "\n"
                    + "• Tên đăng nhập: " + tk.getTenDangNhap() + ht + "\n"
                    + "• Mật khẩu mặc định: 123456 (không đổi)\n"
                    + vt;
                JOptionPane.showMessageDialog(this, msg, "Thêm tài khoản", JOptionPane.INFORMATION_MESSAGE);
                clearForm(); loadData();
            } else JOptionPane.showMessageDialog(this, "Không thể thêm (có thể tên DN trùng?)");
        } catch (SQLException | IllegalStateException e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
        }
    }

    private void sua() {
        if (selectedMaTK < 0) { JOptionPane.showMessageDialog(this, "Chọn tài khoản cần cập nhật"); return; }
        TaiKhoan tk = getForm(); if (tk == null) return;
        try {
            if (tkService.update(tk)) {
                try { auditService.ghi("SUA_TAIKHOAN", "TaiKhoan", String.format("#%d %s → %s / %s", tk.getMaTK(), tk.getTenDangNhap(), tk.getVaiTro(), tk.getTrangThai())); } catch (Exception ignore) {}
                JOptionPane.showMessageDialog(this, "✅ Cập nhật thành công");
                clearForm(); loadData();
            } else JOptionPane.showMessageDialog(this, "Không cập nhật được");
        } catch (SQLException | IllegalStateException e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
        }
    }

    private void xoa() {
        if (selectedMaTK < 0) { JOptionPane.showMessageDialog(this, "Chọn tài khoản cần xóa"); return; }
        int r = JOptionPane.showConfirmDialog(this, "Xác nhận XÓA tài khoản này?", "Xác nhận", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (r != JOptionPane.YES_OPTION) return;
        try {
            if (tkService.delete(selectedMaTK)) {
                try { auditService.ghi("XOA_TAIKHOAN", "TaiKhoan", String.format("Xóa #%d bởi %s", selectedMaTK, UserSession.getHoTen())); } catch (Exception ignore) {}
                JOptionPane.showMessageDialog(this, "✅ Đã xóa");
                clearForm(); loadData();
            } else JOptionPane.showMessageDialog(this, "Không xóa được");
        } catch (SQLException | IllegalStateException e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage(), "Không thể xóa", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void resetMatKhau() {
        if (selectedMaTK < 0) { JOptionPane.showMessageDialog(this, "Chọn tài khoản cần đặt lại mật khẩu"); return; }
        int confirm = JOptionPane.showConfirmDialog(this, "Đặt mật khẩu về 123456?", "Xác nhận", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;
        try {
            if (tkService.resetPassword(selectedMaTK)) {
                try { auditService.ghi("RESET_MK", "TaiKhoan", String.format("Reset mk #%d bởi %s", selectedMaTK, UserSession.getHoTen())); } catch (Exception ignore) {}
                JOptionPane.showMessageDialog(this, "✅ Mật khẩu mới: 123456");
            } else JOptionPane.showMessageDialog(this, "Không đặt lại được");
        } catch (SQLException | IllegalStateException e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
        }
    }

    // === Audit logic ===
    private void loadAuditData() {
        try {
            fillAuditTable(auditService.getAll());
        } catch (SQLException | IllegalStateException e) {
            JOptionPane.showMessageDialog(this, "Lỗi nạp nhật ký: " + e.getMessage());
        }
    }
    private void fillAuditTable(List<AuditLog> list) {
        auditModel.setRowCount(0);
        if (list == null) return;
        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        for (AuditLog a : list) {
            auditModel.addRow(new Object[]{
                a.getMaLog(),
                a.getThoiGian() == null ? "" : a.getThoiGian().format(fmt),
                a.getMaTK() == null ? "" : a.getMaTK(),
                a.getTenDangNhap() == null ? "" : a.getTenDangNhap(),
                a.getHanhDong() == null ? "" : a.getHanhDong(),
                a.getDoiTuong() == null ? "" : a.getDoiTuong(),
                a.getChiTiet() == null ? "" : a.getChiTiet(),
                a.getNguoiThucHien() == null ? "" : a.getNguoiThucHien()
            });
        }
    }
    private void locAudit() {
        try {
            String kw = txtAuditSearch.getText().trim();
            fillAuditTable(kw.isEmpty() ? auditService.getAll() : auditService.search(kw));
        } catch (SQLException | IllegalStateException e) {
            JOptionPane.showMessageDialog(this, "Lỗi tìm nhật ký: " + e.getMessage());
        }
    }
}
