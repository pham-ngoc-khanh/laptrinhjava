package com.mycompany.baitaplon.ui;

import com.mycompany.baitaplon.controller.CongNoController;
import com.mycompany.baitaplon.controller.HocKyNamHocController;
import com.mycompany.baitaplon.controller.SinhVienController;
import com.mycompany.baitaplon.controller.ThanhToanController;
import com.mycompany.baitaplon.controller.YeuCauThanhToanController;
import com.mycompany.baitaplon.controller.AuditController;
import com.mycompany.baitaplon.model.HocKyNamHoc;
import com.mycompany.baitaplon.model.CongNo;
import com.mycompany.baitaplon.model.SinhVien;
import com.mycompany.baitaplon.model.ThanhToan;
import com.mycompany.baitaplon.model.YeuCauThanhToan;
import com.mycompany.baitaplon.util.UserSession;
import com.mycompany.baitaplon.util.TableExportUtil;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.regex.Pattern;

public class ThanhToanPanel extends JPanel {
    private final ThanhToanController thanhToanService = new ThanhToanController();
    private final YeuCauThanhToanController yeuCauService = new YeuCauThanhToanController();
    private final SinhVienController svService = new SinhVienController();
    private final HocKyNamHocController hocKyService = new HocKyNamHocController();
    private final CongNoController congNoService = new CongNoController();
    private final AuditController auditService = new AuditController();

    private StyledTabbedPane tabs;

    private RoundedCombo<String> cboSvHocKy, cboSvHinhThuc;
    private RoundedField txtSvSoTien, txtSvGhiChu;
    private JLabel lblSvConNo, lblSvPending, lblNoiDungCK, lblSvLatestStatus;
    private RoundedButton btnSvSubmit;
    private JPanel paymentMethodCards;
    private CardLayout paymentMethodLayout;
    private DefaultTableModel requestModel;
    private StyledTable requestTable;

    private DefaultTableModel pendingModel;
    private StyledTable pendingTable;
    private JLabel lblPendingCount;
    private RoundedField txtPendingSearch;
    private TableRowSorter<DefaultTableModel> pendingSorter;

    private RoundedCombo<String> cboAdminSV, cboAdminHK, cboAdminHinhThuc;
    private RoundedField txtAdminSoTien, txtAdminGhiChu;
    private JLabel lblAdminConNo;

    private DefaultTableModel historyModel;
    private StyledTable historyTable;

    private List<SinhVien> dsSV;
    private List<HocKyNamHoc> dsHK;

    public ThanhToanPanel() {
        super(new BorderLayout());
        setOpaque(false);
        setBorder(new EmptyBorder(4, 4, 4, 4));

        tabs = new StyledTabbedPane();
        tabs.setOpaque(false);

        if (UserSession.isSinhVien()) {
            tabs.addTab("Thanh toán học phí", createStudentPaymentTabContainer());
            tabs.addTab("Yêu cầu của tôi", createRequestHistoryTab());
            tabs.addTab("Lịch sử đã xác nhận", createHistoryTab());
        } else {
            tabs.addTab("Chờ xác nhận", createPendingTab());
            tabs.addTab("Ghi nhận trực tiếp", createAdminEntryTab());
            tabs.addTab("Lịch sử thanh toán", createHistoryTab());
        }

        add(tabs, BorderLayout.CENTER);
        loadCombos();
        refreshData();
    }

    public void configureForRole() {
    }

    public void refreshData() {
        loadCombos();
        loadHistory();
        if (UserSession.isSinhVien()) {
            loadStudentRequests();
            updateStudentDebt();
        } else {
            loadPendingRequests();
            updateAdminDebt();
        }
    }

    private JPanel createStudentPaymentTabContainer() {
        JPanel shell = new JPanel(new BorderLayout(0, 8));
        shell.setOpaque(false);
        shell.setBorder(new EmptyBorder(0, 0, 2, 0));
        shell.add(UiUtils.pageScroll(createStudentPaymentTab()), BorderLayout.CENTER);

        CardPanel footer = new CardPanel(new BorderLayout());
        footer.setTopAccent(Theme.SUCCESS);
        footer.setBorder(new EmptyBorder(8, 12, 8, 12));

        JPanel row = new JPanel(new WrapLayout(FlowLayout.RIGHT, 10, 4));
        row.setOpaque(false);
        lblSvLatestStatus = new JLabel("Trạng thái gần nhất: Chưa có yêu cầu thanh toán");
        lblSvLatestStatus.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD));
        lblSvLatestStatus.setForeground(Theme.TEXT_SECONDARY);
        lblSvLatestStatus.setToolTipText(lblSvLatestStatus.getText());

        RoundedButton reload = new RoundedButton("Tải lại trạng thái", "info");
        reload.setPreferredSize(new Dimension(155, 42));
        reload.addActionListener(e -> refreshData());

        btnSvSubmit = new RoundedButton("GỬI XÁC NHẬN ĐÃ THANH TOÁN", "success");
        btnSvSubmit.setPreferredSize(new Dimension(300, 46));
        btnSvSubmit.setToolTipText("Gửi thông báo sang Thư ký để kiểm tra và hoàn tất thanh toán");
        btnSvSubmit.addActionListener(e -> sendStudentPaymentRequest());

        row.add(lblSvLatestStatus);
        row.add(reload);
        row.add(btnSvSubmit);
        footer.add(row, BorderLayout.CENTER);
        shell.add(footer, BorderLayout.SOUTH);
        return shell;
    }

    private JPanel createStudentPaymentTab() {
        JPanel root = new JPanel(new BorderLayout(12, 12));
        root.setOpaque(false);
        root.setBorder(new EmptyBorder(10, 6, 8, 6));

        CardPanel header = new CardPanel(new BorderLayout());
        header.setTopAccent(Theme.SUCCESS);
        header.setBorder(new EmptyBorder(14, 18, 14, 18));
        JPanel headerBody = new JPanel(new WrapLayout(FlowLayout.LEFT, 18, 8));
        headerBody.setOpaque(false);
        JLabel title = new JLabel("<html><b style='font-size:16px'>Thanh toán học phí</b><br>" +
                "<span style='color:#64748b'>Quét QR hoặc chọn tiền mặt. Sau khi hoàn tất, gửi xác nhận để Thư ký kiểm tra.</span></html>");
        title.setFont(Theme.FONT_BODY);
        title.setPreferredSize(new Dimension(500, 48));
        JLabel student = new JLabel(UserSession.getMaSV() + "  •  " + UserSession.getHoTen());
        student.setFont(Theme.FONT_H3);
        student.setForeground(Theme.PRIMARY_DARK);
        student.setToolTipText(student.getText());
        headerBody.add(title); headerBody.add(student);
        header.add(headerBody, BorderLayout.CENTER);
        root.add(header, BorderLayout.NORTH);

        ResponsiveGridPanel body = new ResponsiveGridPanel(2, 320, 12, 12);
        body.setOpaque(false);
        JPanel formCard = createStudentFormCard();
        JPanel method = createPaymentMethodCard();
        formCard.setMinimumSize(new Dimension(320, 500));
        method.setMinimumSize(new Dimension(300, 420));
        body.add(formCard);
        body.add(method);
        root.add(body, BorderLayout.CENTER);
        return root;
    }

    private JPanel createStudentFormCard() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setTopAccent(Theme.PRIMARY);
        card.setBorder(new EmptyBorder(18, 20, 18, 20));

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.weightx = 1;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.anchor = GridBagConstraints.WEST;
        g.insets = new Insets(0, 0, 5, 0);

        int y = 0;
        g.gridy = y++;
        form.add(sectionTitle("Thông tin thanh toán"), g);

        g.gridy = y++;
        form.add(makeLabel("Học kỳ"), g);
        g.gridy = y++;
        cboSvHocKy = new RoundedCombo<>();
        cboSvHocKy.setPreferredSize(new Dimension(100, 38));
        cboSvHocKy.addActionListener(e -> updateStudentDebt());
        form.add(cboSvHocKy, g);

        g.insets = new Insets(4, 0, 5, 0);
        g.gridy = y++;
        form.add(makeLabel("Công nợ hiện tại"), g);
        g.gridy = y++;
        lblSvConNo = debtBadge("Đang tải...");
        form.add(lblSvConNo, g);

        g.gridy = y++;
        lblSvPending = new JLabel("Đang chờ xác nhận: 0 VND");
        lblSvPending.setFont(Theme.FONT_SMALL.deriveFont(Font.BOLD));
        lblSvPending.setForeground(Theme.TEXT_MUTED);
        lblSvPending.setBorder(new EmptyBorder(2, 2, 4, 2));
        form.add(lblSvPending, g);

        g.gridy = y++;
        form.add(makeLabel("Số tiền thanh toán (VND)"), g);
        g.gridy = y++;
        txtSvSoTien = new RoundedField(22);
        txtSvSoTien.setPlaceholder("Ví dụ: 2200000");
        txtSvSoTien.setPreferredSize(new Dimension(100, 38));
        form.add(txtSvSoTien, g);

        g.gridy = y++;
        form.add(makeLabel("Hình thức thanh toán"), g);
        g.gridy = y++;
        cboSvHinhThuc = new RoundedCombo<>(new String[]{"Chuyển khoản (QR)", "Tiền mặt"});
        cboSvHinhThuc.setPreferredSize(new Dimension(100, 38));
        cboSvHinhThuc.addActionListener(e -> updatePaymentMethodCard());
        form.add(cboSvHinhThuc, g);

        g.gridy = y++;
        form.add(makeLabel("Tin nhắn / ghi chú gửi Thư ký"), g);
        g.gridy = y++;
        txtSvGhiChu = new RoundedField(22);
        txtSvGhiChu.setPlaceholder("Ví dụ: Em đã chuyển khoản học phí lúc 14:30");
        txtSvGhiChu.setPreferredSize(new Dimension(100, 38));
        form.add(txtSvGhiChu, g);

        g.gridy = y++;
        g.insets = new Insets(10, 0, 5, 0);
        lblNoiDungCK = new JLabel();
        lblNoiDungCK.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD));
        lblNoiDungCK.setForeground(Theme.TEXT_SECONDARY);
        updateTransferContentLabel();
        form.add(lblNoiDungCK, g);

        g.gridy = y;
        g.weighty = 1;
        form.add(Box.createVerticalGlue(), g);

        card.add(form, BorderLayout.CENTER);
        return card;
    }

    private JPanel createPaymentMethodCard() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setTopAccent(Theme.SECONDARY);
        card.setBorder(new EmptyBorder(14, 14, 14, 14));

        paymentMethodLayout = new CardLayout();
        paymentMethodCards = new JPanel(paymentMethodLayout);
        paymentMethodCards.setOpaque(false);
        paymentMethodCards.add(createQrCard(), "QR");
        paymentMethodCards.add(createCashCard(), "CASH");
        card.add(paymentMethodCards, BorderLayout.CENTER);
        updatePaymentMethodCard();
        return card;
    }

    private JPanel createQrCard() {
        JPanel p = new JPanel(new BorderLayout(6, 8));
        p.setOpaque(false);

        JLabel heading = new JLabel("QUÉT MÃ QR CHUYỂN KHOẢN", SwingConstants.CENTER);
        heading.setFont(Theme.FONT_H3);
        heading.setForeground(Theme.PRIMARY_DARK);
        p.add(heading, BorderLayout.NORTH);

        QrImagePanel imagePanel = new QrImagePanel();
        p.add(imagePanel, BorderLayout.CENTER);

        JLabel note = new JLabel("<html><div style='text-align:center;color:#475569'>" +
                "Mở ứng dụng ngân hàng và quét mã.<br>" +
                "Sau khi giao dịch thành công, bấm <b>Gửi xác nhận</b>." +
                "</div></html>", SwingConstants.CENTER);
        note.setFont(Theme.FONT_SMALL);
        note.setBorder(new EmptyBorder(4, 6, 2, 6));
        p.add(note, BorderLayout.SOUTH);
        return p;
    }

    private JPanel createCashCard() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.gridy = 0;
        g.insets = new Insets(8, 8, 8, 8);
        JLabel icon = new JLabel("TIỀN MẶT", SwingConstants.CENTER);
        icon.setFont(Theme.FONT_H2.deriveFont(26f));
        p.add(icon, g);
        g.gridy++;
        JLabel title = new JLabel("NỘP TIỀN MẶT", SwingConstants.CENTER);
        title.setFont(Theme.FONT_H2);
        title.setForeground(Theme.SUCCESS);
        p.add(title, g);
        g.gridy++;
        JLabel text = new JLabel("<html><div style='width:250px;text-align:center;color:#475569'>" +
                "Nộp tiền trực tiếp tại Phòng Tài vụ/Thư ký khoa. " +
                "Sau khi đã giao tiền, nhập số tiền và bấm <b>Gửi xác nhận</b>. " +
                "Công nợ chỉ được cập nhật khi Thư ký xác nhận đã nhận tiền." +
                "</div></html>", SwingConstants.CENTER);
        text.setFont(Theme.FONT_BODY);
        p.add(text, g);
        return p;
    }

    private JPanel createRequestHistoryTab() {
        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setOpaque(false);
        root.setBorder(new EmptyBorder(10, 6, 8, 6));

        CardPanel card = new CardPanel(new BorderLayout(8, 8));
        card.setTopAccent(Theme.INFO);
        card.setBorder(new EmptyBorder(14, 14, 14, 14));
        JLabel help = new JLabel("<html>Các thông báo thanh toán bạn đã gửi cho Thư ký. Chỉ khi có trạng thái <b>Đã nhận tiền - Hoàn tất</b> thì công nợ mới được cập nhật.</html>");
        help.setFont(Theme.FONT_BODY);
        help.setForeground(Theme.TEXT_SECONDARY);
        card.add(help, BorderLayout.NORTH);

        String[] cols = {"Mã YC", "Học kỳ", "Số tiền", "Hình thức", "Ngày gửi", "Trạng thái", "Ngày xử lý", "Người xử lý", "Lý do / ghi chú"};
        requestModel = readonlyModel(cols);
        requestTable = createScrollableTable(requestModel, new int[]{70, 135, 125, 140, 135, 170, 135, 150, 260});
        card.add(wrapTable(requestTable), BorderLayout.CENTER);

        RoundedButton cancel = new RoundedButton("Hủy yêu cầu đang chờ", "danger");
        cancel.setPreferredSize(new Dimension(190, 40));
        cancel.setToolTipText("Chỉ hủy được yêu cầu chưa được Thư ký xử lý");
        cancel.addActionListener(e -> cancelSelectedStudentRequest());

        RoundedButton reload = new RoundedButton("Tải lại", "info");
        reload.setPreferredSize(new Dimension(120, 40));
        reload.addActionListener(e -> { loadStudentRequests(); updateStudentDebt(); });
        JPanel bp = new JPanel(new WrapLayout(FlowLayout.RIGHT, 8, 4));
        bp.setOpaque(false);
        bp.add(cancel);
        bp.add(reload);
        card.add(bp, BorderLayout.SOUTH);
        root.add(card, BorderLayout.CENTER);
        return root;
    }

    private void sendStudentPaymentRequest() {
        if (cboSvHocKy == null || cboSvHocKy.getSelectedIndex() < 0) {
            showWarn("Vui lòng chọn học kỳ.");
            return;
        }
        String raw = txtSvSoTien.getText().trim().replace(",", "").replace(".", "");
        if (raw.isEmpty()) {
            showWarn("Vui lòng nhập số tiền đã thanh toán.");
            return;
        }
        BigDecimal amount;
        try {
            amount = new BigDecimal(raw);
        } catch (NumberFormatException e) {
            showWarn("Số tiền không hợp lệ. Chỉ nhập chữ số, ví dụ 2200000.");
            return;
        }
        if (amount.signum() <= 0) {
            showWarn("Số tiền phải lớn hơn 0.");
            return;
        }

        String method = cboSvHinhThuc.getSelectedIndex() == 0 ? "Chuyển khoản QR" : "Tiền mặt";
        int ask = JOptionPane.showConfirmDialog(this,
                "Xác nhận bạn đã thanh toán " + money(amount) + " bằng " + method + "?\n\n" +
                "Thông báo sẽ được gửi sang tài khoản Thư ký để kiểm tra.\n" +
                "Công nợ chưa bị trừ cho đến khi Thư ký xác nhận.",
                "Gửi xác nhận thanh toán", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (ask != JOptionPane.YES_OPTION) return;

        YeuCauThanhToan yc = new YeuCauThanhToan();
        yc.setMaSV(UserSession.getMaSV());
        yc.setMaHKNH(code(cboSvHocKy));
        yc.setSoTien(amount);
        yc.setHinhThucThanhToan(method);
        String note = txtSvGhiChu.getText().trim();
        if (note.isEmpty()) note = "Sinh viên báo đã thanh toán.";
        yc.setNoiDung(note);

        try {
            if (yeuCauService.insertYeuCau(yc)) {
                JOptionPane.showMessageDialog(this,
                        "✅ Đã gửi thông báo thanh toán cho Thư ký.\n" +
                        "Bạn có thể theo dõi trạng thái tại tab 'Yêu cầu của tôi'.",
                        "Đã gửi", JOptionPane.INFORMATION_MESSAGE);
                txtSvSoTien.setText("");
                txtSvGhiChu.setText("");
                loadStudentRequests();
                updateStudentDebt();
                tabs.setSelectedIndex(1);
            }
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void loadStudentRequests() {
        if (requestModel == null) return;
        try {
            List<YeuCauThanhToan> list = yeuCauService.getByMaSV(UserSession.getMaSV());
            requestModel.setRowCount(0);
            for (YeuCauThanhToan yc : list) {
                String detail = "TU_CHOI".equals(yc.getTrangThai()) ? safe(yc.getLyDoTuChoi()) : safe(yc.getNoiDung());
                requestModel.addRow(new Object[]{
                        yc.getMaYeuCau(), yc.getTenHKNH(), yc.getSoTien(), yc.getHinhThucThanhToan(),
                        yc.getNgayGui(), yc.getTrangThaiHienThi(), safe(yc.getNgayXuLy()), safe(yc.getNguoiXuLy()), detail
                });
            }
            installMoneyRenderer(requestTable, 2);
            installStatusRenderer(requestTable, 5);
            updateLatestStudentRequestStatus(list);
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void updateLatestStudentRequestStatus(List<YeuCauThanhToan> list) {
        if (lblSvLatestStatus == null) return;
        if (list == null || list.isEmpty()) {
            lblSvLatestStatus.setText("Trạng thái gần nhất: Chưa có yêu cầu thanh toán");
            lblSvLatestStatus.setForeground(Theme.TEXT_SECONDARY);
            lblSvLatestStatus.setToolTipText(lblSvLatestStatus.getText());
            return;
        }
        YeuCauThanhToan yc = list.get(0);
        String suffix = safe(yc.getNgayXuLy()).isBlank() ? "" : " - xử lý " + safe(yc.getNgayXuLy());
        String text = "Gần nhất: #" + yc.getMaYeuCau() + " - " + yc.getTrangThaiHienThi() + suffix;
        lblSvLatestStatus.setText(text);
        lblSvLatestStatus.setToolTipText(text);
        if ("DA_XAC_NHAN".equals(yc.getTrangThai())) lblSvLatestStatus.setForeground(Theme.SUCCESS);
        else if ("TU_CHOI".equals(yc.getTrangThai())) lblSvLatestStatus.setForeground(Theme.DANGER);
        else if ("DA_HUY".equals(yc.getTrangThai())) lblSvLatestStatus.setForeground(Theme.TEXT_MUTED);
        else lblSvLatestStatus.setForeground(Theme.WARNING);
    }

    private void cancelSelectedStudentRequest() {
        int r = requestTable == null ? -1 : requestTable.getSelectedRow();
        if (r < 0) {
            showWarn("Chọn yêu cầu đang chờ cần hủy.");
            return;
        }
        String status = safe(requestModel.getValueAt(r, 5));
        if (!status.contains("Chờ xác nhận")) {
            showWarn("Chỉ có thể hủy yêu cầu đang ở trạng thái Chờ xác nhận.");
            return;
        }
        int id = Integer.parseInt(requestModel.getValueAt(r, 0).toString());
        String amount = money(valueToBigDecimal(requestModel.getValueAt(r, 2)));
        if (JOptionPane.showConfirmDialog(this,
                "Hủy yêu cầu thanh toán #" + id + " (" + amount + ")?\n" +
                "Yêu cầu sẽ không còn xuất hiện trong danh sách chờ của Thư ký.",
                "Hủy yêu cầu", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) != JOptionPane.YES_OPTION) return;
        try {
            if (!yeuCauService.cancelPending(id, UserSession.getMaSV())) {
                showWarn("Yêu cầu đã được Thư ký xử lý hoặc không còn ở trạng thái chờ.");
                return;
            }
            try { auditService.ghi("HUY_YEU_CAU_TT", "YeuCauThanhToan", "Hủy yêu cầu #" + id + " " + amount); } catch (Exception ignore) {}
            JOptionPane.showMessageDialog(this, "Đã hủy yêu cầu thanh toán.");
            loadStudentRequests();
            updateStudentDebt();
        } catch (SQLException e) {
            showError(e);
        }
    }

    private BigDecimal getConLaiByService(String maSV, String maHKNH) throws SQLException {
        List<CongNo> list = congNoService.getBySinhVien(maSV);
        for (CongNo cn : list) {
            if (maHKNH.equals(cn.getMaHKNH())) {
                return cn.getConLai();
            }
        }
        return null;
    }

    private BigDecimal getPendingAmountByService(String maSV, String maHKNH) throws SQLException {
        List<YeuCauThanhToan> list = yeuCauService.getPending();
        BigDecimal total = BigDecimal.ZERO;
        for (YeuCauThanhToan yc : list) {
            if (maSV.equals(yc.getMaSV()) && maHKNH.equals(yc.getMaHKNH())) {
                if (yc.getSoTien() != null) {
                    total = total.add(yc.getSoTien());
                }
            }
        }
        return total;
    }

    private void updateStudentDebt() {
        updateTransferContentLabel();
        if (lblSvConNo == null || cboSvHocKy == null || cboSvHocKy.getSelectedIndex() < 0) {
            if (btnSvSubmit != null) btnSvSubmit.setEnabled(false);
            if (txtSvSoTien != null) txtSvSoTien.setEnabled(false);
            return;
        }
        try {
            String maHK = code(cboSvHocKy);
            BigDecimal conLai = getConLaiByService(UserSession.getMaSV(), maHK);
            BigDecimal dangCho = getPendingAmountByService(UserSession.getMaSV(), maHK);

            if (conLai == null) {
                lblSvConNo.setText("Chưa có dữ liệu công nợ cho học kỳ này");
                lblSvConNo.setForeground(Theme.TEXT_MUTED);
                if (lblSvPending != null) {
                    lblSvPending.setText("Hãy kiểm tra Học phần / Học phí trước khi thanh toán.");
                    lblSvPending.setForeground(Theme.TEXT_MUTED);
                }
                if (btnSvSubmit != null) btnSvSubmit.setEnabled(false);
                if (txtSvSoTien != null) txtSvSoTien.setEnabled(false);
                return;
            }

            if (conLai.signum() <= 0) {
                lblSvConNo.setText("Đã thanh toán đủ - Còn lại: 0 VND");
                lblSvConNo.setForeground(Theme.SUCCESS);
                if (lblSvPending != null) {
                    lblSvPending.setText("Không cần gửi thêm thanh toán.");
                    lblSvPending.setForeground(Theme.SUCCESS);
                }
                if (btnSvSubmit != null) btnSvSubmit.setEnabled(false);
                if (txtSvSoTien != null) txtSvSoTien.setEnabled(false);
                return;
            }

            BigDecimal coTheGui = conLai.subtract(dangCho).max(BigDecimal.ZERO);
            lblSvConNo.setText("Còn phải nộp: " + money(conLai));
            lblSvConNo.setForeground(Theme.DANGER);
            if (lblSvPending != null) {
                if (dangCho.signum() > 0) {
                    lblSvPending.setText("Đang chờ xác nhận: " + money(dangCho) +
                            "  |  Có thể gửi thêm: " + money(coTheGui));
                    lblSvPending.setForeground(coTheGui.signum() > 0 ? Theme.WARNING : Theme.SUCCESS);
                } else {
                    lblSvPending.setText("Chưa có khoản nào đang chờ xác nhận.");
                    lblSvPending.setForeground(Theme.TEXT_MUTED);
                }
            }
            boolean canSend = coTheGui.signum() > 0;
            if (btnSvSubmit != null) btnSvSubmit.setEnabled(canSend);
            if (txtSvSoTien != null) txtSvSoTien.setEnabled(canSend);
        } catch (SQLException e) {
            lblSvConNo.setText("Không đọc được công nợ");
            lblSvConNo.setForeground(Theme.DANGER);
            if (lblSvPending != null) lblSvPending.setText("Không đọc được trạng thái yêu cầu thanh toán.");
            if (btnSvSubmit != null) btnSvSubmit.setEnabled(false);
            if (txtSvSoTien != null) txtSvSoTien.setEnabled(false);
        }
    }

    private void updatePaymentMethodCard() {
        if (paymentMethodLayout == null || paymentMethodCards == null || cboSvHinhThuc == null) return;
        paymentMethodLayout.show(paymentMethodCards, cboSvHinhThuc.getSelectedIndex() == 0 ? "QR" : "CASH");
    }

    private void updateTransferContentLabel() {
        if (lblNoiDungCK == null) return;
        String maSV = safe(UserSession.getMaSV());
        lblNoiDungCK.setText("Nội dung chuyển khoản:  " + maSV + " HOC PHI");
    }

    private JPanel createPendingTab() {
        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setOpaque(false);
        root.setBorder(new EmptyBorder(10, 6, 8, 6));

        CardPanel card = new CardPanel(new BorderLayout(10, 10));
        card.setTopAccent(Theme.WARNING);
        card.setBorder(new EmptyBorder(14, 14, 14, 14));

        JPanel topWrap = new JPanel(new BorderLayout(8, 8));
        topWrap.setOpaque(false);

        JPanel top = new JPanel(new WrapLayout(FlowLayout.LEFT, 18, 6));
        top.setOpaque(false);
        JLabel title = new JLabel("Yêu cầu sinh viên báo đã thanh toán");
        title.setFont(Theme.FONT_H2);
        title.setForeground(Theme.TEXT);
        lblPendingCount = new JLabel("0 yêu cầu chờ xác nhận");
        lblPendingCount.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD));
        lblPendingCount.setForeground(Theme.WARNING);
        top.add(title);
        top.add(lblPendingCount);
        txtPendingSearch = new RoundedField(18);
        txtPendingSearch.setPlaceholder("Tìm MSSV / họ tên...");
        txtPendingSearch.setPreferredSize(new Dimension(250, 36));
        top.add(txtPendingSearch);

        JPanel actions = new JPanel(new WrapLayout(FlowLayout.RIGHT, 8, 4));
        actions.setOpaque(false);
        RoundedButton reload = new RoundedButton("Tải lại", "info");
        RoundedButton reject = new RoundedButton("Từ chối", "danger");
        RoundedButton confirm = new RoundedButton("ĐÃ NHẬN TIỀN & HOÀN TẤT", "success");
        reload.setPreferredSize(new Dimension(110, 40));
        reject.setPreferredSize(new Dimension(120, 40));
        confirm.setPreferredSize(new Dimension(245, 40));
        reload.addActionListener(e -> loadPendingRequests());
        reject.addActionListener(e -> rejectSelectedRequest());
        confirm.addActionListener(e -> confirmSelectedRequest());
        actions.add(reload);
        actions.add(reject);
        actions.add(confirm);

        topWrap.add(top, BorderLayout.NORTH);
        topWrap.add(actions, BorderLayout.SOUTH);
        card.add(topWrap, BorderLayout.NORTH);

        String[] cols = {"Mã YC", "Mã SV", "Họ tên", "Học kỳ", "Số tiền", "Hình thức", "Ngày gửi", "Tin nhắn"};
        pendingModel = readonlyModel(cols);
        pendingTable = createScrollableTable(pendingModel, new int[]{70, 90, 180, 135, 125, 140, 135, 280});
        pendingSorter = new TableRowSorter<>(pendingModel);
        pendingTable.setRowSorter(pendingSorter);
        if (txtPendingSearch != null) {
            txtPendingSearch.getDocument().addDocumentListener(new DocumentListener() {
                private void apply() { filterPendingTable(); }
                @Override public void insertUpdate(DocumentEvent e) { apply(); }
                @Override public void removeUpdate(DocumentEvent e) { apply(); }
                @Override public void changedUpdate(DocumentEvent e) { apply(); }
            });
        }
        card.add(wrapTable(pendingTable), BorderLayout.CENTER);

        root.add(card, BorderLayout.CENTER);
        return root;
    }

    private JPanel createAdminEntryTab() {
        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setOpaque(false);
        root.setBorder(new EmptyBorder(10, 6, 8, 6));

        CardPanel card = new CardPanel(new BorderLayout(12, 12));
        card.setTopAccent(Theme.SUCCESS);
        card.setBorder(new EmptyBorder(18, 20, 18, 20));

        JLabel title = new JLabel("Ghi nhận thanh toán trực tiếp");
        title.setFont(Theme.FONT_H2);
        title.setForeground(Theme.TEXT);
        card.add(title, BorderLayout.NORTH);

        ResponsiveGridPanel grid = new ResponsiveGridPanel(2, 290, 16, 12);
        grid.setOpaque(false);

        cboAdminSV = new RoundedCombo<>();
        cboAdminSV.addActionListener(e -> updateAdminDebt());
        grid.add(fieldGroup("Sinh viên", cboAdminSV));

        cboAdminHK = new RoundedCombo<>();
        cboAdminHK.addActionListener(e -> updateAdminDebt());
        grid.add(fieldGroup("Học kỳ", cboAdminHK));

        txtAdminSoTien = new RoundedField(20);
        txtAdminSoTien.setPlaceholder("Ví dụ: 1500000");
        grid.add(fieldGroup("Số tiền (VND)", txtAdminSoTien));

        cboAdminHinhThuc = new RoundedCombo<>(new String[]{"Tiền mặt", "Chuyển khoản", "Khác"});
        grid.add(fieldGroup("Hình thức", cboAdminHinhThuc));

        txtAdminGhiChu = new RoundedField(20);
        txtAdminGhiChu.setPlaceholder("Ghi chú (nếu có)");
        grid.add(fieldGroup("Ghi chú", txtAdminGhiChu));

        lblAdminConNo = debtBadge("Chọn sinh viên và học kỳ");
        grid.add(fieldGroup("Công nợ còn lại", lblAdminConNo));

        card.add(grid, BorderLayout.CENTER);

        JPanel bp = new JPanel(new WrapLayout(FlowLayout.RIGHT, 8, 6));
        bp.setOpaque(false);
        RoundedButton clear = new RoundedButton("Làm mới", "warning");
        RoundedButton save = new RoundedButton("LƯU PHIẾU THANH TOÁN", "success");
        clear.setPreferredSize(new Dimension(140, 42));
        save.setPreferredSize(new Dimension(235, 42));
        clear.addActionListener(e -> clearAdminForm());
        save.addActionListener(e -> saveAdminPayment());
        bp.add(clear);
        bp.add(save);
        card.add(bp, BorderLayout.SOUTH);

        root.add(card, BorderLayout.NORTH);

        JLabel hint = new JLabel("<html><div style='color:#64748b'>Dùng mục này khi Thư ký nhận tiền trực tiếp hoặc tự đối soát giao dịch. " +
                "Nếu sinh viên đã gửi thông báo, nên xử lý ở tab <b>Chờ xác nhận</b> để tránh ghi nhận trùng.</div></html>");
        hint.setFont(Theme.FONT_BODY);
        hint.setBorder(new EmptyBorder(4, 10, 0, 10));
        root.add(hint, BorderLayout.CENTER);
        return root;
    }

    private void filterPendingTable() {
        if (pendingSorter == null || txtPendingSearch == null) return;
        String q = txtPendingSearch.getText() == null ? "" : txtPendingSearch.getText().trim();
        if (q.isEmpty()) {
            pendingSorter.setRowFilter(null);
        } else {
            pendingSorter.setRowFilter(RowFilter.regexFilter("(?i)" + Pattern.quote(q), 1, 2, 3, 5, 7));
        }
    }

    private void loadPendingRequests() {
        if (pendingModel == null) return;
        try {
            List<YeuCauThanhToan> list = yeuCauService.getPending();
            pendingModel.setRowCount(0);
            for (YeuCauThanhToan yc : list) {
                pendingModel.addRow(new Object[]{
                        yc.getMaYeuCau(), yc.getMaSV(), yc.getHoTenSV(), yc.getTenHKNH(), yc.getSoTien(),
                        yc.getHinhThucThanhToan(), yc.getNgayGui(), safe(yc.getNoiDung())
                });
            }
            installMoneyRenderer(pendingTable, 4);
            int count = list.size();
            lblPendingCount.setText(count + " yêu cầu chờ xác nhận");
            lblPendingCount.setForeground(count > 0 ? Theme.DANGER : Theme.SUCCESS);
            tabs.setTitleAt(0, "Chờ xác nhận" + (count > 0 ? " (" + count + ")" : ""));
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void confirmSelectedRequest() {
        int viewRow = pendingTable.getSelectedRow();
        if (viewRow < 0) {
            showWarn("Chọn một yêu cầu cần xác nhận.");
            return;
        }
        int r = pendingTable.convertRowIndexToModel(viewRow);
        int id = Integer.parseInt(pendingModel.getValueAt(r, 0).toString());
        String maSV = safe(pendingModel.getValueAt(r, 1));
        String hoTen = safe(pendingModel.getValueAt(r, 2));
        String amount = money(valueToBigDecimal(pendingModel.getValueAt(r, 4)));
        String method = safe(pendingModel.getValueAt(r, 5));

        int ask = JOptionPane.showConfirmDialog(this,
                "Xác nhận đã nhận tiền từ sinh viên:\n\n" +
                maSV + " - " + hoTen + "\nSố tiền: " + amount + "\nHình thức: " + method + "\n\n" +
                "Sau khi hoàn tất, hệ thống sẽ tự tạo phiếu thu, cập nhật công nợ và trả trạng thái về tài khoản sinh viên.",
                "Xác nhận thanh toán", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (ask != JOptionPane.YES_OPTION) return;

        try {
            yeuCauService.xacNhanThanhToan(id, "DA_XAC_NHAN", null);
            try { auditService.ghi("XAC_NHAN_THANH_TOAN", "YeuCauThanhToan", "Xác nhận #" + id + " " + maSV + " - " + hoTen + " " + amount); } catch (Exception ignore) {}
            JOptionPane.showMessageDialog(this, "ĐÃ HOÀN TẤT: đã nhận tiền, tạo phiếu thanh toán, cập nhật công nợ và trạng thái sinh viên.");
            refreshData();
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void rejectSelectedRequest() {
        int viewRow = pendingTable.getSelectedRow();
        if (viewRow < 0) {
            showWarn("Chọn một yêu cầu cần từ chối.");
            return;
        }
        int r = pendingTable.convertRowIndexToModel(viewRow);
        int id = Integer.parseInt(pendingModel.getValueAt(r, 0).toString());
        String reason = JOptionPane.showInputDialog(this,
                "Nhập lý do từ chối (ví dụ: chưa thấy giao dịch / sai số tiền):",
                "Từ chối yêu cầu", JOptionPane.QUESTION_MESSAGE);
        if (reason == null) return;
        if (reason.trim().isEmpty()) {
            showWarn("Vui lòng nhập lý do từ chối.");
            return;
        }
        try {
            yeuCauService.xacNhanThanhToan(id, "TU_CHOI", reason.trim());
            try { auditService.ghi("TU_CHOI_THANH_TOAN", "YeuCauThanhToan", "Từ chối #" + id + " Lý do: " + reason.trim()); } catch (Exception ignore) {}
            JOptionPane.showMessageDialog(this, "Đã từ chối yêu cầu và gửi trạng thái về phía sinh viên.");
            refreshData();
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void saveAdminPayment() {
        if (cboAdminSV.getSelectedIndex() < 0 || cboAdminHK.getSelectedIndex() < 0) {
            showWarn("Vui lòng chọn sinh viên và học kỳ.");
            return;
        }
        String raw = txtAdminSoTien.getText().trim().replace(",", "").replace(".", "");
        BigDecimal amount;
        try {
            amount = new BigDecimal(raw);
        } catch (Exception e) {
            showWarn("Số tiền không hợp lệ.");
            return;
        }

        ThanhToan tt = new ThanhToan();
        tt.setMaSV(code(cboAdminSV));
        tt.setMaHKNH(code(cboAdminHK));
        tt.setSoTien(amount);
        tt.setHinhThucThanhToan(cboAdminHinhThuc.getSelectedItem().toString());
        tt.setNgayThanhToan(LocalDate.now().toString());
        tt.setNguoiThu(UserSession.getHoTen());
        tt.setGhiChu(txtAdminGhiChu.getText().trim());

        try {
            if (thanhToanService.insert(tt)) {
                try { auditService.ghi("THU_THANH_TOAN", "ThanhToan", "Thu " + tt.getMaSV() + " " + money(amount) + " " + tt.getHinhThucThanhToan()); } catch (Exception ignore) {}
                JOptionPane.showMessageDialog(this, "✅ Đã ghi nhận thanh toán và cập nhật công nợ.");
                clearAdminForm();
                refreshData();
            }
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void clearAdminForm() {
        if (txtAdminSoTien != null) txtAdminSoTien.setText("");
        if (txtAdminGhiChu != null) txtAdminGhiChu.setText("");
        if (cboAdminHinhThuc != null) cboAdminHinhThuc.setSelectedIndex(0);
        updateAdminDebt();
    }

    private void updateAdminDebt() {
        if (lblAdminConNo == null || cboAdminSV == null || cboAdminHK == null ||
                cboAdminSV.getSelectedIndex() < 0 || cboAdminHK.getSelectedIndex() < 0) return;
        try {
            BigDecimal conLai = getConLaiByService(code(cboAdminSV), code(cboAdminHK));
            if (conLai == null) {
                lblAdminConNo.setText("Chưa có công nợ");
                lblAdminConNo.setForeground(Theme.TEXT_MUTED);
            } else {
                lblAdminConNo.setText(money(conLai));
                lblAdminConNo.setForeground(conLai.signum() > 0 ? Theme.DANGER : Theme.SUCCESS);
            }
        } catch (SQLException e) {
            lblAdminConNo.setText("Không đọc được công nợ");
            lblAdminConNo.setForeground(Theme.DANGER);
        }
    }

    private JPanel createHistoryTab() {
        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setOpaque(false);
        root.setBorder(new EmptyBorder(10, 6, 8, 6));

        CardPanel card = new CardPanel(new BorderLayout(8, 8));
        card.setTopAccent(Theme.PRIMARY);
        card.setBorder(new EmptyBorder(14, 14, 14, 14));

        JLabel title = new JLabel("<html>" + (UserSession.isSinhVien() ? "Các khoản đã được Thư ký xác nhận" : "Toàn bộ phiếu thanh toán đã ghi nhận") + "</html>");
        title.setFont(Theme.FONT_H2);
        title.setForeground(Theme.TEXT);
        card.add(title, BorderLayout.NORTH);

        String[] cols = {"Mã TT", "Mã SV", "Họ tên", "Học kỳ", "Số tiền", "Hình thức", "Ngày TT", "Người thu", "Ghi chú"};
        historyModel = readonlyModel(cols);
        historyTable = createScrollableTable(historyModel, new int[]{75, 90, 180, 135, 125, 135, 105, 150, 260});
        card.add(wrapTable(historyTable), BorderLayout.CENTER);

        RoundedButton export = new RoundedButton("Xuất CSV", "success");
        export.setPreferredSize(new Dimension(120, 40));
        export.addActionListener(e -> TableExportUtil.exportCsv(this, historyTable, "lich-su-thanh-toan"));

        RoundedButton reload = new RoundedButton("Tải lại", "info");
        reload.setPreferredSize(new Dimension(120, 40));
        reload.addActionListener(e -> loadHistory());
        JPanel bp = new JPanel(new WrapLayout(FlowLayout.RIGHT, 8, 4));
        bp.setOpaque(false);
        bp.add(export);
        bp.add(reload);
        card.add(bp, BorderLayout.SOUTH);

        root.add(card, BorderLayout.CENTER);
        return root;
    }

    private void loadHistory() {
        if (historyModel == null) return;
        try {
            List<ThanhToan> list = UserSession.isSinhVien()
                    ? thanhToanService.getByMaSV(UserSession.getMaSV())
                    : thanhToanService.getAll();
            historyModel.setRowCount(0);
            for (ThanhToan tt : list) {
                historyModel.addRow(new Object[]{
                        tt.getMaThanhToan(), tt.getMaSV(), tt.getHoTenSV(), tt.getTenHKNH(), tt.getSoTien(),
                        tt.getHinhThucThanhToan(), tt.getNgayThanhToan(), tt.getNguoiThu(), tt.getGhiChu()
                });
            }
            installMoneyRenderer(historyTable, 4);
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void loadCombos() {
        try {
            dsHK = hocKyService.getAll();
            if (UserSession.isSinhVien()) {
                String keepHK = selectedCode(cboSvHocKy);
                if (cboSvHocKy != null) {
                    cboSvHocKy.removeAllItems();
                    for (HocKyNamHoc hk : dsHK) {
                        cboSvHocKy.addItem(hk.getMaHKNH() + " - HK " + hk.getHocKy() + " - " + hk.getNamHoc());
                    }
                    restoreSelection(cboSvHocKy, keepHK);
                    if (keepHK == null || keepHK.isBlank()) selectStudentOutstandingTerm();
                }
            } else {
                dsSV = svService.getAll();
                String keepSV = selectedCode(cboAdminSV);
                String keepHK = selectedCode(cboAdminHK);
                if (cboAdminSV != null) {
                    cboAdminSV.removeAllItems();
                    for (SinhVien sv : dsSV) cboAdminSV.addItem(sv.getMaSV() + " - " + sv.getHoTen());
                    restoreSelection(cboAdminSV, keepSV);
                }
                if (cboAdminHK != null) {
                    cboAdminHK.removeAllItems();
                    for (HocKyNamHoc hk : dsHK) {
                        cboAdminHK.addItem(hk.getMaHKNH() + " - HK " + hk.getHocKy() + " - " + hk.getNamHoc());
                    }
                    restoreSelection(cboAdminHK, keepHK);
                }
            }
        } catch (Exception e) {
            showError(e);
        }
    }

    private void selectStudentOutstandingTerm() {
        if (cboSvHocKy == null) return;
        try {
            for (CongNo cn : congNoService.getBySinhVien(UserSession.getMaSV())) {
                if (cn.getConLai() != null && cn.getConLai().signum() > 0) {
                    String ma = cn.getMaHKNH();
                    for (int i = 0; i < cboSvHocKy.getItemCount(); i++) {
                        if (cboSvHocKy.getItemAt(i).startsWith(ma + " - ")) {
                            cboSvHocKy.setSelectedIndex(i);
                            return;
                        }
                    }
                }
            }
        } catch (SQLException ignored) {
        }
    }

    private JPanel fieldGroup(String label, JComponent component) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        JLabel l = makeLabel(label);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        component.setAlignmentX(Component.LEFT_ALIGNMENT);
        component.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        component.setMinimumSize(new Dimension(140, 38));
        if (component.getPreferredSize().width < 180) component.setPreferredSize(new Dimension(180, 38));
        p.add(l);
        p.add(Box.createVerticalStrut(5));
        p.add(component);
        return p;
    }

    private JLabel makeLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(Theme.FONT_LABEL);
        l.setForeground(Theme.TEXT_SECONDARY);
        return l;
    }

    private JLabel sectionTitle(String text) {
        JLabel l = new JLabel(text);
        l.setFont(Theme.FONT_H2);
        l.setForeground(Theme.TEXT);
        l.setBorder(new EmptyBorder(0, 0, 8, 0));
        return l;
    }

    private JLabel debtBadge(String text) {
        JLabel l = new JLabel(text);
        l.setOpaque(true);
        l.setBackground(Theme.SURFACE_ALT);
        l.setBorder(new EmptyBorder(9, 12, 9, 12));
        l.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD));
        l.setForeground(Theme.TEXT_SECONDARY);
        l.setPreferredSize(new Dimension(180, 38));
        l.setMinimumSize(new Dimension(140, 38));
        l.setToolTipText(text);
        return l;
    }

    private DefaultTableModel readonlyModel(String[] cols) {
        return new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
    }

    private StyledTable createScrollableTable(DefaultTableModel model, int[] widths) {
        StyledTable table = new StyledTable();
        table.setModel(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        for (int i = 0; i < widths.length && i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
            table.getColumnModel().getColumn(i).setMinWidth(Math.min(widths[i], 60));
        }
        return table;
    }

    private JScrollPane wrapTable(JTable table) {
        JScrollPane sp = new JScrollPane(table,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        sp.setBorder(BorderFactory.createEmptyBorder(4, 0, 4, 0));
        sp.getViewport().setBackground(Color.WHITE);
        UiUtils.tuneScrollPane(sp);
        return sp;
    }

    private void installMoneyRenderer(JTable table, int column) {
        if (table == null || column < 0 || column >= table.getColumnCount()) return;
        table.getColumnModel().getColumn(column).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object value, boolean selected, boolean focus, int row, int col) {
                Component c = super.getTableCellRendererComponent(t,
                        value instanceof BigDecimal ? money((BigDecimal) value) : value,
                        selected, focus, row, col);
                setHorizontalAlignment(SwingConstants.RIGHT);
                return c;
            }
        });
    }

    private void installStatusRenderer(JTable table, int column) {
        if (table == null || column < 0 || column >= table.getColumnCount()) return;
        table.getColumnModel().getColumn(column).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object value, boolean selected, boolean focus, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, value, selected, focus, row, col);
                setFont(Theme.FONT_BODY.deriveFont(Font.BOLD));
                if (!selected) {
                    setForeground(Theme.TEXT);
                    String s = safe(value);
                    if (s.contains("Hoàn tất") || s.contains("Đã nhận tiền")) setForeground(Theme.SUCCESS);
                    else if (s.contains("Từ chối")) setForeground(Theme.DANGER);
                    else if (s.contains("Đã hủy")) setForeground(Theme.TEXT_MUTED);
                    else if (!s.isEmpty()) setForeground(Theme.WARNING);
                }
                return c;
            }
        });
    }

    private String code(RoundedCombo<String> combo) {
        if (combo == null || combo.getSelectedItem() == null) return "";
        return combo.getSelectedItem().toString().split(" - ")[0].trim();
    }

    private String selectedCode(RoundedCombo<String> combo) {
        return combo == null || combo.getSelectedItem() == null ? "" : code(combo);
    }

    private void restoreSelection(RoundedCombo<String> combo, String code) {
        if (combo == null || code == null || code.isBlank()) return;
        for (int i = 0; i < combo.getItemCount(); i++) {
            if (combo.getItemAt(i).startsWith(code + " - ")) {
                combo.setSelectedIndex(i);
                return;
            }
        }
    }

    private static String money(BigDecimal value) {
        return value == null ? "0 VND" : String.format("%,.0f VND", value);
    }

    private static BigDecimal valueToBigDecimal(Object value) {
        if (value instanceof BigDecimal b) return b;
        if (value == null) return BigDecimal.ZERO;
        try { return new BigDecimal(value.toString().replace(",", "")); }
        catch (Exception e) { return BigDecimal.ZERO; }
    }

    private static String safe(Object value) { return value == null ? "" : value.toString(); }

    private void showWarn(String message) {
        JOptionPane.showMessageDialog(this, message, "Thông báo", JOptionPane.WARNING_MESSAGE);
    }

    private void showError(Exception e) {
        JOptionPane.showMessageDialog(this, e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
    }

    private static class QrImagePanel extends JPanel {
        private BufferedImage image;

        QrImagePanel() {
            setOpaque(false);
            setPreferredSize(new Dimension(300, 320));
            setMinimumSize(new Dimension(220, 220));
            try {
                image = ImageIO.read(ThanhToanPanel.class.getResource("/images/payment_qr.png"));
            } catch (IOException | IllegalArgumentException ignored) {
                image = null;
            }
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (image == null) {
                g2.setColor(Theme.TEXT_MUTED);
                g2.setFont(Theme.FONT_BODY);
                String s = "Không tải được ảnh QR";
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString(s, (getWidth() - fm.stringWidth(s)) / 2, getHeight() / 2);
                g2.dispose();
                return;
            }
            int pad = 8;
            int maxW = Math.max(1, getWidth() - pad * 2);
            int maxH = Math.max(1, getHeight() - pad * 2);
            double scale = Math.min((double) maxW / image.getWidth(), (double) maxH / image.getHeight());
            int w = Math.max(1, (int) Math.round(image.getWidth() * scale));
            int h = Math.max(1, (int) Math.round(image.getHeight() * scale));
            int x = (getWidth() - w) / 2;
            int y = (getHeight() - h) / 2;
            g2.drawImage(image, x, y, w, h, null);
            g2.dispose();
        }
    }
}
