package com.mycompany.baitaplon.ui;

import com.mycompany.baitaplon.model.HocPhan;
import com.mycompany.baitaplon.controller.AuditController;
import com.mycompany.baitaplon.controller.HocPhanController;
import com.mycompany.baitaplon.util.UserSession;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public class HocPhanPanel extends JPanel {
    private RoundedField txtMaHP, txtTenHP, txtSoTinChi, txtHocPhi, txtMaNganh;
    private StyledTable table;
    private DefaultTableModel model;
    private final HocPhanController hocPhanService = new HocPhanController();
    private final AuditController auditService = new AuditController();
    private JPanel inputPanel;
    private RoundedButton bThem, bSua, bXoa;

    public HocPhanPanel() {
        super(new BorderLayout(14, 14));
        setOpaque(false);
        setBorder(new EmptyBorder(6, 6, 6, 6));
        add(createInputPanel(), BorderLayout.NORTH);
        add(createTablePanel(), BorderLayout.CENTER);
        add(createButtonPanel(), BorderLayout.SOUTH);
        loadData();
    }

    private JLabel makeLbl(String s) {
        JLabel l = new JLabel(s); l.setFont(Theme.FONT_LABEL); l.setForeground(Theme.TEXT_SECONDARY); return l;
    }

    private JPanel createInputPanel() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(24, 24, 20, 24));
        card.setTopAccent(Theme.PURPLE);
        JPanel p = new JPanel(new GridBagLayout()); p.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 14);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; p.add(makeLbl("Mã học phần"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.3;
        txtMaHP = new RoundedField(14); txtMaHP.setPlaceholder("VD: HP001"); p.add(txtMaHP, gbc); gbc.weightx = 0;

        gbc.gridx = 2; gbc.gridy = 0; p.add(makeLbl("Tên học phần"), gbc);
        gbc.gridx = 3; gbc.weightx = 0.7;
        txtTenHP = new RoundedField(24); txtTenHP.setPlaceholder("Tên môn học đầy đủ"); p.add(txtTenHP, gbc); gbc.weightx = 0;

        gbc.gridx = 0; gbc.gridy = 1; p.add(makeLbl("Số tín chỉ"), gbc);
        gbc.gridx = 1;
        txtSoTinChi = new RoundedField(14); txtSoTinChi.setPlaceholder("VD: 3"); p.add(txtSoTinChi, gbc);

        gbc.gridx = 2; gbc.gridy = 1; p.add(makeLbl("Học phí một tín chỉ (VND)"), gbc);
        gbc.gridx = 3;
        txtHocPhi = new RoundedField(24); txtHocPhi.setPlaceholder("VD: 550000"); p.add(txtHocPhi, gbc);

        gbc.gridx = 0; gbc.gridy = 2; p.add(makeLbl("Mã ngành"), gbc);
        gbc.gridx = 1;
        txtMaNganh = new RoundedField(14); txtMaNganh.setPlaceholder("VD: N001"); p.add(txtMaNganh, gbc);

        card.add(p, BorderLayout.CENTER);
        inputPanel = new JPanel(new BorderLayout()); inputPanel.setOpaque(false); inputPanel.add(card);
        JPanel wrap = new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(inputPanel);
        return wrap;
    }

    private JPanel createTablePanel() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(12, 12, 12, 12));
        card.setTopAccent(Theme.INFO);
        String[] cols = {"Mã HP", "Tên học phần", "Số TC", "Học phí/TC", "Mã ngành", "Tên ngành"};
        model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new StyledTable(); table.setModel(model);
        table.getColumnModel().getColumn(0).setPreferredWidth(90);
        table.getColumnModel().getColumn(1).setPreferredWidth(260);
        table.getColumnModel().getColumn(2).setPreferredWidth(90);
        table.getColumnModel().getColumn(3).setPreferredWidth(130);
        table.getColumnModel().getColumn(4).setPreferredWidth(100);
        table.getColumnModel().getColumn(5).setPreferredWidth(200);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) fillForm(); });
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        sp.getViewport().setOpaque(false); sp.setOpaque(false); UiUtils.tuneScrollPane(sp);
        card.add(sp, BorderLayout.CENTER);
        JPanel wrap = new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(card);
        return wrap;
    }

    private JPanel createButtonPanel() {
        JPanel p = new JPanel(new WrapLayout(FlowLayout.CENTER, 12, 6)); p.setOpaque(false);
        bThem = new RoundedButton("Thêm mới", "primary");
        bSua = new RoundedButton("Cập nhật", "secondary");
        bXoa = new RoundedButton("Xóa", "danger");
        RoundedButton b5 = new RoundedButton("Làm mới", "warning");
        bThem.addActionListener(e -> them());
        bSua.addActionListener(e -> sua());
        bXoa.addActionListener(e -> xoa());
        b5.addActionListener(e -> { clearForm(); loadData(); });
        p.add(bThem); p.add(bSua); p.add(bXoa); p.add(b5);
        return p;
    }

    public void configureForRole() {
        if (UserSession.isSinhVien()) {
            if (inputPanel != null) inputPanel.setVisible(false);
            if (bThem != null) bThem.setVisible(false);
            if (bSua != null) bSua.setVisible(false);
            if (bXoa != null) bXoa.setVisible(false);
        }
    }

    public void refreshData() { loadData(); }

    private void loadData() {
        try {
            List<HocPhan> list = hocPhanService.getAll(); model.setRowCount(0);
            for (HocPhan hp : list) model.addRow(new Object[]{hp.getMaHP(), hp.getTenHP(), hp.getSoTinChi(),
                hp.getHocPhiMotTinChi(), hp.getMaNganh(), hp.getTenNganh()});
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    private String str(Object o) { return o == null ? "" : o.toString(); }

    private void fillForm() {
        int row = table.getSelectedRow(); if (row < 0) return;
        txtMaHP.setText(str(model.getValueAt(row, 0)));
        txtTenHP.setText(str(model.getValueAt(row, 1)));
        txtSoTinChi.setText(str(model.getValueAt(row, 2)));
        Object hp = model.getValueAt(row, 3); txtHocPhi.setText(hp != null ? hp.toString() : "");
        Object mn = model.getValueAt(row, 4); txtMaNganh.setText(mn != null ? mn.toString() : "");
    }

    private void clearForm() {
        for (RoundedField f : new RoundedField[]{txtMaHP, txtTenHP, txtSoTinChi, txtHocPhi, txtMaNganh}) f.setText("");
        table.clearSelection();
    }

    private HocPhan getFormData() {
        String ma = txtMaHP.getText().trim().toUpperCase();
        String ten = txtTenHP.getText().trim();
        if (ma.isEmpty()) { JOptionPane.showMessageDialog(this, "Vui lòng nhập Mã HP"); return null; }
        if (ten.isEmpty()) { JOptionPane.showMessageDialog(this, "Vui lòng nhập Tên học phần"); return null; }
        HocPhan hp = new HocPhan();
        hp.setMaHP(ma);
        hp.setTenHP(ten);
        try { hp.setSoTinChi(Integer.parseInt(txtSoTinChi.getText().trim())); }
        catch (NumberFormatException e) { JOptionPane.showMessageDialog(this, "Số tín chỉ phải là số nguyên"); return null; }
        if (hp.getSoTinChi() <= 0 || hp.getSoTinChi() > 20) { JOptionPane.showMessageDialog(this, "Số tín chỉ phải từ 1 đến 20."); return null; }
        try { hp.setHocPhiMotTinChi(new BigDecimal(txtHocPhi.getText().trim().replace(",", ""))); }
        catch (Exception e) { JOptionPane.showMessageDialog(this, "Học phí/tín chỉ không hợp lệ."); return null; }
        if (hp.getHocPhiMotTinChi().signum() < 0) { JOptionPane.showMessageDialog(this, "Học phí không được âm."); return null; }
        hp.setMaNganh(txtMaNganh.getText().trim());
        return hp;
    }

    private void them() {
        HocPhan hp = getFormData(); if (hp == null) return;
        try { if (hocPhanService.insert(hp)) {
            try { auditService.ghi("THEM_HOC_PHAN", "HocPhan", hp.getMaHP() + " | " + hp.getTenHP()); } catch (Exception ignored) {}
            JOptionPane.showMessageDialog(this, "✅ Thêm thành công"); loadData(); clearForm(); } }
        catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    private void sua() {
        if (table.getSelectedRow() < 0) { JOptionPane.showMessageDialog(this, "Chọn học phần cần sửa"); return; }
        HocPhan hp = getFormData(); if (hp == null) return;
        try { if (hocPhanService.update(hp)) {
            try { auditService.ghi("SUA_HOC_PHAN", "HocPhan", hp.getMaHP() + " | " + hp.getTenHP()); } catch (Exception ignored) {}
            JOptionPane.showMessageDialog(this, "✅ Cập nhật thành công"); loadData(); clearForm(); } }
        catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    private void xoa() {
        if (table.getSelectedRow() < 0) { JOptionPane.showMessageDialog(this, "Chọn học phần cần xóa"); return; }
        if (JOptionPane.showConfirmDialog(this, "Xác nhận xóa?", "Xóa", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) return;
        String maHP = txtMaHP.getText().trim();
        try { if (hocPhanService.delete(maHP)) {
            try { auditService.ghi("XOA_HOC_PHAN", "HocPhan", maHP); } catch (Exception ignored) {}
            JOptionPane.showMessageDialog(this, "✅ Xóa thành công"); loadData(); clearForm(); } }
        catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }
}
