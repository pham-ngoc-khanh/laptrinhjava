package com.mycompany.baitaplon.ui;

import com.mycompany.baitaplon.model.*;
import com.mycompany.baitaplon.controller.AuditController;
import com.mycompany.baitaplon.controller.DangKyHocPhanController;
import com.mycompany.baitaplon.controller.HocKyNamHocController;
import com.mycompany.baitaplon.controller.HocPhanController;
import com.mycompany.baitaplon.controller.SinhVienController;
import com.mycompany.baitaplon.service.DangKyHocPhanService;
import com.mycompany.baitaplon.util.TableExportUtil;
import com.mycompany.baitaplon.util.UserSession;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class DangKyHocPhanPanel extends JPanel {
    private final DangKyHocPhanController dangKyService = new DangKyHocPhanController();
    private final SinhVienController sinhVienService = new SinhVienController();
    private final HocPhanController hocPhanService = new HocPhanController();
    private final HocKyNamHocController hocKyNamHocService = new HocKyNamHocController();
    private final AuditController auditService = new AuditController();
    private RoundedCombo<String> cboSV, cboHP, cboHK, cboNamHoc;
    private RoundedField txtSearch;
    private RoundedButton btnAdd, btnDelete, btnRefresh, btnExport;
    private StyledTable table;
    private DefaultTableModel model;
    private JLabel lblCount, lblCredits, lblAmount;
    private JLabel lblNamHocTC, lblNganhInfo;

    public DangKyHocPhanPanel() {
        super(new BorderLayout(14,14));
        setOpaque(false); setBorder(new EmptyBorder(6,6,6,6));
        add(createTop(), BorderLayout.NORTH);
        add(createTable(), BorderLayout.CENTER);
        add(createSummary(), BorderLayout.SOUTH);
        loadCombos();
        cboSV.addActionListener(e -> { reloadHocPhanCombo(); updateNamHocTinChi(); updateNganhInfo(); loadData(); });
        cboNamHoc.addActionListener(e -> { reloadHocKyTheoNam(); updateNamHocTinChi(); loadData(); });
        cboHK.addActionListener(e -> updateNamHocTinChi());
        loadData();
        updateNganhInfo();
    }

    private JLabel label(String s) { JLabel l=new JLabel(s); l.setFont(Theme.FONT_LABEL); l.setForeground(Theme.TEXT_SECONDARY); return l; }

    private JPanel createTop() {
        JPanel outer=new JPanel(new BorderLayout(0,10)); outer.setOpaque(false);
        CardPanel form=new CardPanel(new BorderLayout()); form.setTopAccent(Theme.PURPLE); form.setBorder(new EmptyBorder(18,22,16,22));
        JPanel row=new JPanel(new WrapLayout(FlowLayout.LEFT,12,8)); row.setOpaque(false);
        cboSV=new RoundedCombo<>(); cboSV.setPreferredSize(new Dimension(280,36));
        cboNamHoc=new RoundedCombo<>(); cboNamHoc.setPreferredSize(new Dimension(180,36));
        cboHP=new RoundedCombo<>(); cboHP.setPreferredSize(new Dimension(300,36));
        cboHK=new RoundedCombo<>(); cboHK.setPreferredSize(new Dimension(230,36));
        row.add(group("🎓 Sinh viên",cboSV));
        row.add(group("📆 Năm học",cboNamHoc));
        row.add(group("📚 Học phần",cboHP));
        row.add(group("📅 Học kỳ",cboHK));
        btnAdd=new RoundedButton("Đăng ký", "primary"); btnAdd.setPreferredSize(new Dimension(145,42)); btnAdd.addActionListener(e->addRegistration());
        JPanel bp=new JPanel(new BorderLayout()); bp.setOpaque(false); bp.setBorder(new EmptyBorder(18,4,0,0)); bp.add(btnAdd); row.add(bp);
        form.add(row); outer.add(form,BorderLayout.NORTH);

        CardPanel filter=new CardPanel(new BorderLayout()); filter.setTopAccent(Theme.INFO); filter.setBorder(new EmptyBorder(14,20,14,20));
        JPanel fr=new JPanel(new WrapLayout(FlowLayout.LEFT,10,6)); fr.setOpaque(false);
        txtSearch=new RoundedField(28); txtSearch.setPlaceholder("Tìm MSSV, họ tên hoặc học phần..."); txtSearch.setPreferredSize(new Dimension(360,36));
        txtSearch.addActionListener(e->loadData());
        RoundedButton find=new RoundedButton("Tìm", "secondary"); find.addActionListener(e->loadData());
        btnRefresh=new RoundedButton("Làm mới", "warning"); btnRefresh.addActionListener(e->{txtSearch.setText("");loadCombos();loadData();updateNamHocTinChi();});
        btnDelete=new RoundedButton("Hủy đăng ký", "danger"); btnDelete.addActionListener(e->deleteRegistration());
        btnExport=new RoundedButton("Xuất CSV", "success"); btnExport.addActionListener(e->TableExportUtil.exportCsv(this,table,"dang-ky-hoc-phan"));
        fr.add(txtSearch); fr.add(find); fr.add(btnRefresh); fr.add(btnDelete); fr.add(btnExport);
        filter.add(fr, BorderLayout.NORTH);

        JPanel statusRow = new JPanel(new BorderLayout()); statusRow.setOpaque(false); statusRow.setBorder(new EmptyBorder(8, 2, 2, 2));
        lblNganhInfo = new JLabel("💡 Chọn Sinh viên để xem danh sách học phần theo NGÀNH của sinh viên đó (chỉ cho đăng ký cùng ngành).");
        lblNganhInfo.setFont(Theme.FONT_LABEL.deriveFont(Font.BOLD, 12.5f));
        lblNganhInfo.setForeground(new Color(79, 70, 229));
        lblNganhInfo.setBorder(BorderFactory.createEmptyBorder(6, 10, 6, 10));
        statusRow.add(lblNganhInfo, BorderLayout.NORTH);

        lblNamHocTC = new JLabel("📅 Chọn Sinh viên và Học kỳ để xem tổng tín chỉ theo năm học (tối đa 24 tín chỉ / năm)");
        lblNamHocTC.setFont(Theme.FONT_LABEL.deriveFont(Font.BOLD, 13f));
        lblNamHocTC.setForeground(Theme.TEXT_SECONDARY);
        lblNamHocTC.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        statusRow.add(lblNamHocTC, BorderLayout.SOUTH);
        filter.add(statusRow, BorderLayout.SOUTH);

        outer.add(filter,BorderLayout.CENTER); return outer;
    }

    private JPanel group(String title, JComponent c) { JPanel p=new JPanel(); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS)); p.setOpaque(false); c.setMaximumSize(new Dimension(Integer.MAX_VALUE, Math.max(36,c.getPreferredSize().height))); p.add(label(title)); p.add(Box.createVerticalStrut(4)); p.add(c); return p; }

    private JPanel createTable() {
        CardPanel card=new CardPanel(new BorderLayout()); card.setTopAccent(Theme.SECONDARY); card.setBorder(new EmptyBorder(10,10,10,10));
        model=new DefaultTableModel(new String[]{"Mã ĐK","Mã SV","Họ tên","Mã HP","Tên học phần","Số TC","Học phí/TC","Thành tiền","Học kỳ","Ngày ĐK"},0){public boolean isCellEditable(int r,int c){return false;}};
        table=new StyledTable(); table.setModel(model); table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getColumnModel().getColumn(0).setPreferredWidth(65); table.getColumnModel().getColumn(2).setPreferredWidth(170); table.getColumnModel().getColumn(4).setPreferredWidth(200); table.getColumnModel().getColumn(8).setPreferredWidth(140);
        JScrollPane sp=new JScrollPane(table); sp.setBorder(BorderFactory.createEmptyBorder()); sp.getViewport().setOpaque(false); sp.setOpaque(false); UiUtils.tuneScrollPane(sp); card.add(sp);
        JPanel wrap=new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(card); return wrap;
    }

    private JPanel createSummary() {
        CardPanel card=new CardPanel(new BorderLayout());
        card.setTopAccent(Theme.SUCCESS);
        card.setBorder(new EmptyBorder(12,16,12,16));
        ResponsiveGridPanel grid = new ResponsiveGridPanel(3, 220, 12, 10);
        lblCount=summary("Số lượt đăng ký","0");
        lblCredits=summary("Tổng tín chỉ","0");
        lblAmount=summary("Tổng học phí","0 VND");
        grid.add(lblCount); grid.add(lblCredits); grid.add(lblAmount);
        card.add(grid, BorderLayout.CENTER);
        JPanel w=new JPanel(new BorderLayout());w.setOpaque(false);w.add(card);return w;
    }
    private JLabel summary(String t,String v){JLabel l=new JLabel("<html><span style='color:#64748b'>"+t+"</span><br><b style='font-size:16px;color:#0f172a'>"+v+"</b></html>");l.setBorder(new EmptyBorder(6,12,6,12));l.setPreferredSize(new Dimension(220,58));l.setToolTipText(t+": "+v);return l;}

    public void configureForRole() {
        if(UserSession.isSinhVien()){
            cboSV.setEnabled(false); cboNamHoc.setEnabled(true); cboHP.setEnabled(true); cboHK.setEnabled(true);
            btnAdd.setVisible(true); btnDelete.setVisible(true);
            String ma=UserSession.getMaSV();
            boolean found=false;
            for(int i=0;i<cboSV.getItemCount();i++){ if(cboSV.getItemAt(i).startsWith(ma+" - ")){cboSV.setSelectedIndex(i);found=true;break;} }
            if(found){ reloadHocPhanCombo(); updateNganhInfo(); }
        }
    }

    public void refreshData(){loadCombos();loadData();updateNamHocTinChi();updateNganhInfo();}

    private String getSelectedMaSV() {
        if (cboSV == null || cboSV.getSelectedItem() == null) return null;
        String s = cboSV.getSelectedItem().toString();
        if (s.contains(" - ")) return s.split(" - ")[0];
        s = s.trim();
        return s.isEmpty() ? null : s;
    }

    private void loadCombos(){
        try{
            cboSV.removeAllItems();
            if(UserSession.isSinhVien()){
                String ma=UserSession.getMaSV();
                SinhVien sv=sinhVienService.getById(ma);
                if(sv!=null) cboSV.addItem(sv.getMaSV()+" - "+sv.getHoTen());
            } else {
                for(SinhVien s:sinhVienService.getAll()) cboSV.addItem(s.getMaSV()+" - "+s.getHoTen());
            }
            cboNamHoc.removeAllItems();
            java.util.LinkedHashSet<String> namHocs = new java.util.LinkedHashSet<>();
            for(HocKyNamHoc h : hocKyNamHocService.getAll()) namHocs.add(h.getNamHoc());
            if (!UserSession.isSinhVien()) cboNamHoc.addItem("Tất cả năm học");
            for (String namHoc : namHocs) cboNamHoc.addItem(namHoc);
            if (cboNamHoc.getItemCount() > 0) {
                cboNamHoc.setSelectedIndex(0);
            }
            reloadHocKyTheoNam();
            reloadHocPhanCombo();
        }catch(Exception e){showError(e);}
    }

    /** Nạp danh sách học kỳ theo năm học đang chọn. Sinh viên chọn năm học trước,
     * sau đó chỉ nhìn thấy các học kỳ thuộc đúng năm đó. */
    private void reloadHocKyTheoNam() {
        if (cboHK == null || cboNamHoc == null) return;
        try {
            Object selected = cboNamHoc.getSelectedItem();
            String namHoc = selected == null ? null : selected.toString();
            String oldMaHK = null;
            if (cboHK.getSelectedItem() != null) oldMaHK = cboHK.getSelectedItem().toString().split(" - ")[0];
            cboHK.removeAllItems();
            for (HocKyNamHoc h : hocKyNamHocService.getAll()) {
                if (namHoc == null || "Tất cả năm học".equals(namHoc) || namHoc.equals(h.getNamHoc())) {
                    cboHK.addItem(h.getMaHKNH()+" - "+h.toString());
                }
            }
            if (oldMaHK != null) {
                for (int i=0;i<cboHK.getItemCount();i++) {
                    if (cboHK.getItemAt(i).startsWith(oldMaHK+" - ")) { cboHK.setSelectedIndex(i); break; }
                }
            }
        } catch (Exception e) { showError(e); }
    }

    private void reloadHocPhanCombo() {
        try {
            cboHP.removeAllItems();
            String maSV = getSelectedMaSV();
            String maNganhSV = null;
            if (maSV != null) maNganhSV = sinhVienService.getMaNganhByMaSV(maSV);
            int count = 0;
            for (HocPhan h : hocPhanService.getAll()) {
                if (maNganhSV == null || maNganhSV.equals(h.getMaNganh())) {
                    cboHP.addItem(h.getMaHP()+" - "+h.getTenHP()+" ("+h.getSoTinChi()+" TC)");
                    count++;
                }
            }
            if (cboSV.getItemCount() > 0 && maNganhSV != null && count == 0) {
                cboHP.addItem("⚠ Không có học phần cho ngành " + maNganhSV);
                cboHP.setEnabled(false);
            } else {
                cboHP.setEnabled(true);
            }
        } catch (Exception e) { showError(e); }
    }

    private void updateNganhInfo() {
        if (lblNganhInfo == null) return;
        try {
            String maSV = getSelectedMaSV();
            if (maSV == null) {
                lblNganhInfo.setText("💡 Vui lòng chọn Sinh viên để xem danh sách học phần theo NGÀNH.");
                lblNganhInfo.setForeground(Theme.TEXT_SECONDARY);
                return;
            }
            String maNganh = sinhVienService.getTenNganhByMaSV(maSV);
            int soHP = 0;
            for (int i = 0; i < cboHP.getItemCount(); i++) if (!cboHP.getItemAt(i).startsWith("⚠")) soHP++;
            String hoten = "";
            try { SinhVien sv = sinhVienService.getById(maSV); if (sv != null) hoten=" - " + sv.getHoTen(); } catch (Exception ignore) {}
            lblNganhInfo.setText(String.format("🎓 %s%s → Ngành: %s (%d môn học phần phù hợp cùng ngành — CHỈ được đăng ký môn học trong danh sách lọc này.)",
                    maSV, hoten,
                    (maNganh == null ? "Chưa xác định" : maNganh),
                    soHP));
            lblNganhInfo.setForeground(new Color(79, 70, 229));
        } catch (Exception e) {
            lblNganhInfo.setText("⚠ Lỗi kiểm tra ngành: " + e.getMessage());
            lblNganhInfo.setForeground(Theme.DANGER);
        }
    }

    private void updateNamHocTinChi() {
        if (lblNamHocTC == null || cboSV == null || cboNamHoc == null) return;
        if (cboSV.getSelectedItem() == null || cboNamHoc.getSelectedItem() == null) {
            lblNamHocTC.setText("📅 Chọn Sinh viên và Năm học để xem tổng số tín chỉ đã/đang học trong năm đó.");
            lblNamHocTC.setForeground(Theme.TEXT_SECONDARY);
            return;
        }
        try {
            String maSV = getSelectedMaSV();
            String namHoc = cboNamHoc.getSelectedItem().toString();
            if ("Tất cả năm học".equals(namHoc)) {
                lblNamHocTC.setText("📚 Đang xem tất cả năm học — hãy chọn một năm học để biết chính xác sinh viên học bao nhiêu tín chỉ trong năm đó.");
                lblNamHocTC.setForeground(Theme.TEXT_SECONDARY);
                return;
            }
            int tcNam = dangKyService.getTongTinChiTheoNamHoc(maSV, namHoc);
            int tcKy = 0;
            if (cboHK.getSelectedItem() != null) {
                String maHKNH = cboHK.getSelectedItem().toString().split(" - ")[0];
                tcKy = dangKyService.getTongTinChiTheoMaHKNH(maSV, maHKNH);
            }
            int maxTC = DangKyHocPhanService.TONG_TIN_CHI_BAT_BUOC_1_NAM;
            int conLai = Math.max(0, maxTC - tcNam);
            lblNamHocTC.setText(String.format("📆 Năm học %s: %d / %d tín chỉ — còn có thể đăng ký %d tín chỉ trong năm; học kỳ đang chọn: %d TC",
                    namHoc, tcNam, maxTC, conLai, tcKy));
            lblNamHocTC.setForeground(tcNam >= maxTC ? new Color(16, 185, 129) : new Color(245, 158, 11));
        } catch (SQLException | IllegalStateException e) {
            lblNamHocTC.setText("⚠ Lỗi kiểm tra tín chỉ: " + e.getMessage());
            lblNamHocTC.setForeground(Theme.DANGER);
        }
    }

    private void loadData(){
        try{
            List<DangKyHocPhan> list;
            if(UserSession.isSinhVien()) list=dangKyService.getBySinhVien(UserSession.getMaSV());
            else {String k=txtSearch==null?"":txtSearch.getText().trim(); list=k.isEmpty()?dangKyService.getAll():dangKyService.search(k);}
            Object selectedYear = cboNamHoc == null ? null : cboNamHoc.getSelectedItem();
            String namHocFilter = selectedYear == null ? null : selectedYear.toString();
            if (namHocFilter != null && !"Tất cả năm học".equals(namHocFilter)) {
                final String year = namHocFilter;
                list = list.stream().filter(d -> d.getTenHKNH() != null && d.getTenHKNH().endsWith(year)).toList();
            }
            model.setRowCount(0); int tc=0; BigDecimal money=BigDecimal.ZERO;
            for(DangKyHocPhan d:list){model.addRow(new Object[]{d.getMaDKHP(),d.getMaSV(),d.getHoTenSV(),d.getMaHP(),d.getTenHP(),d.getSoTinChi(),String.format("%,.0f",d.getHocPhiMotTinChi()),String.format("%,.0f",d.getThanhTien()),d.getTenHKNH(),d.getNgayDangKy()});tc+=d.getSoTinChi();money=money.add(d.getThanhTien());}
            if(lblCount!=null){lblCount.setText(html("Số lượt đăng ký",String.valueOf(list.size())));lblCredits.setText(html("Tổng tín chỉ của năm đang chọn",String.valueOf(tc)));lblAmount.setText(html("Tổng học phí năm đang chọn",String.format("%,.0f VND",money)));}
        }catch(Exception e){showError(e);}
    }
    private String html(String t,String v){return "<html><span style='color:#64748b'>"+t+"</span><br><b style='font-size:16px;color:#0f172a'>"+v+"</b></html>";}

    private void addRegistration(){
        if(cboSV.getSelectedItem()==null||cboHP.getSelectedItem()==null||cboHK.getSelectedItem()==null){JOptionPane.showMessageDialog(this,"Vui lòng chọn đủ sinh viên, học phần và học kỳ.");return;}
        String sv=code(cboSV), hp=code(cboHP), hk=code(cboHK);
        try{if(dangKyService.insert(sv,hp,hk,Date.valueOf(LocalDate.now()))){
            try { auditService.ghi("THEM_DANG_KY_HP", "DangKyHocPhan", "SV:" + sv + " HP:" + hp + " HK:" + hk); } catch (Exception ignored) {}
            JOptionPane.showMessageDialog(this,"✅ Đăng ký thành công. Học phí và công nợ đã được tính/cập nhật tự động.");loadData();updateNamHocTinChi();}}
        catch(IllegalStateException e){JOptionPane.showMessageDialog(this,e.getMessage(),"Thông báo",JOptionPane.WARNING_MESSAGE);}
        catch(SQLException e){showError(e);}
    }

    private void deleteRegistration(){
        int r=table.getSelectedRow(); if(r<0){JOptionPane.showMessageDialog(this,"Chọn một đăng ký cần hủy.");return;}
        int id=Integer.parseInt(model.getValueAt(r,0).toString());
        if(JOptionPane.showConfirmDialog(this,"Hủy đăng ký học phần đã chọn? Học phí sẽ được tính lại tự động.","Xác nhận",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;
        try{if(dangKyService.delete(id)){
            try { auditService.ghi("XOA_DANG_KY_HP", "DangKyHocPhan", "MaDKHP:" + id); } catch (Exception ignored) {}
            JOptionPane.showMessageDialog(this,"✅ Đã hủy đăng ký và đồng bộ học phí/công nợ.");loadData();updateNamHocTinChi();}}catch(SQLException e){showError(e);}
    }
    private String code(RoundedCombo<String> c){return c.getSelectedItem().toString().split(" - ")[0];}
    private void showError(Exception e){JOptionPane.showMessageDialog(this,e.getMessage(),"Lỗi",JOptionPane.ERROR_MESSAGE);}
}
