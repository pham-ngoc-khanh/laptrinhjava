package com.mycompany.baitaplon.ui;

import javax.swing.border.Border;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class SectionBorder implements Border {
    private String title;
    private Color accent;
    public SectionBorder(String title, Color accent) { this.title = title; this.accent = accent; }

    @Override public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int r = Theme.RADIUS;
        g2.setColor(new Color(255,255,255, 70));
        g2.fill(new RoundRectangle2D.Float(x, y + 10, w - 1, h - 11, r, r));

        g2.setColor(accent);
        g2.setFont(Theme.FONT_H3);
        FontMetrics fm = g2.getFontMetrics();
        int tw = fm.stringWidth(title);
        int bx = x + 16;
        int by = y + 16;

        g2.setPaint(new LinearGradientPaint(bx, by, bx, by + 30, new float[]{0f, 1f}, new Color[]{accent, Theme.mix(accent, Color.WHITE, 0.7f)}));
        RoundRectangle2D pill = new RoundRectangle2D.Float(bx - 1, by - 1, tw + 28, 30, 15, 15);
        g2.fill(pill);
        g2.setColor(new Color(255,255,255,60));
        g2.draw(pill);

        g2.setColor(Color.WHITE);
        g2.drawString(title, bx + 14, by + 21);
        g2.dispose();
    }
    @Override public Insets getBorderInsets(Component c) { return new Insets(40, 16, 16, 16); }
    @Override public boolean isBorderOpaque() { return false; }
}
