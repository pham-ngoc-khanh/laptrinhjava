package com.mycompany.baitaplon.ui;

import com.mycompany.baitaplon.dao.BaoCaoDAO.KhoaRow;
import com.mycompany.baitaplon.dao.BaoCaoDAO.ThangRow;
import com.mycompany.baitaplon.controller.AuditController;
import com.mycompany.baitaplon.controller.BaoCaoController;
import com.mycompany.baitaplon.util.TableExportUtil;
import com.mycompany.baitaplon.util.UserSession;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class BaoCaoPanel extends JPanel {
    private final BaoCaoController baoCaoService = new BaoCaoController();
    private final AuditController auditService = new AuditController();
    private RoundedCombo<String> cboNam;
    private JLabel lblSV,lblPhaiThu,lblDaThu,lblConLai;
    private DefaultTableModel modelKhoa,modelThang;
    private StyledTable tblKhoa,tblThang;
    private JPanel chartPanel;
    private List<ThangRow> monthData = new ArrayList<>();

    public BaoCaoPanel(){
        super(new BorderLayout(14,14)); setOpaque(false); setBorder(new EmptyBorder(6,6,6,6));
        add(createHeader(),BorderLayout.NORTH); add(createBody(),BorderLayout.CENTER);
        if(!UserSession.isSinhVien()){ loadYears(); refreshData(); }
    }

    public void configureForRole(){
        if(UserSession.isSinhVien()){
            removeAll(); JPanel p=new JPanel(new GridBagLayout());p.setOpaque(false);JLabel l=new JLabel("Tính năng Báo cáo chỉ dành cho Thư ký khoa.");l.setFont(Theme.FONT_H2);l.setForeground(Theme.TEXT_SECONDARY);p.add(l);add(p);
        }
    }

    private JPanel createHeader(){
        JPanel p=new JPanel(new WrapLayout(FlowLayout.LEFT,18,8));
        p.setOpaque(false);
        JPanel title=new JPanel();
        title.setLayout(new BoxLayout(title,BoxLayout.Y_AXIS));
        title.setOpaque(false);
        title.setPreferredSize(new Dimension(390,54));
        JLabel a=new JLabel("📈 Báo cáo tài chính");
        a.setFont(Theme.FONT_H2.deriveFont(22f));
        a.setForeground(Theme.TEXT);
        JLabel b=new JLabel("Dữ liệu thật từ học phí, công nợ và giao dịch thanh toán");
        b.setFont(Theme.FONT_BODY);
        b.setForeground(Theme.TEXT_MUTED);
        b.setToolTipText(b.getText());
        title.add(a); title.add(Box.createVerticalStrut(2)); title.add(b);

        JPanel right=new JPanel(new WrapLayout(FlowLayout.LEFT,8,4));
        right.setOpaque(false);
        JLabel y=new JLabel("Năm học:"); y.setFont(Theme.FONT_LABEL); y.setForeground(Theme.TEXT_SECONDARY);
        right.add(y);
        cboNam=new RoundedCombo<>(); UiUtils.makeFlexible(cboNam,140,180,38); cboNam.addActionListener(e->refreshData()); right.add(cboNam);
        RoundedButton reload=new RoundedButton("Làm mới","warning"); reload.addActionListener(e->refreshData()); right.add(reload);
        RoundedButton export=new RoundedButton("Xuất báo cáo","success"); export.addActionListener(e->exportReport()); right.add(export);
        p.add(title); p.add(right);
        return p;
    }

    private JPanel createBody(){
        JPanel p=new JPanel(new BorderLayout(14,14));p.setOpaque(false);
        JPanel stats=new ResponsiveGridPanel(4,210,12,12);stats.setOpaque(false);
        Object[] s1=statCard("👥 Sinh viên",Theme.PRIMARY);Object[] s2=statCard("💸 Phải thu",Theme.PURPLE);Object[] s3=statCard("✅ Đã thu",Theme.SUCCESS);Object[] s4=statCard("⚠ Còn nợ",Theme.DANGER);
        lblSV=(JLabel)s1[1];lblPhaiThu=(JLabel)s2[1];lblDaThu=(JLabel)s3[1];lblConLai=(JLabel)s4[1];stats.add((JPanel)s1[0]);stats.add((JPanel)s2[0]);stats.add((JPanel)s3[0]);stats.add((JPanel)s4[0]);p.add(stats,BorderLayout.NORTH);

        JSplitPane split=new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);split.setBorder(null);split.setOpaque(false);split.setDividerSize(5);split.setResizeWeight(.55);
        JPanel leftCard=createFacultyCard(); JPanel rightCard=createMonthlyCard(); leftCard.setMinimumSize(new Dimension(280,220)); rightCard.setMinimumSize(new Dimension(280,220)); split.setLeftComponent(leftCard); split.setRightComponent(rightCard);p.add(split,BorderLayout.CENTER);return p;
    }

    private Object[] statCard(String title,Color accent){
        CardPanel c=new CardPanel(new BorderLayout());c.setTopAccent(accent);c.setBorder(new EmptyBorder(18,20,16,20));
        JLabel t=new JLabel(title);t.setFont(Theme.FONT_LABEL);t.setForeground(Theme.TEXT_MUTED);JLabel v=new JLabel("0");v.setFont(Theme.FONT_STAT.deriveFont(22f));v.setForeground(Theme.TEXT);
        c.add(t,BorderLayout.NORTH);c.add(v,BorderLayout.CENTER);JPanel w=new JPanel(new BorderLayout());w.setOpaque(false);w.setPreferredSize(new Dimension(210,92));w.add(c);return new Object[]{w,v};
    }

    private JPanel createFacultyCard(){
        CardPanel c=new CardPanel(new BorderLayout());c.setTopAccent(Theme.SECONDARY);c.setBorder(new EmptyBorder(14,14,14,14));
        JLabel t=new JLabel("🏫 Tổng hợp theo khoa");t.setFont(Theme.FONT_H2);t.setBorder(new EmptyBorder(0,4,10,0));c.add(t,BorderLayout.NORTH);
        modelKhoa=new DefaultTableModel(new String[]{"Khoa","Số SV","Phải thu","Đã thu","Còn nợ","Tỷ lệ thu"},0){public boolean isCellEditable(int r,int col){return false;}};
        tblKhoa=new StyledTable();tblKhoa.setModel(modelKhoa);tblKhoa.getColumnModel().getColumn(0).setPreferredWidth(190);
        JScrollPane sp=new JScrollPane(tblKhoa);sp.setBorder(BorderFactory.createEmptyBorder());UiUtils.tuneScrollPane(sp);c.add(sp);JPanel w=new JPanel(new BorderLayout());w.setOpaque(false);w.add(c);return w;
    }

    private JPanel createMonthlyCard(){
        CardPanel c=new CardPanel(new BorderLayout(0,10));c.setTopAccent(Theme.INFO);c.setBorder(new EmptyBorder(14,14,14,14));
        JLabel t=new JLabel("📊 Doanh thu theo tháng");t.setFont(Theme.FONT_H2);c.add(t,BorderLayout.NORTH);
        chartPanel=new JPanel(){protected void paintComponent(Graphics g){super.paintComponent(g);drawChart((Graphics2D)g.create(),getWidth(),getHeight());}};chartPanel.setOpaque(false);chartPanel.setPreferredSize(new Dimension(420,240));
        modelThang=new DefaultTableModel(new String[]{"Tháng","Doanh thu"},0){public boolean isCellEditable(int r,int col){return false;}};
        tblThang=new StyledTable();tblThang.setModel(modelThang);JScrollPane sp=new JScrollPane(tblThang);sp.setPreferredSize(new Dimension(0,150));sp.setBorder(BorderFactory.createEmptyBorder());UiUtils.tuneScrollPane(sp);
        JSplitPane split=new JSplitPane(JSplitPane.VERTICAL_SPLIT,chartPanel,sp);split.setResizeWeight(.64);split.setDividerSize(4);split.setBorder(null);split.setOpaque(false);c.add(split,BorderLayout.CENTER);
        JPanel w=new JPanel(new BorderLayout());w.setOpaque(false);w.add(c);return w;
    }

    private void drawChart(Graphics2D g2,int w,int h){
        try{g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);int l=55,r=16,t=20,b=36;int cw=w-l-r,ch=h-t-b;if(cw<40||ch<40)return;
            g2.setColor(Theme.BORDER);g2.drawLine(l,t,l,h-b);g2.drawLine(l,h-b,w-r,h-b);
            if(monthData.isEmpty()){g2.setColor(Theme.TEXT_MUTED);g2.setFont(Theme.FONT_BODY);g2.drawString("Chưa có giao dịch thanh toán trong phạm vi đã chọn.",l+20,t+40);return;}
            BigDecimal max=BigDecimal.ZERO;for(ThangRow m:monthData)if(m.doanhThu.compareTo(max)>0)max=m.doanhThu;if(max.signum()==0)return;
            int n=monthData.size(),group=Math.max(20,cw/n),bw=Math.max(12,(int)(group*.55));
            for(int i=0;i<n;i++){ThangRow m=monthData.get(i);double ratio=m.doanhThu.doubleValue()/max.doubleValue();int bh=(int)(ch*ratio);int x=l+i*group+(group-bw)/2;int y=h-b-bh;
                g2.setPaint(new GradientPaint(0,y,Theme.PRIMARY,0,h-b,Theme.SECONDARY));g2.fill(new RoundRectangle2D.Float(x,y,bw,bh,8,8));g2.setColor(Theme.TEXT_MUTED);g2.setFont(Theme.FONT_SMALL);String lab=m.label();FontMetrics fm=g2.getFontMetrics();if(n<=12)g2.drawString(lab,x+bw/2-fm.stringWidth(lab)/2,h-b+16);}
        }finally{g2.dispose();}
    }

    private void loadYears(){
        if(UserSession.isSinhVien())return;
        try{Object selected=cboNam.getSelectedItem();cboNam.removeAllItems();cboNam.addItem("🌐 Tất cả");for(String y:baoCaoService.getNamHoc())cboNam.addItem(y);if(selected!=null)cboNam.setSelectedItem(selected);}catch(Exception e){showError(e);}
    }

    public void refreshData(){
        if(UserSession.isSinhVien())return;
        try{
            String nam=cboNam==null||cboNam.getSelectedIndex()<=0?null:String.valueOf(cboNam.getSelectedItem());
            List<KhoaRow> rows=baoCaoService.baoCaoCongNoTheoKhoa(nam);BigDecimal total=BigDecimal.ZERO,paid=BigDecimal.ZERO,debt=BigDecimal.ZERO;modelKhoa.setRowCount(0);
            for(KhoaRow x:rows){total=total.add(x.phaiThu);paid=paid.add(x.daThu);debt=debt.add(x.conLai);int pct=x.phaiThu.signum()==0?0:x.daThu.multiply(BigDecimal.valueOf(100)).divide(x.phaiThu,0,java.math.RoundingMode.HALF_UP).intValue();modelKhoa.addRow(new Object[]{x.tenKhoa,x.soSinhVien,money(x.phaiThu),money(x.daThu),money(x.conLai),pct+"%"});}
            lblSV.setText(String.format("%,d",baoCaoService.demSinhVien(nam)));lblPhaiThu.setText(money(total));lblDaThu.setText(money(paid));lblConLai.setText(money(debt));
            monthData=baoCaoService.baoCaoDoanhThuTheoThang(nam);modelThang.setRowCount(0);for(ThangRow m:monthData)modelThang.addRow(new Object[]{m.label(),money(m.doanhThu)});chartPanel.repaint();
        }catch(Exception e){showError(e);}
    }

    private String money(BigDecimal v){return String.format("%,.0f VND",v==null?BigDecimal.ZERO:v);}
    private void exportReport(){
        String choice=(String)JOptionPane.showInputDialog(this,"Chọn bảng cần xuất:","Xuất báo cáo",JOptionPane.QUESTION_MESSAGE,null,new String[]{"Tổng hợp theo khoa","Doanh thu theo tháng"},"Tổng hợp theo khoa");
        if(choice==null)return;TableExportUtil.exportCsv(this,"Doanh thu theo tháng".equals(choice)?tblThang:tblKhoa,"bao-cao-tai-chinh");
    }
    private void showError(Exception e){JOptionPane.showMessageDialog(this,e.getMessage(),"Lỗi báo cáo",JOptionPane.ERROR_MESSAGE);}
}
