package com.mycompany.baitaplon.ui;

import com.mycompany.baitaplon.model.CongNo;
import com.mycompany.baitaplon.controller.AuditController;
import com.mycompany.baitaplon.controller.CongNoController;
import com.mycompany.baitaplon.util.UserSession;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

public class CongNoPanel extends JPanel {
    private RoundedField txtSearch;
    private RoundedCombo<String> cboTrangThai;
    private StyledTable table;
    private DefaultTableModel model;
    private JLabel lblTongNo, lblTongDaThu, lblTongConLai;
    private final CongNoController cnService = new CongNoController();
    private final AuditController auditService = new AuditController();

    public CongNoPanel() {
        super(new BorderLayout(14, 14));
        setOpaque(false);
        setBorder(new EmptyBorder(6, 6, 6, 6));
        add(createTopPanel(), BorderLayout.NORTH);
        add(createTablePanel(), BorderLayout.CENTER);
        add(createSummaryPanel(), BorderLayout.SOUTH);
        loadData();
    }

    private JLabel makeLbl(String s) { JLabel l = new JLabel(s); l.setFont(Theme.FONT_LABEL); l.setForeground(Theme.TEXT_SECONDARY); return l; }

    private JPanel createTopPanel() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(18, 22, 16, 22));
        card.setTopAccent(Theme.DANGER);
        JPanel p = new JPanel(new WrapLayout(FlowLayout.LEFT, 14, 8)); p.setOpaque(false);

        JPanel g1 = new JPanel(); g1.setLayout(new BoxLayout(g1, BoxLayout.Y_AXIS)); g1.setOpaque(false);
        g1.add(makeLbl("🔍 Tìm kiếm (Mã SV / Họ tên)")); g1.add(Box.createVerticalStrut(4));
        txtSearch = new RoundedField(26); txtSearch.setPlaceholder("Nhập từ khóa..."); txtSearch.setPreferredSize(new Dimension(340, 34));
        g1.add(txtSearch);

        JPanel g2 = new JPanel(); g2.setLayout(new BoxLayout(g2, BoxLayout.Y_AXIS)); g2.setOpaque(false);
        g2.add(makeLbl("📂 Trạng thái")); g2.add(Box.createVerticalStrut(4));
        cboTrangThai = new RoundedCombo<>(new String[]{"📊 Tất cả", "🔴 Chưa nộp", "🟡 Đang nợ", "🟢 Đã nộp đủ"});
        cboTrangThai.setPreferredSize(new Dimension(220, 34));
        g2.add(cboTrangThai);

        RoundedButton bLoc = new RoundedButton("Lọc", "primary");
        bLoc.setPreferredSize(new Dimension(130, 40));
        RoundedButton bLamMoi = new RoundedButton("Làm mới", "warning");
        bLamMoi.setPreferredSize(new Dimension(150, 40));
        bLoc.addActionListener(e -> loc());
        bLamMoi.addActionListener(e -> { cboTrangThai.setSelectedIndex(0); txtSearch.setText(""); loadData(); });

        p.add(g1); p.add(g2); p.add(Box.createHorizontalStrut(6));
        JPanel bp = new JPanel(); bp.setLayout(new BoxLayout(bp, BoxLayout.Y_AXIS)); bp.setOpaque(false);
        bp.add(Box.createVerticalStrut(18));
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); row.setOpaque(false);
        row.add(bLoc); row.add(bLamMoi); bp.add(row);
        p.add(bp);

        card.add(p, BorderLayout.CENTER);
        JPanel wrap = new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(card);
        return wrap;
    }

    private JPanel createTablePanel() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(12, 12, 12, 12));
        card.setTopAccent(Theme.WARNING);
        String[] cols = {"Mã CN", "Mã SV", "Họ tên", "Học kỳ", "Số tiền nợ", "Đã thu", "Còn lại", "Trạng thái", "Ngày C.Nhật"};
        model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new StyledTable(); table.setModel(model);
        table.getColumnModel().getColumn(0).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setPreferredWidth(90);
        table.getColumnModel().getColumn(2).setPreferredWidth(200);
        table.getColumnModel().getColumn(3).setPreferredWidth(140);
        table.getColumnModel().getColumn(4).setPreferredWidth(130);
        table.getColumnModel().getColumn(5).setPreferredWidth(130);
        table.getColumnModel().getColumn(6).setPreferredWidth(130);
        table.getColumnModel().getColumn(7).setPreferredWidth(110);
        table.getColumnModel().getColumn(8).setPreferredWidth(110);
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        sp.getViewport().setOpaque(false); sp.setOpaque(false); UiUtils.tuneScrollPane(sp);
        card.add(sp, BorderLayout.CENTER);
        JPanel wrap = new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(card);
        return wrap;
    }

    private JPanel createSummaryPanel() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(14, 20, 14, 20));
        card.setTopAccent(Theme.SUCCESS);

        ResponsiveGridPanel grid = new ResponsiveGridPanel(3, 220, 14, 12);
        lblTongNo = summaryItem("💸 Tổng tiền phải thu:", "0 VND", Theme.WARNING);
        lblTongDaThu = summaryItem("✅ Tổng đã thu:", "0 VND", Theme.SUCCESS);
        lblTongConLai = summaryItem("⚠ Tổng còn lại:", "0 VND", Theme.DANGER);
        grid.add(lblTongNo); grid.add(lblTongDaThu); grid.add(lblTongConLai);
        card.add(grid, BorderLayout.CENTER);

        JPanel wrap = new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(card);
        return wrap;
    }

    private JLabel summaryItem(String label, String value, Color accent) {
        JLabel l = new JLabel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, Theme.mix(accent, Color.WHITE, 0.2), getWidth(), getHeight(), Theme.mix(accent, Color.WHITE, 0.4));
                g2.setPaint(gp);
                g2.fill(new java.awt.geom.RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 14, 14));
                g2.setColor(new Color(255,255,255,100));
                g2.draw(new java.awt.geom.RoundRectangle2D.Float(0.5f, 0.5f, Math.max(1,getWidth()-1), Math.max(1,getHeight()-1), 14, 14));

                int available = Math.max(20, getWidth() - 36);
                g2.setFont(Theme.FONT_LABEL);
                g2.setColor(new Color(255,255,255, 240));
                FontMetrics fm1 = g2.getFontMetrics();
                g2.drawString(fit(label, fm1, available), 18, 25);

                g2.setFont(Theme.FONT_H2.deriveFont(Font.BOLD, 20f));
                g2.setColor(Color.WHITE);
                FontMetrics fm2 = g2.getFontMetrics();
                String v = fit(getText(), fm2, available);
                g2.drawString(v, 18, 57);
                g2.dispose();
            }
        };
        l.setText(value);
        l.setToolTipText(label + " " + value);
        l.setPreferredSize(new Dimension(220, 78));
        return l;
    }

    private static String fit(String text, FontMetrics fm, int maxWidth) {
        if (text == null) return "";
        if (fm.stringWidth(text) <= maxWidth) return text;
        String dots = "…";
        int dw = fm.stringWidth(dots);
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            if (fm.stringWidth(out.toString() + text.charAt(i)) + dw > maxWidth) break;
            out.append(text.charAt(i));
        }
        return out.append(dots).toString();
    }

    private void updateSummary(List<CongNo> list) {
        BigDecimal tongNo = BigDecimal.ZERO, tongDaThu = BigDecimal.ZERO, tongConLai = BigDecimal.ZERO;
        for (CongNo cn : list) {
            if (cn.getSoTienNo() != null) tongNo = tongNo.add(cn.getSoTienNo());
            if (cn.getSoTienDaThu() != null) tongDaThu = tongDaThu.add(cn.getSoTienDaThu());
            if (cn.getConLai() != null) tongConLai = tongConLai.add(cn.getConLai());
        }
        lblTongNo.setText(String.format("%,.0f VND", tongNo));
        lblTongDaThu.setText(String.format("%,.0f VND", tongDaThu));
        lblTongConLai.setText(String.format("%,.0f VND", tongConLai));
    }

    private void fillTable(List<CongNo> list) {
        model.setRowCount(0);
        for (CongNo cn : list) {
            model.addRow(new Object[]{cn.getMaCongNo(), cn.getMaSV(), cn.getHoTenSV(), cn.getTenHKNH(),
                cn.getSoTienNo(), cn.getSoTienDaThu(), cn.getConLai(), cn.getTrangThai(), cn.getNgayCapNhat()});
        }
    }

    private void loadData() {
        try {
            List<CongNo> list;
            if (UserSession.isSinhVien()) {
                list = cnService.getBySinhVien(UserSession.getMaSV());
            } else {
                list = cnService.getAll();
            }
            fillTable(list);
            updateSummary(list);
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    public void refreshData() { loadData(); }

    public void configureForRole() {
        if (UserSession.isSinhVien()) {
            txtSearch.setEnabled(false);
        }
    }

    private void loc() {
        try {
            List<CongNo> list;
            int idx = cboTrangThai.getSelectedIndex();
            String tt = idx == 1 ? "Chưa nộp" : idx == 2 ? "Đang nợ" : idx == 3 ? "Đã nộp đủ" : "";
            String kw = txtSearch.getText().trim();
            if (UserSession.isSinhVien()) {
                list = cnService.getBySinhVien(UserSession.getMaSV());
                if (!tt.isEmpty()) { final String ftt = tt; list.removeIf(cn -> !ftt.equals(cn.getTrangThai())); }
            } else if (!kw.isEmpty()) {
                list = cnService.search(kw);
                if (!tt.isEmpty()) { final String ftt = tt; list.removeIf(cn -> !ftt.equals(cn.getTrangThai())); }
            } else if (!tt.isEmpty()) {
                list = cnService.getAll();
                final String ftt = tt;
                list.removeIf(cn -> !ftt.equals(cn.getTrangThai()));
            } else list = cnService.getAll();
            fillTable(list); updateSummary(list);
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }
}
