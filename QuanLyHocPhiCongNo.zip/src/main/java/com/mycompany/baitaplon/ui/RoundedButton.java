package com.mycompany.baitaplon.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

/** Nút bo góc có kích thước tự bảo vệ theo nội dung để chữ không bị tràn. */
public class RoundedButton extends JButton {
    private Color bgColor;
    private Color hoverColor;
    private Color pressColor;
    private Color fgColor;
    private int radius = Theme.RADIUS;
    private boolean hasShadow = true;
    private boolean hover = false;
    private boolean pressed = false;

    public RoundedButton(String text, Color bg, Color fg) {
        super(text);
        this.bgColor = bg;
        this.hoverColor = Theme.mix(bg, Color.WHITE, 0.85);
        this.pressColor = Theme.mix(bg, Color.BLACK, 0.9);
        this.fgColor = Theme.readableForeground(bg, fg);
        init();
    }

    public RoundedButton(String text, Color bg, Color fg, String variant) {
        super(text);
        this.bgColor = bg;
        this.fgColor = Theme.readableForeground(bg, fg);
        this.hoverColor = Theme.mix(bg, Color.WHITE, 0.85);
        this.pressColor = Theme.mix(bg, Color.BLACK, 0.9);
        if ("outline".equals(variant)) this.hasShadow = false;
        init();
    }

    public RoundedButton(String text, String type) {
        super(text);
        this.fgColor = Color.WHITE;
        switch (type) {
            case "primary":   this.bgColor = Theme.PRIMARY;   break;
            case "success":   this.bgColor = Theme.SUCCESS;   break;
            case "danger":    this.bgColor = Theme.DANGER;    break;
            case "warning":   this.bgColor = Theme.WARNING;   break;
            case "secondary": this.bgColor = Theme.SECONDARY; break;
            case "purple":    this.bgColor = Theme.PURPLE;    break;
            case "info":      this.bgColor = Theme.INFO;      break;
            default:           this.bgColor = Theme.PRIMARY;
        }
        this.fgColor = Theme.readableForeground(this.bgColor, this.fgColor);
        this.hoverColor = Theme.mix(bgColor, Color.WHITE, 0.85);
        this.pressColor = Theme.mix(bgColor, Color.BLACK, 0.9);
        init();
    }

    private void init() {
        setOpaque(false);
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFocusPainted(false);
        setForeground(fgColor);
        setFont(Theme.FONT_H3);
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { hover = true; repaint(); }
            @Override public void mouseExited(MouseEvent e)  { hover = false; repaint(); }
            @Override public void mousePressed(MouseEvent e) { pressed = true; repaint(); }
            @Override public void mouseReleased(MouseEvent e){ pressed = false; repaint(); }
        });
    }

    public void setRadius(int r) { this.radius = r; }

    @Override
    public Dimension getPreferredSize() {
        Dimension requested = super.getPreferredSize();
        Font f = getFont() == null ? Theme.FONT_BODY : getFont();
        FontMetrics fm = getFontMetrics(f);
        Insets in = getInsets();
        int pad = hasShadow ? Theme.SHADOW_PAD * 2 : 0;
        int textW = fm.stringWidth(getText() == null ? "" : getText());
        int minW = textW + in.left + in.right + pad + 8;
        int minH = fm.getHeight() + in.top + in.bottom + (hasShadow ? 4 : 0);
        return new Dimension(Math.max(requested.width, minW), Math.max(requested.height, minH));
    }

    @Override
    public Dimension getMinimumSize() {
        Dimension p = getPreferredSize();
        // Cho phép co lại vừa phải, nhưng không thấp quá làm chữ chạm biên.
        return new Dimension(Math.min(p.width, Math.max(80, p.width - 60)), p.height);
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int pad = hasShadow ? Theme.SHADOW_PAD : 0;
        int x = pad, y = pad;
        int w = Math.max(1, getWidth() - pad * 2);
        int h = Math.max(1, getHeight() - pad * 2);

        if (hasShadow) {
            g2.setColor(new Color(0,0,0, 40));
            g2.fill(new RoundRectangle2D.Float(x, y + 2, w, h, radius, radius));
            g2.setColor(new Color(0,0,0, 25));
            g2.fill(new RoundRectangle2D.Float(x, y + 1, w, h, radius, radius));
        }

        Color fill = pressed ? pressColor : (hover ? hoverColor : bgColor);
        g2.setPaint(new GradientPaint(0, y, fill, 0, y + h, Theme.mix(fill, Color.BLACK, 0.95f)));
        g2.fill(new RoundRectangle2D.Float(x, y, w, h, radius, radius));

        g2.setPaint(new GradientPaint(0, y, new Color(255,255,255,120), 0, y + h / 2f, new Color(255,255,255,0)));
        g2.fill(new RoundRectangle2D.Float(x, y, w, Math.max(1, h / 2f), radius, radius));

        g2.setFont(getFont());
        FontMetrics fm = g2.getFontMetrics();
        Insets in = getInsets();
        int available = Math.max(8, getWidth() - in.left - in.right - pad * 2 - 6);
        String text = fitText(getText(), fm, available);
        int tw = fm.stringWidth(text);
        int tx = Math.max(in.left, (getWidth() - tw) / 2);
        int ty = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
        g2.setClip(in.left, 0, Math.max(1, getWidth() - in.left - in.right), getHeight());
        g2.setColor(fgColor);
        g2.drawString(text, tx, ty);
        g2.dispose();
    }

    private static String fitText(String text, FontMetrics fm, int maxWidth) {
        if (text == null) return "";
        if (fm.stringWidth(text) <= maxWidth) return text;
        String dots = "…";
        int dotsW = fm.stringWidth(dots);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            int nextW = fm.stringWidth(sb.toString() + text.charAt(i));
            if (nextW + dotsW > maxWidth) break;
            sb.append(text.charAt(i));
        }
        return sb.append(dots).toString();
    }
}
