package com.mycompany.baitaplon.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

/**
 * Lưới tự đổi số cột theo chiều rộng thực tế của màn hình.
 * Mục tiêu là tránh ép component quá nhỏ làm chữ bị cắt/lấn.
 */
public class ResponsiveGridPanel extends JPanel {
    private final int maxColumns;
    private final int minCellWidth;
    private final int hgap;
    private final int vgap;

    public ResponsiveGridPanel(int maxColumns, int minCellWidth, int hgap, int vgap) {
        this.maxColumns = Math.max(1, maxColumns);
        this.minCellWidth = Math.max(120, minCellWidth);
        this.hgap = Math.max(0, hgap);
        this.vgap = Math.max(0, vgap);
        setOpaque(false);
        setLayout(new ResponsiveLayout());
        addComponentListener(new ComponentAdapter() {
            @Override public void componentResized(ComponentEvent e) {
                revalidate();
                Container p = getParent();
                if (p != null) p.revalidate();
            }
        });
    }

    private int columnsFor(int availableWidth, int count) {
        if (count <= 0) return 1;
        if (availableWidth <= 0) return Math.min(maxColumns, count);
        int cols = Math.max(1, (availableWidth + hgap) / (minCellWidth + hgap));
        return Math.min(Math.min(maxColumns, count), cols);
    }

    private final class ResponsiveLayout implements LayoutManager2 {
        @Override public void addLayoutComponent(String name, Component comp) {}
        @Override public void addLayoutComponent(Component comp, Object constraints) {}
        @Override public void removeLayoutComponent(Component comp) {}
        @Override public float getLayoutAlignmentX(Container target) { return 0f; }
        @Override public float getLayoutAlignmentY(Container target) { return 0f; }
        @Override public void invalidateLayout(Container target) {}
        @Override public Dimension maximumLayoutSize(Container target) { return new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE); }

        @Override public Dimension preferredLayoutSize(Container parent) {
            return computeSize(parent, true);
        }

        @Override public Dimension minimumLayoutSize(Container parent) {
            return computeSize(parent, false);
        }

        private Dimension computeSize(Container parent, boolean preferred) {
            synchronized (parent.getTreeLock()) {
                Insets in = parent.getInsets();
                int count = visibleCount(parent);
                if (count == 0) return new Dimension(in.left + in.right, in.top + in.bottom);

                int width = parent.getWidth();
                if (width <= 0 && parent.getParent() != null) width = parent.getParent().getWidth();
                int contentW;
                if (width > 0) contentW = Math.max(minCellWidth, width - in.left - in.right);
                else contentW = maxColumns * minCellWidth + Math.max(0, maxColumns - 1) * hgap;

                int cols = columnsFor(contentW, count);
                int rows = (count + cols - 1) / cols;
                int[] rowHeights = new int[rows];
                int maxPrefWidth = minCellWidth;
                int vi = 0;
                for (Component c : parent.getComponents()) {
                    if (!c.isVisible()) continue;
                    Dimension d = preferred ? c.getPreferredSize() : c.getMinimumSize();
                    maxPrefWidth = Math.max(maxPrefWidth, d.width);
                    rowHeights[vi / cols] = Math.max(rowHeights[vi / cols], Math.max(1, d.height));
                    vi++;
                }
                int h = in.top + in.bottom + Math.max(0, rows - 1) * vgap;
                for (int rh : rowHeights) h += rh;
                int w = in.left + in.right + cols * Math.max(minCellWidth, Math.min(maxPrefWidth, contentW)) + Math.max(0, cols - 1) * hgap;
                if (width > 0) w = Math.max(1, width);
                return new Dimension(w, h);
            }
        }

        @Override public void layoutContainer(Container parent) {
            synchronized (parent.getTreeLock()) {
                Insets in = parent.getInsets();
                int count = visibleCount(parent);
                if (count == 0) return;
                int availableW = Math.max(1, parent.getWidth() - in.left - in.right);
                int cols = columnsFor(availableW, count);
                int rows = (count + cols - 1) / cols;
                int cellW = Math.max(1, (availableW - Math.max(0, cols - 1) * hgap) / cols);
                int[] rowHeights = new int[rows];
                int vi = 0;
                for (Component c : parent.getComponents()) {
                    if (!c.isVisible()) continue;
                    rowHeights[vi / cols] = Math.max(rowHeights[vi / cols], c.getPreferredSize().height);
                    vi++;
                }
                int y = in.top;
                vi = 0;
                int currentRow = 0;
                for (Component c : parent.getComponents()) {
                    if (!c.isVisible()) continue;
                    int row = vi / cols;
                    int col = vi % cols;
                    if (row != currentRow) {
                        y += rowHeights[currentRow] + vgap;
                        currentRow = row;
                    }
                    int x = in.left + col * (cellW + hgap);
                    c.setBounds(x, y, cellW, Math.max(1, rowHeights[row]));
                    vi++;
                }
            }
        }

        private int visibleCount(Container parent) {
            int n = 0;
            for (Component c : parent.getComponents()) if (c.isVisible()) n++;
            return n;
        }
    }
}
