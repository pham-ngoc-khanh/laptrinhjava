package com.mycompany.baitaplon.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class RoundedField extends JTextField {
    private int radius = Theme.RADIUS_SMALL;
    private String placeholder = "";

    public RoundedField() { super(); init(); }
    public RoundedField(int cols) { super(cols); init(); }

    private void init() {
        setOpaque(false);
        setFont(Theme.FONT_BODY);
        setForeground(Theme.TEXT);
        setCaretColor(Theme.PRIMARY);
        setBorder(new EmptyBorder(7, 12, 7, 12));
    }

    public void setPlaceholder(String p) { this.placeholder = p; repaint(); }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int w = getWidth() - 1, h = getHeight() - 1;
        g2.setColor(Color.WHITE);
        g2.fill(new RoundRectangle2D.Float(0, 0, w, h, radius, radius));
        g2.setColor(Theme.BORDER);
        g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, w - 1, h - 1, radius, radius));
        if (hasFocus()) {
            g2.setColor(Theme.PRIMARY_LIGHT);
            g2.setStroke(new BasicStroke(2));
            g2.draw(new RoundRectangle2D.Float(1, 1, w - 2, h - 2, radius, radius));
            g2.setStroke(new BasicStroke(1));
        }
        g2.dispose();
        super.paintComponent(g);
        if (getText().isEmpty() && !placeholder.isEmpty()) {
            Graphics2D gg = (Graphics2D) g.create();
            gg.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            gg.setColor(Theme.TEXT_MUTED);
            gg.setFont(Theme.FONT_BODY);
            FontMetrics fm = gg.getFontMetrics();
            int ty = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
            gg.drawString(placeholder, 12, ty);
            gg.dispose();
        }
    }
}
