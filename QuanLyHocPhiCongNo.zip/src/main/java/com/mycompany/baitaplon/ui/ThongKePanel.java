package com.mycompany.baitaplon.ui;

import com.mycompany.baitaplon.dao.BaoCaoDAO.ThangRow;
import com.mycompany.baitaplon.controller.BaoCaoController;
import com.mycompany.baitaplon.controller.HocPhiController;
import com.mycompany.baitaplon.controller.CongNoController;
import com.mycompany.baitaplon.controller.SinhVienController;
import com.mycompany.baitaplon.controller.ThanhToanController;
import com.mycompany.baitaplon.controller.YeuCauThanhToanController;
import com.mycompany.baitaplon.controller.HocKyNamHocController;
import com.mycompany.baitaplon.controller.TaiKhoanController;
import com.mycompany.baitaplon.model.*;
import com.mycompany.baitaplon.util.UserSession;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ThongKePanel extends JPanel {
    private SinhVienController svService = new SinhVienController();
    private HocPhiController hocPhiService = new HocPhiController();
    private CongNoController cnService = new CongNoController();
    private ThanhToanController ttService = new ThanhToanController();
    private BaoCaoController baoCaoService = new BaoCaoController();
    private YeuCauThanhToanController yeuCauService = new YeuCauThanhToanController();
    private HocKyNamHocController hocKyService = new HocKyNamHocController();
    private TaiKhoanController taiKhoanService = new TaiKhoanController();
    private boolean isStudentView;
    private Runnable onShowAllRecent;
    private Runnable onShowPaymentHistory;

    public void setOnShowAllRecent(Runnable r) {
        this.onShowAllRecent = r;
    }

    public void setOnShowPaymentHistory(Runnable r) {
        this.onShowPaymentHistory = r;
    }

    private JLabel lblTongDoanhThu, lblTongNoTonDong, lblSVTTDu, lblSVConNo;
    private DefaultTableModel modelRecent;
    private StyledTable tblRecent;
    private JPanel chartPanel;
    private List<ThangRow> adminMonthlyData = new ArrayList<>();

    private SinhVien currentSV;
    private JLabel lblSVHoTen, lblSVMSSV, lblSVNganh, lblSVKhoa, lblSVTrangThai;
    private JLabel lblSVTongNo, lblSVKyNay;
    private JLabel lblProgressLabel;
    private JPanel progressPanel;
    private DefaultTableModel modelUpcoming;

    public ThongKePanel() {
        super(new BorderLayout(14, 14));
        setOpaque(false);
        setBorder(new EmptyBorder(6, 6, 6, 6));
    }

    public void configureForRole() {
        isStudentView = UserSession.isSinhVien();
        this.removeAll();
        if (isStudentView) buildStudentView();
        else buildAdminView();
        this.revalidate();
        this.repaint();
    }

    // ======================================
    // ADMIN DASHBOARD
    // ======================================
    private void buildAdminView() {
        add(createAdminHeader(), BorderLayout.NORTH);
        add(createAdminBody(), BorderLayout.CENTER);
    }

    private JPanel createAdminHeader() {
        JPanel p = new JPanel(new WrapLayout(FlowLayout.LEFT, 18, 8));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(2, 4, 6, 4));
        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setOpaque(false);
        left.setPreferredSize(new Dimension(390, 54));
        JLabel t1 = new JLabel("🏛 Tổng quan Tài chính");
        t1.setFont(Theme.FONT_H2.deriveFont(Font.BOLD, 22f));
        t1.setForeground(Theme.TEXT);
        t1.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel t2 = new JLabel("Tổng hợp học phí, công nợ và giao dịch thanh toán");
        t2.setFont(Theme.FONT_BODY);
        t2.setForeground(Theme.TEXT_MUTED);
        t2.setAlignmentX(Component.LEFT_ALIGNMENT);
        t2.setToolTipText(t2.getText());
        left.add(t1); left.add(Box.createVerticalStrut(2)); left.add(t2);

        p.add(left);
        return p;
    }

    private JPanel createAdminBody() {
        JPanel p = new JPanel(new BorderLayout(14, 14));
        p.setOpaque(false);
        p.add(createAdminStatCards(), BorderLayout.NORTH);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setOpaque(false);
        split.setBorder(BorderFactory.createEmptyBorder());
        split.setDividerSize(4);
        split.setResizeWeight(0.65);

        CardPanel chartCard = new CardPanel(new BorderLayout());
        chartCard.setTopAccent(Theme.PRIMARY);
        chartCard.setBorder(new EmptyBorder(18, 22, 22, 22));
        JLabel title1 = new JLabel("📈 Doanh thu theo tháng (Học kỳ Thu)");
        title1.setFont(Theme.FONT_H2);
        title1.setForeground(Theme.TEXT);
        title1.setBorder(new EmptyBorder(0, 0, 10, 0));
        chartPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                drawAdminBarChart(g2, getWidth(), getHeight());
                g2.dispose();
            }
        };
        chartPanel.setOpaque(false);
        chartPanel.setPreferredSize(new Dimension(0, 300));
        chartCard.add(title1, BorderLayout.NORTH);
        chartCard.add(chartPanel, BorderLayout.CENTER);

        JPanel rightCol = new JPanel(new BorderLayout(0, 14));
        rightCol.setOpaque(false);

        CardPanel recentCard = new CardPanel(new BorderLayout());
        recentCard.setTopAccent(Theme.SECONDARY);
        recentCard.setBorder(new EmptyBorder(18, 20, 20, 20));
        JPanel title2 = new JPanel(new BorderLayout());
        title2.setOpaque(false);
        JLabel t2 = new JLabel("💳 Giao dịch gần đây");
        t2.setFont(Theme.FONT_H2);
        t2.setForeground(Theme.TEXT);
        JLabel more = new JLabel("<html><a href='#'>Xem tất cả →</a></html>");
        more.setCursor(new Cursor(Cursor.HAND_CURSOR));
        more.setForeground(Theme.PRIMARY);
        more.setFont(Theme.FONT_BODY);
        more.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (onShowAllRecent != null) onShowAllRecent.run();
            }
        });
        title2.add(t2, BorderLayout.WEST);
        title2.add(more, BorderLayout.EAST);
        title2.setBorder(new EmptyBorder(0, 0, 8, 0));
        String[] cols = {"Mã SV", "Số tiền", "Hình thức", "Trạng thái"};
        modelRecent = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tblRecent = new StyledTable();
        tblRecent.setModel(modelRecent);
        tblRecent.getColumnModel().getColumn(0).setPreferredWidth(110);
        tblRecent.getColumnModel().getColumn(1).setPreferredWidth(130);
        tblRecent.getColumnModel().getColumn(2).setPreferredWidth(120);
        tblRecent.getColumnModel().getColumn(3).setPreferredWidth(100);
        tblRecent.setRowHeight(32);
        tblRecent.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean isSel, boolean hasFocus, int row, int col) {
                JLabel c = (JLabel) super.getTableCellRendererComponent(t, v, isSel, hasFocus, row, col);
                c.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
                c.setFont(Theme.FONT_BODY);
                if (!isSel) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : Theme.SURFACE_ALT);
                    c.setForeground(Theme.TEXT);
                }
                if (!isSel && col == 1) { c.setForeground(Theme.PRIMARY_DARK); c.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD)); }
                if (!isSel && col == 3 && v != null) {
                    String s = v.toString();
                    if (s.contains("THÀNH") || s.contains("Đã")) { c.setForeground(Theme.SUCCESS); c.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD)); }
                    else if (s.contains("CHỜ")) { c.setForeground(Theme.WARNING); c.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD)); }
                    else if (s.contains("HỦY") || s.contains("Đang")) { c.setForeground(Theme.DANGER); c.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD)); }
                }
                return c;
            }
        });
        JScrollPane sp = new JScrollPane(tblRecent);
        sp.setOpaque(false); sp.getViewport().setOpaque(false);
        sp.setBorder(BorderFactory.createEmptyBorder());
        UiUtils.tuneScrollPane(sp);
        recentCard.add(title2, BorderLayout.NORTH);
        recentCard.add(sp, BorderLayout.CENTER);

        rightCol.add(recentCard, BorderLayout.CENTER);

        split.setLeftComponent(chartCard);
        split.setRightComponent(rightCol);
        p.add(split, BorderLayout.CENTER);
        return p;
    }

    private JPanel createAdminStatCards() {
        ResponsiveGridPanel p = new ResponsiveGridPanel(4, 215, 14, 12);
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(0, 0, 4, 0));
        p.add(miniStat("TỔNG DOANH THU", "0 VND", "Tổng số tiền đã thu", Theme.PRIMARY, Theme.SECONDARY, "📊"));
        p.add(miniStat("TỔNG NỢ TỒN ĐỌNG", "0 VND", "Số tiền còn phải thu", Theme.WARNING, Theme.DANGER, "⚠"));
        p.add(miniStat("SV ĐÃ THANH TOÁN ĐỦ", "0", "Sinh viên không còn nợ", Theme.SUCCESS, Theme.SECONDARY, "✅"));
        p.add(miniStat("SINH VIÊN CÒN NỢ", "0", "Sinh viên còn công nợ", Theme.DANGER, Theme.WARNING, "✖"));
        lblTongDoanhThu = statValueRef(p, 0);
        lblTongNoTonDong = statValueRef(p, 1);
        lblSVTTDu = statValueRef(p, 2);
        lblSVConNo = statValueRef(p, 3);
        return p;
    }

    private JLabel statValueRef(JPanel p, int idx) {
        Object ref = ((JComponent)p.getComponent(idx)).getClientProperty("valueLabel");
        return ref instanceof JLabel ? (JLabel) ref : new JLabel("0");
    }

    private JPanel miniStat(String badge, String value, String sub, Color c1, Color c2, String icon) {
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.setPreferredSize(new Dimension(215, 118));
        CardPanel card = new CardPanel(new BorderLayout());
        card.setCardBackground(Color.WHITE);
        card.setDrawShadow(true);
        card.setTopAccent(c1);

        JPanel body = new JPanel(new BorderLayout(10, 4)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, Theme.mix(c1, Color.WHITE, 0.16), getWidth(), getHeight(), Theme.mix(c2, Color.WHITE, 0.22));
                g2.setPaint(gp);
                g2.fill(new RoundRectangle2D.Float(6, 7, Math.max(1,getWidth()-12), Math.max(1,getHeight()-13), 16, 16));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        body.setOpaque(false);
        body.setBorder(new EmptyBorder(13, 18, 13, 16));

        JLabel b = new JLabel("<html>" + badge + "</html>");
        b.setFont(Theme.FONT_SMALL.deriveFont(Font.BOLD));
        b.setForeground(Theme.TEXT_ON_LIGHT);
        b.setToolTipText(badge);
        JLabel ic = new JLabel(icon, SwingConstants.RIGHT);
        ic.setFont(Theme.FONT_ICON.deriveFont(21f));
        ic.setForeground(Theme.TEXT_ON_LIGHT);
        ic.setPreferredSize(new Dimension(38, 28));
        JPanel top = new JPanel(new BorderLayout(6,0)); top.setOpaque(false); top.add(b,BorderLayout.CENTER); top.add(ic,BorderLayout.EAST);

        JLabel v = new JLabel(value);
        v.setFont(Theme.FONT_STAT_BIG.deriveFont(20f));
        v.setForeground(Theme.TEXT_ON_LIGHT);
        v.setToolTipText(value);
        JLabel subLabel = new JLabel("<html>" + sub + "</html>");
        subLabel.setFont(Theme.FONT_SMALL);
        subLabel.setForeground(Theme.TEXT_SECONDARY);
        subLabel.setToolTipText(sub);

        body.add(top, BorderLayout.NORTH);
        body.add(v, BorderLayout.CENTER);
        body.add(subLabel, BorderLayout.SOUTH);
        card.add(body, BorderLayout.CENTER);
        wrap.putClientProperty("valueLabel", v);
        wrap.add(card, BorderLayout.CENTER);
        return wrap;
    }

    private void drawAdminBarChart(Graphics2D g2, int w, int h) {
        int padL = 58, padR = 18, padT = 20, padB = 42;
        int cw = w - padL - padR, ch = h - padT - padB;
        if (cw <= 30 || ch <= 20) return;
        g2.setColor(Theme.BORDER);
        g2.drawLine(padL, padT, padL, h - padB);
        g2.drawLine(padL, h - padB, w - padR, h - padB);
        if (adminMonthlyData == null || adminMonthlyData.isEmpty()) {
            g2.setColor(Theme.TEXT_MUTED); g2.setFont(Theme.FONT_BODY);
            g2.drawString("Chưa có giao dịch thanh toán để hiển thị biểu đồ.", padL + 18, padT + 36);
            return;
        }
        BigDecimal max = BigDecimal.ZERO;
        for (ThangRow x : adminMonthlyData) if (x.doanhThu.compareTo(max) > 0) max = x.doanhThu;
        if (max.signum() == 0) return;
        int n = adminMonthlyData.size(); int groupW = Math.max(20, cw / n); int bw = Math.max(12, (int)(groupW * .55));
        for (int i = 0; i < n; i++) {
            ThangRow x = adminMonthlyData.get(i);
            int bh = (int)(ch * x.doanhThu.doubleValue() / max.doubleValue());
            int bx = padL + i * groupW + (groupW - bw) / 2, by = h - padB - bh;
            g2.setPaint(new GradientPaint(0, by, Theme.PRIMARY, 0, h - padB, Theme.SECONDARY));
            g2.fill(new RoundRectangle2D.Float(bx, by, bw, bh, 8, 8));
            if (n <= 12) {
                g2.setColor(Theme.TEXT_MUTED); g2.setFont(Theme.FONT_SMALL); FontMetrics fm = g2.getFontMetrics();
                String label = String.format("%02d/%02d", x.thang, x.nam % 100);
                g2.drawString(label, bx + bw/2 - fm.stringWidth(label)/2, h - padB + 17);
            }
        }
    }

    // ======================================
    // STUDENT PORTAL VIEW
    // ======================================
    private void buildStudentView() {
        loadCurrentStudent();
        add(createStudentHeader(), BorderLayout.NORTH);
        add(createStudentBody(), BorderLayout.CENTER);
    }

    private void loadCurrentStudent() {
        if (UserSession.getMaSV() != null) {
            try { currentSV = svService.getById(UserSession.getMaSV()); }
            catch (SQLException ignored) {}
        }
    }

    private JPanel createStudentHeader() {
        JPanel p = new JPanel(new WrapLayout(FlowLayout.LEFT, 12, 6));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(2, 4, 6, 4));
        JPanel left = new JPanel();
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setOpaque(false);
        JLabel t1 = new JLabel("💸 Tổng quan Học phí");
        t1.setFont(Theme.FONT_H2.deriveFont(Font.BOLD, 22f));
        t1.setForeground(Theme.TEXT);
        t1.setAlignmentX(Component.LEFT_ALIGNMENT);
        String ht = currentSV != null && currentSV.getHoTen() != null ? currentSV.getHoTen() : "";
        String mssv = currentSV != null && currentSV.getMaSV() != null ? currentSV.getMaSV() : "";
        JLabel t2 = new JLabel("Xin chào " + ht + " (MSSV: " + mssv + ")");
        t2.setFont(Theme.FONT_BODY);
        t2.setForeground(Theme.TEXT_MUTED);
        t2.setAlignmentX(Component.LEFT_ALIGNMENT);
        t2.setToolTipText(t2.getText());
        left.add(t1); left.add(Box.createVerticalStrut(2)); left.add(t2);
        p.add(left);
        return p;
    }

    private JPanel createStudentBody() {
        JPanel p = new JPanel(new BorderLayout(14, 14));
        p.setOpaque(false);

        ResponsiveGridPanel topRow = new ResponsiveGridPanel(3, 290, 14, 14);
        topRow.setOpaque(false);
        topRow.add(createStudentInfoCard());
        JPanel debt2col = new JPanel(new GridLayout(2, 1, 0, 14));
        debt2col.setOpaque(false);
        debt2col.add(debtSummaryCard("💰 Tổng dư nợ học phí", "Cần thanh toán trước 15/11/2023", "0 VND", Theme.DANGER, Theme.WARNING));
        debt2col.add(debtSummaryCard("✅ Đã thanh toán kỳ này", "Cập nhật cuối: 01/10/2023", "0 VND", Theme.SUCCESS, Theme.SECONDARY));
        topRow.add(debt2col);
        topRow.add(createPaymentSideCard());
        p.add(topRow, BorderLayout.NORTH);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setOpaque(false);
        split.setBorder(BorderFactory.createEmptyBorder());
        split.setDividerSize(4);
        split.setResizeWeight(0.65);
        split.setLeftComponent(createUpcomingFeesCard());
        split.setRightComponent(createProgressCard());
        p.add(split, BorderLayout.CENTER);

        lblSVTongNo = valFrom((JPanel)debt2col.getComponent(0));
        lblSVKyNay = valFrom((JPanel)debt2col.getComponent(1));
        return p;
    }

    private JLayeredPane debtSummaryLayers(JPanel p) {
        return null;
    }
    private JLabel valFrom(JPanel wrapPanel) {
        return (JLabel) wrapPanel.getClientProperty("valueLabel");
    }

    private JPanel createStudentInfoCard() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setTopAccent(Theme.PRIMARY);
        card.setBorder(new EmptyBorder(20, 22, 20, 22));
        JPanel header = new JPanel(new BorderLayout(14, 0));
        header.setOpaque(false);
        JPanel avatar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, Theme.PRIMARY, getWidth(), getHeight(), Theme.SECONDARY);
                g2.setPaint(gp);
                g2.fillOval(0, 0, 96, 96);
                g2.setColor(new Color(255,255,255,160));
                g2.drawOval(2, 2, 92, 92);
                String initials = "SV";
                if (currentSV != null && currentSV.getHoTen() != null) {
                    String[] parts = currentSV.getHoTen().trim().split("\\s+");
                    if (parts.length >= 2) initials = parts[0].substring(0,1) + parts[parts.length-1].substring(0,1);
                    else if (parts.length == 1) initials = parts[0].substring(0,1);
                    initials = initials.toUpperCase();
                }
                g2.setFont(Theme.FONT_H2.deriveFont(Font.BOLD, 34f));
                FontMetrics fm = g2.getFontMetrics();
                int tw = fm.stringWidth(initials);
                g2.setColor(Color.WHITE);
                g2.drawString(initials, (96 - tw)/2, (96 - fm.getHeight())/2 + fm.getAscent());
                g2.dispose();
            }
        };
        avatar.setOpaque(false);
        avatar.setPreferredSize(new Dimension(96, 96));
        JPanel rightInfo = new JPanel();
        rightInfo.setLayout(new BoxLayout(rightInfo, BoxLayout.Y_AXIS));
        rightInfo.setOpaque(false);
        JLabel bdg = new JLabel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, Theme.mix(Theme.PRIMARY, Color.WHITE, 0.18), getWidth(), 0, Theme.mix(Theme.SECONDARY, Color.WHITE, 0.22));
                g2.setPaint(gp);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 8, 8));
                g2.setFont(getFont());
                g2.setColor(Theme.PRIMARY_DARK);
                FontMetrics fm = g2.getFontMetrics();
                g2.drawString("🎓  THẺ SINH VIÊN ĐIỆN TỬ", 12, (getHeight() - fm.getHeight())/2 + fm.getAscent());
                g2.dispose();
            }
        };
        bdg.setFont(Theme.FONT_SMALL.deriveFont(Font.BOLD));
        bdg.setPreferredSize(new Dimension(200, 26));
        bdg.setAlignmentX(Component.LEFT_ALIGNMENT);
        lblSVHoTen = new JLabel(currentSV != null && currentSV.getHoTen() != null ? currentSV.getHoTen() : "—");
        lblSVHoTen.setFont(Theme.FONT_H2.deriveFont(Font.BOLD, 18f));
        lblSVHoTen.setForeground(Theme.TEXT);
        lblSVHoTen.setAlignmentX(Component.LEFT_ALIGNMENT);
        lblSVMSSV = new JLabel();
        lblSVNganh = new JLabel();
        lblSVKhoa = new JLabel();
        lblSVTrangThai = new JLabel();
        lblSVMSSV.setFont(Theme.FONT_BODY); lblSVMSSV.setForeground(Theme.TEXT_SECONDARY);
        lblSVNganh.setFont(Theme.FONT_BODY); lblSVNganh.setForeground(Theme.TEXT_SECONDARY);
        lblSVKhoa.setFont(Theme.FONT_BODY); lblSVKhoa.setForeground(Theme.TEXT_SECONDARY);
        lblSVTrangThai.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD)); lblSVTrangThai.setForeground(Theme.SUCCESS);
        lblSVMSSV.setAlignmentX(Component.LEFT_ALIGNMENT);
        lblSVNganh.setAlignmentX(Component.LEFT_ALIGNMENT);
        lblSVKhoa.setAlignmentX(Component.LEFT_ALIGNMENT);
        lblSVTrangThai.setAlignmentX(Component.LEFT_ALIGNMENT);
        updateSVLabels();
        rightInfo.add(bdg);
        rightInfo.add(Box.createVerticalStrut(8));
        rightInfo.add(lblSVHoTen);
        rightInfo.add(Box.createVerticalStrut(4));
        rightInfo.add(lblSVMSSV);
        rightInfo.add(Box.createVerticalStrut(2));
        rightInfo.add(lblSVNganh);
        rightInfo.add(Box.createVerticalStrut(2));
        rightInfo.add(lblSVKhoa);
        rightInfo.add(Box.createVerticalStrut(6));
        rightInfo.add(lblSVTrangThai);
        header.add(avatar, BorderLayout.WEST);
        header.add(rightInfo, BorderLayout.CENTER);
        card.add(header, BorderLayout.CENTER);
        JPanel wrap = new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(card); return wrap;
    }

    private void updateSVLabels() {
        if (currentSV == null) return;
        lblSVMSSV.setText("<html><b style='color:#475569'>MSSV:</b>  " + str(currentSV.getMaSV()) + "</html>");
        String tenNganh = currentSV.getTenNganh() != null ? currentSV.getTenNganh() : "—";
        if (currentSV.getMaNganh() != null && !currentSV.getMaNganh().isBlank()) {
            tenNganh = currentSV.getMaNganh() + " - " + tenNganh;
        }
        lblSVNganh.setText("<html><b style='color:#475569'>Ngành:</b>  " + tenNganh + "</html>");
        String khoaText;
        Integer kh = currentSV.getKhoaHoc();
        if (kh != null) {
            String thuTu = "";
            int num = kh % 100;
            if (num >= 20 && num <= 39) thuTu = "K" + num; else thuTu = "Khóa " + kh;
            khoaText = thuTu + " (" + kh + " - " + (kh + 4) + ")";
        } else {
            khoaText = "Chưa cập nhật";
        }
        lblSVKhoa.setText("<html><b style='color:#475569'>Khóa:</b>  " + khoaText + "</html>");
        lblSVTrangThai.setText("<html><span style='color:#10b981'>● Đang học</span>  <span style='color:#94a3b8'> |  </span><span style='color:#475569'>Lớp: " + str(currentSV.getTenLop()) + "</span></html>");
    }

    private JPanel debtSummaryCard(String title, String sub, String value, Color c1, Color c2) {
        final Color fc1 = c1, fc2 = c2;
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        CardPanel card = new CardPanel();
        card.setCardBackground(Color.WHITE);
        card.setDrawShadow(true);
        card.setTopAccent(fc1);
        card.setLayout(new BorderLayout());
        JPanel body = new JPanel(new BorderLayout(0, 2)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, Theme.mix(fc1, Color.WHITE, 0.15), getWidth(), getHeight(), Theme.mix(fc2, Color.WHITE, 0.22));
                g2.setPaint(gp);
                g2.fill(new RoundRectangle2D.Float(6, 6, getWidth() - 12, getHeight() - 12, 16, 16));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        body.setOpaque(false);
        body.setBorder(new EmptyBorder(14, 22, 14, 22));

        JLabel t = new JLabel(title);
        t.setFont(Theme.FONT_SMALL.deriveFont(Font.BOLD));
        t.setForeground(Theme.TEXT_ON_LIGHT);
        JLabel s = new JLabel(sub);
        s.setFont(Theme.FONT_SMALL);
        s.setForeground(Theme.TEXT_SECONDARY);
        JLabel v = new JLabel(value);
        v.setFont(Theme.FONT_STAT_BIG.deriveFont(22f));
        v.setForeground(Theme.TEXT_ON_LIGHT);

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(t, BorderLayout.NORTH);
        body.add(top, BorderLayout.NORTH);
        body.add(v, BorderLayout.CENTER);
        body.add(s, BorderLayout.SOUTH);

        wrap.putClientProperty("valueLabel", v);
        card.add(body, BorderLayout.CENTER);
        wrap.add(card, BorderLayout.CENTER);
        return wrap;
    }

    private JPanel createPaymentSideCard() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setTopAccent(Theme.PRIMARY);
        card.setBorder(new EmptyBorder(20, 22, 22, 22));
        JLabel t = new JLabel("⚡ Thanh toán ngay");
        t.setFont(Theme.FONT_H2);
        t.setForeground(Theme.TEXT);
        t.setBorder(new EmptyBorder(0, 0, 6, 0));
        JLabel des = new JLabel("<html><span style='color:#64748b'>Chọn phương thức thanh toán cho các khoản nợ hiện tại.</span></html>");
        des.setFont(Theme.FONT_SMALL);
        des.setBorder(new EmptyBorder(0, 0, 14, 0));

        final JPanel momo = payMethodRow("qr.png", "Chuyển khoản QR", "Quét mã VietQR / NAPAS 247", true);
        final JPanel bank = payMethodRow("cash.png", "Tiền mặt", "Nộp trực tiếp và gửi xác nhận", false);
        final JRadioButton rMomo = (JRadioButton) momo.getClientProperty("radio");
        final JRadioButton rBank = (JRadioButton) bank.getClientProperty("radio");
        final ButtonGroup payGroup = new ButtonGroup();
        payGroup.add(rMomo);
        payGroup.add(rBank);

        final Runnable syncPayRows = new Runnable() {
            @Override public void run() {
                boolean momoSele = rMomo.isSelected();
                momo.putClientProperty("selected", momoSele);
                bank.putClientProperty("selected", !momoSele);
                momo.repaint();
                bank.repaint();
            }
        };

        MouseAdapter rowClick = new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                JPanel which = (JPanel) e.getSource();
                if (which == momo) rMomo.setSelected(true);
                else rBank.setSelected(true);
                syncPayRows.run();
            }
        };
        momo.addMouseListener(rowClick);
        bank.addMouseListener(rowClick);
        rMomo.addActionListener(e -> syncPayRows.run());
        rBank.addActionListener(e -> syncPayRows.run());

        final RoundedButton pay = new RoundedButton("Mở trang thanh toán", "primary");
        pay.setPreferredSize(new Dimension(1, 46));
        pay.setFont(Theme.FONT_H3.deriveFont(Font.BOLD));
        pay.addActionListener(e -> {
            if (onShowPaymentHistory != null) onShowPaymentHistory.run();
        });

        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setOpaque(false);
        p.add(t, BorderLayout.NORTH);
        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setOpaque(false);
        body.add(des);
        body.add(Box.createVerticalStrut(4));
        body.add(momo);
        body.add(Box.createVerticalStrut(8));
        body.add(bank);
        body.add(Box.createVerticalStrut(16));
        body.add(pay);
        card.add(body);
        JPanel wrap = new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(card); return wrap;
    }

    private JPanel payMethodRow(String iconName, String name, String desc, boolean selected) {
        JPanel p = new JPanel(new BorderLayout(10, 0)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                Boolean sel = (Boolean) getClientProperty("selected");
                if (sel == null) sel = false;
                if (sel) {
                    GradientPaint gp = new GradientPaint(0, 0, Theme.mix(Theme.PRIMARY, Color.WHITE, 0.12), getWidth(), 0, Theme.mix(Theme.SECONDARY, Color.WHITE, 0.15));
                    g2.setPaint(gp);
                    g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                    g2.setColor(Theme.PRIMARY);
                    g2.setStroke(new BasicStroke(2));
                    g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth()-1, getHeight()-1, 12, 12));
                } else {
                    g2.setColor(Theme.SURFACE_ALT);
                    g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                    g2.setColor(Theme.BORDER);
                    g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth()-1, getHeight()-1, 12, 12));
                }
                g2.dispose();
                super.paintComponent(g);
            }
        };
        p.putClientProperty("selected", selected);
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(12, 14, 12, 14));
        JPanel ic = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (name.contains("MoMo")) {
                    g2.setColor(new Color(217, 37, 115));
                    g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
                    g2.setColor(Color.WHITE);
                    g2.setFont(Theme.FONT_H3.deriveFont(Font.BOLD, 14f));
                    FontMetrics fm = g2.getFontMetrics();
                    String s = "M";
                    int tw = fm.stringWidth(s);
                    g2.drawString(s, (getWidth()-tw)/2, (getHeight()-fm.getHeight())/2 + fm.getAscent());
                } else {
                    g2.setColor(new Color(30, 64, 175));
                    g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
                    g2.setColor(Color.WHITE);
                    g2.setFont(Theme.FONT_ICON.deriveFont(16f));
                    FontMetrics fm = g2.getFontMetrics();
                    String s = "🏦";
                    int tw = fm.stringWidth(s);
                    g2.drawString(s, (getWidth()-tw)/2, (getHeight()-fm.getHeight())/2 + fm.getAscent());
                }
                g2.dispose();
            }
        };
        ic.setOpaque(false);
        ic.setPreferredSize(new Dimension(42, 42));
        JPanel texts = new JPanel();
        texts.setLayout(new BoxLayout(texts, BoxLayout.Y_AXIS));
        texts.setOpaque(false);
        JLabel n = new JLabel(name);
        n.setFont(Theme.FONT_LABEL);
        n.setForeground(Theme.TEXT);
        JLabel d = new JLabel(desc);
        d.setFont(Theme.FONT_SMALL);
        d.setForeground(Theme.TEXT_MUTED);
        texts.add(n); texts.add(Box.createVerticalStrut(2)); texts.add(d);
        JRadioButton check = new JRadioButton();
        check.setOpaque(false);
        check.setSelected(selected);
        p.putClientProperty("radio", check);
        p.add(ic, BorderLayout.WEST);
        p.add(texts, BorderLayout.CENTER);
        p.add(check, BorderLayout.EAST);
        return p;
    }

    private JPanel createUpcomingFeesCard() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setTopAccent(Theme.INFO);
        card.setBorder(new EmptyBorder(18, 22, 22, 22));
        JLabel t = new JLabel("📋 Các khoản công nợ hiện tại");
        t.setFont(Theme.FONT_H2);
        t.setForeground(Theme.TEXT);
        t.setBorder(new EmptyBorder(0, 0, 12, 0));
        String[] cols = {"Nội dung", "Kỳ học", "Hạn chót", "Số tiền (VND)", "Trạng thái"};
        modelUpcoming = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        StyledTable tbl = new StyledTable();
        tbl.setModel(modelUpcoming);
        tbl.getColumnModel().getColumn(0).setPreferredWidth(220);
        tbl.getColumnModel().getColumn(1).setPreferredWidth(140);
        tbl.getColumnModel().getColumn(2).setPreferredWidth(120);
        tbl.getColumnModel().getColumn(3).setPreferredWidth(140);
        tbl.getColumnModel().getColumn(4).setPreferredWidth(110);
        tbl.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean isSel, boolean hasFocus, int row, int col) {
                JLabel c = (JLabel) super.getTableCellRendererComponent(t, v, isSel, hasFocus, row, col);
                c.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
                c.setFont(Theme.FONT_BODY);
                if (!isSel) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : Theme.SURFACE_ALT);
                    c.setForeground(Theme.TEXT);
                }
                if (!isSel && col == 4 && v != null) {
                    String s = v.toString();
                    if (s.contains("Đã")) { c.setForeground(Theme.SUCCESS); c.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD)); }
                    else { c.setForeground(Theme.DANGER); c.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD)); }
                }
                return c;
            }
        });
        JScrollPane sp = new JScrollPane(tbl);
        sp.setOpaque(false); sp.getViewport().setOpaque(false);
        sp.setBorder(BorderFactory.createEmptyBorder());
        UiUtils.tuneScrollPane(sp);
        sp.setPreferredSize(new Dimension(0, 200));
        card.add(t, BorderLayout.NORTH);
        card.add(sp, BorderLayout.CENTER);
        JPanel wrap = new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(card); return wrap;
    }

    private JPanel createProgressCard() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setTopAccent(Theme.PURPLE);
        card.setBorder(new EmptyBorder(20, 22, 22, 22));
        JLabel t = new JLabel("🎯 Tiến độ hoàn thành học phí");
        t.setFont(Theme.FONT_H2);
        t.setForeground(Theme.TEXT);
        t.setBorder(new EmptyBorder(0, 0, 14, 0));
        JLabel pct = new JLabel("28%");
        pct.setFont(Theme.FONT_STAT_BIG.deriveFont(36f));
        pct.setForeground(Theme.PRIMARY_DARK);
        pct.setHorizontalAlignment(SwingConstants.CENTER);
        lblProgressLabel = pct;
        progressPanel = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int h = getHeight();
                g2.setColor(Theme.SURFACE_ALT);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), 18, 18, 18));
                int p = 28;
                try { p = Integer.parseInt(lblProgressLabel.getText().replace("%","")); } catch (Exception ignored) {}
                GradientPaint gp = new GradientPaint(0, 0, Theme.PRIMARY, getWidth() * Math.max(0.1f, p/100f), 0, Theme.SECONDARY);
                g2.setPaint(gp);
                g2.fill(new RoundRectangle2D.Float(0, 0, (int)(getWidth() * Math.max(0, Math.min(1, p/100.0))), 18, 18, 18));
                g2.setColor(Theme.BORDER);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth()-1, 17, 18, 18));
                g2.dispose();
            }
        };
        progressPanel.setOpaque(false);
        progressPanel.setPreferredSize(new Dimension(0, 28));
        JPanel row = new JPanel(new GridLayout(2, 2, 12, 8));
        row.setOpaque(false);
        row.setBorder(new EmptyBorder(14, 0, 14, 0));
        row.add(progressSmallRow("⌛ Đã đóng:", "Xem số liệu phía trên", Theme.SUCCESS));
        row.add(progressSmallRow("⏳ Còn lại:", "Xem số liệu phía trên", Theme.DANGER));
        JLabel link = new JLabel("<html><a href='#'>Xem chi tiết lịch sử đóng phí →</a></html>");
        link.setCursor(new Cursor(Cursor.HAND_CURSOR));
        link.setForeground(Theme.PRIMARY);
        link.setFont(Theme.FONT_BODY);
        link.setHorizontalAlignment(SwingConstants.CENTER);
        link.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (onShowPaymentHistory != null) onShowPaymentHistory.run();
            }
        });
        card.add(t, BorderLayout.NORTH);
        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setOpaque(false);
        body.add(pct);
        body.add(Box.createVerticalStrut(8));
        body.add(progressPanel);
        body.add(Box.createVerticalStrut(12));
        body.add(row);
        body.add(Box.createVerticalStrut(6));
        body.add(link);
        card.add(body, BorderLayout.CENTER);
        JPanel wrap = new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(card); return wrap;
    }

    private JPanel progressSmallRow(String name, String value, Color c) {
        JPanel p = new JPanel(new BorderLayout(4, 3)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Theme.SURFACE_ALT);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
                g2.setColor(Theme.BORDER);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, Math.max(1,getWidth()-1), Math.max(1,getHeight()-1), 10, 10));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(8, 12, 8, 12));
        JLabel l = new JLabel(name);
        l.setFont(Theme.FONT_LABEL);
        l.setForeground(Theme.TEXT_SECONDARY);
        JLabel v = new JLabel(value);
        v.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD));
        v.setForeground(c);
        v.setToolTipText(value);
        p.add(l, BorderLayout.NORTH); p.add(v, BorderLayout.SOUTH);
        return p;
    }

    // ======================================
    // REFRESH - applies to both views
    // ======================================
    public void refreshData() {
        try {
            if (isStudentView) refreshStudentData();
            else refreshAdminData();
        } catch (Throwable e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi cập nhật Dashboard: " + e.getMessage(), "Thông báo", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void refreshAdminData() throws SQLException {
        List<CongNo> dsCN = cnService.getAll();
        BigDecimal tongDoanhThu = BigDecimal.ZERO, tongNo = BigDecimal.ZERO;
        java.util.Map<String, BigDecimal> noTheoSV = new java.util.HashMap<>();
        for (CongNo cnItem : dsCN) {
            if (cnItem.getSoTienDaThu() != null) tongDoanhThu = tongDoanhThu.add(cnItem.getSoTienDaThu());
            BigDecimal remain = cnItem.getConLai() == null ? BigDecimal.ZERO : cnItem.getConLai();
            tongNo = tongNo.add(remain);
            noTheoSV.put(cnItem.getMaSV(), noTheoSV.getOrDefault(cnItem.getMaSV(), BigDecimal.ZERO).add(remain));
        }
        int ttd = 0, conNoCount = 0;
        for (BigDecimal remain : noTheoSV.values()) { if (remain.signum() == 0) ttd++; else conNoCount++; }
        if (lblTongDoanhThu != null) lblTongDoanhThu.setText(String.format("%,.0f VND", tongDoanhThu));
        if (lblTongNoTonDong != null) lblTongNoTonDong.setText(String.format("%,.0f VND", tongNo));
        if (lblSVTTDu != null) lblSVTTDu.setText(String.format("%,d", ttd));
        if (lblSVConNo != null) lblSVConNo.setText(String.format("%,d", conNoCount));

        modelRecent.setRowCount(0);
        List<ThanhToan> dsTT = ttService.getAll();
        int limit = Math.min(6, dsTT.size());
        for (int i = 0; i < limit; i++) {
            ThanhToan tt = dsTT.get(i);
            modelRecent.addRow(new Object[]{tt.getMaSV(), String.format("%,.0f₫", tt.getSoTien()),
                    tt.getHinhThucThanhToan() == null ? "—" : tt.getHinhThucThanhToan(), "✅ ĐÃ GHI NHẬN"});
        }
        adminMonthlyData = baoCaoService.baoCaoDoanhThuTheoThang(null);
        if (chartPanel != null) chartPanel.repaint();
    }

    private void refreshStudentData() throws SQLException {
        if (currentSV == null) loadCurrentStudent();
        updateSVLabels();
        List<CongNo> dsCN = UserSession.getMaSV() != null ? cnService.getBySinhVien(UserSession.getMaSV()) : new ArrayList<>();
        BigDecimal tongPhaiThu = BigDecimal.ZERO, tongThu = BigDecimal.ZERO, tongConLai = BigDecimal.ZERO;
        for (CongNo cn : dsCN) {
            if (cn.getSoTienNo() != null) tongPhaiThu = tongPhaiThu.add(cn.getSoTienNo());
            if (cn.getSoTienDaThu() != null) tongThu = tongThu.add(cn.getSoTienDaThu());
            if (cn.getConLai() != null) tongConLai = tongConLai.add(cn.getConLai());
        }
        lblSVTongNo.setText(String.format("%,.0f VND", tongConLai));
        lblSVKyNay.setText(String.format("%,.0f VND", tongThu));
        int pct = tongPhaiThu.signum() == 0 ? 0 : tongThu.multiply(BigDecimal.valueOf(100)).divide(tongPhaiThu, 0, RoundingMode.HALF_UP).min(BigDecimal.valueOf(100)).intValue();
        lblProgressLabel.setText(pct + "%");
        if (progressPanel != null) progressPanel.repaint();

        modelUpcoming.setRowCount(0);
        for (CongNo cn : dsCN) {
            BigDecimal conLai = cn.getConLai() == null ? BigDecimal.ZERO : cn.getConLai();
            if (conLai.signum() > 0) {
                modelUpcoming.addRow(new Object[]{"Học phí còn phải nộp", cn.getTenHKNH(), cn.getNgayCapNhat(),
                        String.format("%,.0f", conLai), "● " + cn.getTrangThai()});
            }
        }
    }

    private String str(Object o) { return o == null || o.toString().isEmpty() ? "—" : o.toString(); }
}
