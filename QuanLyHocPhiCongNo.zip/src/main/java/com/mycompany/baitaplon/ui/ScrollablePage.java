package com.mycompany.baitaplon.ui;

import javax.swing.*;
import java.awt.*;

/** Viewport wrapper: luôn bám chiều rộng cửa sổ và cho phép cuộn dọc khi nội dung dài. */
public class ScrollablePage extends JPanel implements Scrollable {
    public ScrollablePage(JComponent content) {
        super(new BorderLayout());
        setOpaque(false);
        add(content, BorderLayout.CENTER);
    }

    @Override public Dimension getPreferredScrollableViewportSize() { return getPreferredSize(); }
    @Override public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction) { return 18; }
    @Override public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction) {
        return orientation == SwingConstants.VERTICAL ? Math.max(80, visibleRect.height - 60) : Math.max(80, visibleRect.width - 60);
    }
    @Override public boolean getScrollableTracksViewportWidth() { return true; }
    @Override public boolean getScrollableTracksViewportHeight() { return false; }
}
