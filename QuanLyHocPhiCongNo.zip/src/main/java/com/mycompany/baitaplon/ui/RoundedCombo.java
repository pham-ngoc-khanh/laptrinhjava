package com.mycompany.baitaplon.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicComboBoxUI;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

/** Combo bo góc. Mũi tên được vẽ bằng vector để không phụ thuộc font/emoji. */
public class RoundedCombo<E> extends JComboBox<E> {
    private int radius = Theme.RADIUS_SMALL;

    public RoundedCombo() { super(); init(); }
    public RoundedCombo(E[] items) { super(items); init(); }

    private void init() {
        setOpaque(false);
        setFont(Theme.FONT_BODY);
        setForeground(Theme.TEXT);
        setBackground(Color.WHITE);
        setBorder(new EmptyBorder(5, 12, 5, 34));
        setFocusable(true);

        setUI(new BasicComboBoxUI() {
            @Override
            protected JButton createArrowButton() {
                JButton button = new JButton() {
                    @Override
                    protected void paintComponent(Graphics g) {
                        Graphics2D g2 = (Graphics2D) g.create();
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                RenderingHints.VALUE_ANTIALIAS_ON);

                        int cx = getWidth() / 2;
                        int cy = getHeight() / 2 + 1;
                        int half = 4;
                        Polygon triangle = new Polygon(
                                new int[]{cx - half, cx + half, cx},
                                new int[]{cy - 2, cy - 2, cy + 3},
                                3);
                        g2.setColor(isEnabled() ? Theme.PRIMARY : Theme.TEXT_MUTED);
                        g2.fillPolygon(triangle);
                        g2.dispose();
                    }
                };
                button.setPreferredSize(new Dimension(30, 30));
                button.setMinimumSize(new Dimension(28, 28));
                button.setOpaque(false);
                button.setContentAreaFilled(false);
                button.setBorderPainted(false);
                button.setFocusPainted(false);
                button.setCursor(new Cursor(Cursor.HAND_CURSOR));
                button.setToolTipText("Mở danh sách");
                return button;
            }
        });

        setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                           boolean isSelected, boolean cellHasFocus) {
                JLabel c = (JLabel) super.getListCellRendererComponent(
                        list, value, index, isSelected, cellHasFocus);
                c.setFont(Theme.FONT_BODY);
                c.setBorder(new EmptyBorder(7, 10, 7, 10));
                if (isSelected) {
                    c.setBackground(Theme.PRIMARY_LIGHT);
                    c.setForeground(Theme.PRIMARY_DARK);
                } else {
                    c.setBackground(Color.WHITE);
                    c.setForeground(Theme.TEXT);
                }
                c.setToolTipText(value == null ? null : value.toString());
                return c;
            }
        });

        addActionListener(e -> {
            Object item = getSelectedItem();
            setToolTipText(item == null ? null : item.toString());
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        int w = Math.max(1, getWidth() - 1);
        int h = Math.max(1, getHeight() - 1);
        g2.setColor(Color.WHITE);
        g2.fill(new RoundRectangle2D.Float(0, 0, w, h, radius, radius));
        g2.setColor(Theme.BORDER);
        g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, w - 1, h - 1, radius, radius));
        if (hasFocus()) {
            g2.setColor(Theme.PRIMARY_LIGHT);
            g2.setStroke(new BasicStroke(2));
            g2.draw(new RoundRectangle2D.Float(1, 1, w - 2, h - 2, radius, radius));
        }
        g2.dispose();
        super.paintComponent(g);
    }
}
