package com.mycompany.baitaplon.dao;

import com.mycompany.baitaplon.model.CongNo;
import com.mycompany.baitaplon.util.DatabaseConnection;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CongNoDAO {
    private static final String BASE = "SELECT cn.*, sv.HoTen, hk.HocKy, hk.NamHoc FROM CongNo cn " +
            "LEFT JOIN SinhVien sv ON cn.MaSV=sv.MaSV LEFT JOIN HocKyNamHoc hk ON cn.MaHKNH=hk.MaHKNH ";

    public List<CongNo> getAll() throws SQLException { return query(BASE + "ORDER BY hk.NgayBatDau DESC, cn.MaSV", null); }
    public List<CongNo> getByMaSV(String maSV) throws SQLException { return query(BASE + "WHERE cn.MaSV=? ORDER BY hk.NgayBatDau DESC", new Object[]{maSV}); }
    public List<CongNo> getByTrangThai(String tt) throws SQLException { return query(BASE + "WHERE cn.TrangThai=? ORDER BY cn.ConLai DESC", new Object[]{tt}); }

    public List<CongNo> searchBySV(String keyword) throws SQLException {
        String kw = "%" + keyword + "%";
        return query(BASE + "WHERE cn.MaSV LIKE ? OR sv.HoTen LIKE ? ORDER BY hk.NgayBatDau DESC, cn.MaSV", new Object[]{kw, kw});
    }

    public BigDecimal getConLai(String maSV, String maHKNH) throws SQLException {
        String sql = "SELECT ConLai FROM CongNo WHERE MaSV=? AND MaHKNH=?";
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, maSV); ps.setString(2, maHKNH);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getBigDecimal(1) : null; }
        }
    }

    public boolean capNhatCongNo(String maSV, String maHKNH, BigDecimal soTienThu) throws SQLException {
        try (Connection c = DatabaseConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                capNhatCongNo(c, maSV, maHKNH, soTienThu);
                c.commit();
                return true;
            } catch (SQLException e) { c.rollback(); throw e; }
            finally { c.setAutoCommit(true); }
        }
    }

    void capNhatCongNo(Connection c, String maSV, String maHKNH, BigDecimal soTienThu) throws SQLException {
        if (soTienThu == null || soTienThu.signum() <= 0) throw new SQLException("Số tiền thanh toán phải lớn hơn 0.");
        BigDecimal conLai;
        String lock = "SELECT ConLai FROM CongNo WHERE MaSV=? AND MaHKNH=? FOR UPDATE";
        try (PreparedStatement ps = c.prepareStatement(lock)) {
            ps.setString(1, maSV); ps.setString(2, maHKNH);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) throw new SQLException("Chưa có công nợ cho sinh viên trong học kỳ này. Hãy tính học phí trước khi thanh toán.");
                conLai = rs.getBigDecimal(1);
            }
        }
        if (conLai == null || conLai.signum() <= 0) throw new SQLException("Khoản công nợ này đã được thanh toán đủ.");
        if (soTienThu.compareTo(conLai) > 0) {
            throw new SQLException("Số tiền nộp vượt số tiền còn nợ. Còn phải thu: " + String.format("%,.0f VND", conLai));
        }
        String update = "UPDATE CongNo SET SoTienDaThu=SoTienDaThu+?, ConLai=GREATEST(SoTienNo-(SoTienDaThu+?),0), " +
                "TrangThai=CASE WHEN GREATEST(SoTienNo-(SoTienDaThu+?),0)=0 THEN 'Đã nộp đủ' " +
                "WHEN SoTienDaThu+?>0 THEN 'Đang nợ' ELSE 'Chưa nộp' END, NgayCapNhat=CURDATE() " +
                "WHERE MaSV=? AND MaHKNH=?";
        try (PreparedStatement ps = c.prepareStatement(update)) {
            ps.setBigDecimal(1, soTienThu); ps.setBigDecimal(2, soTienThu); ps.setBigDecimal(3, soTienThu); ps.setBigDecimal(4, soTienThu);
            ps.setString(5, maSV); ps.setString(6, maHKNH);
            if (ps.executeUpdate() != 1) throw new SQLException("Không cập nhật được công nợ.");
        }
    }

    private List<CongNo> query(String sql, Object[] args) throws SQLException {
        List<CongNo> list = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (args != null) for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) list.add(map(rs)); }
        }
        return list;
    }

    private CongNo map(ResultSet rs) throws SQLException {
        CongNo cn = new CongNo();
        cn.setMaCongNo(rs.getInt("MaCongNo")); cn.setMaSV(rs.getString("MaSV")); cn.setHoTenSV(rs.getString("HoTen"));
        cn.setMaHKNH(rs.getString("MaHKNH")); cn.setTenHKNH("HK " + rs.getInt("HocKy") + " - " + rs.getString("NamHoc"));
        cn.setSoTienNo(rs.getBigDecimal("SoTienNo")); cn.setSoTienDaThu(rs.getBigDecimal("SoTienDaThu")); cn.setConLai(rs.getBigDecimal("ConLai"));
        cn.setTrangThai(rs.getString("TrangThai")); cn.setNgayCapNhat(rs.getString("NgayCapNhat")); return cn;
    }
}
