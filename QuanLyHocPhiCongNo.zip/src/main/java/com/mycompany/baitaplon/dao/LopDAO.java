package com.mycompany.baitaplon.dao;

import com.mycompany.baitaplon.model.Lop;
import com.mycompany.baitaplon.util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class LopDAO {
    public List<Lop> getAll() throws SQLException {
        List<Lop> list = new ArrayList<>();
        String sql = "SELECT * FROM Lop";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Lop l = new Lop();
                l.setMaLop(rs.getString("MaLop"));
                l.setTenLop(rs.getString("TenLop"));
                l.setMaNganh(rs.getString("MaNganh"));
                l.setKhoaHoc(rs.getInt("KhoaHoc"));
                list.add(l);
            }
        }
        return list;
    }

    public Lop getById(String maLop) throws SQLException {
        if (maLop == null) return null;
        String sql = "SELECT * FROM Lop WHERE MaLop = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maLop);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Lop l = new Lop();
                    l.setMaLop(rs.getString("MaLop"));
                    l.setTenLop(rs.getString("TenLop"));
                    l.setMaNganh(rs.getString("MaNganh"));
                    l.setKhoaHoc(rs.getInt("KhoaHoc"));
                    return l;
                }
            }
        }
        return null;
    }
}
