package com.mycompany.baitaplon.dao;

import com.mycompany.baitaplon.model.HocPhan;
import com.mycompany.baitaplon.util.DatabaseConnection;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HocPhanDAO {
    public List<HocPhan> getAll() throws SQLException {
        List<HocPhan> list = new ArrayList<>();
        String sql = "SELECT hp.*, n.TenNganh FROM HocPhan hp LEFT JOIN Nganh n ON hp.MaNganh = n.MaNganh";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                HocPhan hp = new HocPhan();
                hp.setMaHP(rs.getString("MaHP"));
                hp.setTenHP(rs.getString("TenHP"));
                hp.setSoTinChi(rs.getInt("SoTinChi"));
                hp.setHocPhiMotTinChi(rs.getBigDecimal("HocPhiMotTinChi"));
                hp.setMaNganh(rs.getString("MaNganh"));
                hp.setTenNganh(rs.getString("TenNganh"));
                list.add(hp);
            }
        }
        return list;
    }

    public HocPhan getById(String maHP) throws SQLException {
        String sql = "SELECT hp.*, n.TenNganh FROM HocPhan hp LEFT JOIN Nganh n ON hp.MaNganh = n.MaNganh WHERE MaHP = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maHP);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    HocPhan hp = new HocPhan();
                    hp.setMaHP(rs.getString("MaHP"));
                    hp.setTenHP(rs.getString("TenHP"));
                    hp.setSoTinChi(rs.getInt("SoTinChi"));
                    hp.setHocPhiMotTinChi(rs.getBigDecimal("HocPhiMotTinChi"));
                    hp.setMaNganh(rs.getString("MaNganh"));
                    hp.setTenNganh(rs.getString("TenNganh"));
                    return hp;
                }
            }
        }
        return null;
    }

    public boolean insert(HocPhan hp) throws SQLException {
        String sql = "INSERT INTO HocPhan (MaHP, TenHP, SoTinChi, HocPhiMotTinChi, MaNganh) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, hp.getMaHP());
            ps.setString(2, hp.getTenHP());
            ps.setInt(3, hp.getSoTinChi());
            ps.setBigDecimal(4, hp.getHocPhiMotTinChi() != null ? hp.getHocPhiMotTinChi() : BigDecimal.ZERO);
            ps.setString(5, hp.getMaNganh());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean update(HocPhan hp) throws SQLException {
        String sql = "UPDATE HocPhan SET TenHP=?, SoTinChi=?, HocPhiMotTinChi=?, MaNganh=? WHERE MaHP=?";
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                java.util.List<String[]> affected = new java.util.ArrayList<>();
                try (PreparedStatement ps = conn.prepareStatement("SELECT DISTINCT MaSV,MaHKNH FROM DangKyHocPhan WHERE MaHP=?")) {
                    ps.setString(1, hp.getMaHP());
                    try (ResultSet rs = ps.executeQuery()) { while (rs.next()) affected.add(new String[]{rs.getString(1),rs.getString(2)}); }
                }
                int n;
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, hp.getTenHP()); ps.setInt(2, hp.getSoTinChi());
                    ps.setBigDecimal(3, hp.getHocPhiMotTinChi() != null ? hp.getHocPhiMotTinChi() : BigDecimal.ZERO);
                    ps.setString(4, hp.getMaNganh()); ps.setString(5, hp.getMaHP()); n = ps.executeUpdate();
                }
                HocPhiDAO phiDAO = new HocPhiDAO();
                for (String[] a : affected) phiDAO.tinhHocPhi(conn, a[0], a[1]);
                conn.commit(); return n > 0;
            } catch (SQLException e) { conn.rollback(); throw e; }
            finally { conn.setAutoCommit(true); }
        }
    }

    public boolean delete(String maHP) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            try (PreparedStatement check = conn.prepareStatement("SELECT COUNT(*) FROM DangKyHocPhan WHERE MaHP=?")) {
                check.setString(1, maHP);
                try (ResultSet rs = check.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) throw new SQLException("Không thể xóa học phần đã có sinh viên đăng ký. Hãy hủy các đăng ký trước.");
                }
            }
            try (PreparedStatement ps = conn.prepareStatement("DELETE FROM HocPhan WHERE MaHP=?")) { ps.setString(1, maHP); return ps.executeUpdate() > 0; }
        }
    }

}
