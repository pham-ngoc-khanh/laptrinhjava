package com.mycompany.baitaplon.dao;

import com.mycompany.baitaplon.model.HocKyNamHoc;
import com.mycompany.baitaplon.util.DatabaseConnection;
import java.sql.*;
import java.util.*;

public class HocKyNamHocDAO {
    public List<HocKyNamHoc> getAll() throws SQLException {
        List<HocKyNamHoc> list=new ArrayList<>();
        try(Connection c=DatabaseConnection.getConnection();PreparedStatement ps=c.prepareStatement("SELECT * FROM HocKyNamHoc ORDER BY NgayBatDau DESC, NamHoc DESC, HocKy DESC");ResultSet rs=ps.executeQuery()){
            while(rs.next()){HocKyNamHoc h=new HocKyNamHoc();h.setMaHKNH(rs.getString("MaHKNH"));h.setHocKy(rs.getInt("HocKy"));h.setNamHoc(rs.getString("NamHoc"));h.setNgayBatDau(rs.getString("NgayBatDau"));h.setNgayKetThuc(rs.getString("NgayKetThuc"));list.add(h);}
        }return list;
    }
    public boolean insert(HocKyNamHoc h)throws SQLException{return save(h,false);}
    public boolean update(HocKyNamHoc h)throws SQLException{return save(h,true);}
    private boolean save(HocKyNamHoc h,boolean update)throws SQLException{
        String sql=update?"UPDATE HocKyNamHoc SET HocKy=?,NamHoc=?,NgayBatDau=?,NgayKetThuc=? WHERE MaHKNH=?":"INSERT INTO HocKyNamHoc(HocKy,NamHoc,NgayBatDau,NgayKetThuc,MaHKNH) VALUES(?,?,?,?,?)";
        try(Connection c=DatabaseConnection.getConnection();PreparedStatement ps=c.prepareStatement(sql)){
            ps.setInt(1,h.getHocKy());ps.setString(2,h.getNamHoc());
            if(h.getNgayBatDau()==null||h.getNgayBatDau().isBlank())ps.setNull(3,Types.DATE);else ps.setDate(3,java.sql.Date.valueOf(h.getNgayBatDau()));
            if(h.getNgayKetThuc()==null||h.getNgayKetThuc().isBlank())ps.setNull(4,Types.DATE);else ps.setDate(4,java.sql.Date.valueOf(h.getNgayKetThuc()));
            ps.setString(5,h.getMaHKNH());return ps.executeUpdate()>0;
        }
    }
    public boolean delete(String ma)throws SQLException{
        try(Connection c=DatabaseConnection.getConnection()){
            String[] tables={"DangKyHocPhan","HocPhi","CongNo","YeuCauThanhToan","ThanhToan"};
            for(String t:tables)try(PreparedStatement ps=c.prepareStatement("SELECT COUNT(*) FROM "+t+" WHERE MaHKNH=?")){ps.setString(1,ma);try(ResultSet rs=ps.executeQuery()){rs.next();if(rs.getInt(1)>0)throw new SQLException("Không thể xóa học kỳ đã phát sinh dữ liệu "+t+".");}}
            try(PreparedStatement ps=c.prepareStatement("DELETE FROM HocKyNamHoc WHERE MaHKNH=?")){ps.setString(1,ma);return ps.executeUpdate()>0;}
        }
    }
}
