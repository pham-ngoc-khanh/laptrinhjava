package com.mycompany.baitaplon.dao;

import com.mycompany.baitaplon.util.DatabaseConnection;
import java.math.BigDecimal;
import java.sql.*;
import java.util.*;

public class BaoCaoDAO {
    public static class KhoaRow {
        public String tenKhoa; public int soSinhVien; public BigDecimal phaiThu=BigDecimal.ZERO, daThu=BigDecimal.ZERO, conLai=BigDecimal.ZERO;
    }
    public static class ThangRow {
        public int nam, thang; public BigDecimal doanhThu=BigDecimal.ZERO;
        public String label(){ return String.format("%02d/%d", thang, nam); }
    }

    public List<String> getNamHoc() throws SQLException {
        List<String> list=new ArrayList<>();
        try(Connection c=DatabaseConnection.getConnection(); PreparedStatement ps=c.prepareStatement("SELECT DISTINCT NamHoc FROM HocKyNamHoc ORDER BY NamHoc DESC"); ResultSet rs=ps.executeQuery()){
            while(rs.next()) list.add(rs.getString(1));
        } return list;
    }

    public List<KhoaRow> getByKhoa(String namHoc) throws SQLException {
        String sql="SELECT COALESCE(k.TenKhoa,'Chưa phân khoa') TenKhoa, COUNT(DISTINCT cn.MaSV) SoSV, " +
                "COALESCE(SUM(cn.SoTienNo),0) PhaiThu, COALESCE(SUM(cn.SoTienDaThu),0) DaThu, COALESCE(SUM(cn.ConLai),0) ConLai " +
                "FROM CongNo cn JOIN HocKyNamHoc hk ON cn.MaHKNH=hk.MaHKNH " +
                "LEFT JOIN SinhVien sv ON cn.MaSV=sv.MaSV LEFT JOIN Lop l ON sv.MaLop=l.MaLop " +
                "LEFT JOIN Nganh n ON l.MaNganh=n.MaNganh LEFT JOIN Khoa k ON n.MaKhoa=k.MaKhoa " +
                (namHoc==null?"":"WHERE hk.NamHoc=? ") + "GROUP BY k.MaKhoa,k.TenKhoa ORDER BY PhaiThu DESC";
        List<KhoaRow> list=new ArrayList<>();
        try(Connection c=DatabaseConnection.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
            if(namHoc!=null) ps.setString(1,namHoc);
            try(ResultSet rs=ps.executeQuery()){while(rs.next()){KhoaRow r=new KhoaRow();r.tenKhoa=rs.getString("TenKhoa");r.soSinhVien=rs.getInt("SoSV");r.phaiThu=rs.getBigDecimal("PhaiThu");r.daThu=rs.getBigDecimal("DaThu");r.conLai=rs.getBigDecimal("ConLai");list.add(r);}}
        } return list;
    }

    public List<ThangRow> getTheoThang(String namHoc) throws SQLException {
        String sql="SELECT YEAR(tt.NgayThanhToan) Nam, MONTH(tt.NgayThanhToan) Thang, COALESCE(SUM(tt.SoTien),0) DoanhThu " +
                "FROM ThanhToan tt JOIN HocKyNamHoc hk ON tt.MaHKNH=hk.MaHKNH " + (namHoc==null?"":"WHERE hk.NamHoc=? ") +
                "GROUP BY YEAR(tt.NgayThanhToan),MONTH(tt.NgayThanhToan) ORDER BY Nam,Thang";
        List<ThangRow> list=new ArrayList<>();
        try(Connection c=DatabaseConnection.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
            if(namHoc!=null) ps.setString(1,namHoc);
            try(ResultSet rs=ps.executeQuery()){while(rs.next()){ThangRow r=new ThangRow();r.nam=rs.getInt("Nam");r.thang=rs.getInt("Thang");r.doanhThu=rs.getBigDecimal("DoanhThu");list.add(r);}}
        } return list;
    }

    public int countStudents(String namHoc) throws SQLException {
        String sql = namHoc == null ? "SELECT COUNT(*) FROM SinhVien" :
                "SELECT COUNT(DISTINCT cn.MaSV) FROM CongNo cn JOIN HocKyNamHoc hk ON cn.MaHKNH=hk.MaHKNH WHERE hk.NamHoc=?";
        try(Connection c=DatabaseConnection.getConnection(); PreparedStatement ps=c.prepareStatement(sql)){
            if(namHoc!=null) ps.setString(1,namHoc);
            try(ResultSet rs=ps.executeQuery()){rs.next();return rs.getInt(1);}
        }
    }
}
