package com.mycompany.baitaplon.dao;

import com.mycompany.baitaplon.model.DangKyHocPhan;
import com.mycompany.baitaplon.util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DangKyHocPhanDAO {
    private static final String BASE =
            "SELECT dk.MaDKHP, dk.MaSV, sv.HoTen, dk.MaHP, hp.TenHP, hp.SoTinChi, " +
            "nhhp.HocPhiMotTinChi AS HocPhiMotTinChi, " +
            "dk.MaHKNH, hk.HocKy, hk.NamHoc, dk.NgayDangKy " +
            "FROM DangKyHocPhan dk " +
            "JOIN SinhVien sv ON dk.MaSV=sv.MaSV " +
            "JOIN HocPhan hp ON dk.MaHP=hp.MaHP " +
            "JOIN HocKyNamHoc hk ON dk.MaHKNH=hk.MaHKNH " +
            "LEFT JOIN NamHocHocPhi nhhp ON nhhp.MaNam=(SELECT MAX(n2.MaNam) FROM NamHocHocPhi n2 WHERE n2.NamHoc=hk.NamHoc) ";

    public List<DangKyHocPhan> getAll() throws SQLException {
        return query(BASE + "ORDER BY hk.NgayBatDau DESC, sv.MaSV, hp.MaHP", null);
    }

    public List<DangKyHocPhan> getByMaSV(String maSV) throws SQLException {
        return query(BASE + "WHERE dk.MaSV=? ORDER BY hk.NgayBatDau DESC, hp.MaHP", maSV);
    }

    public DangKyHocPhan getById(int maDKHP) throws SQLException {
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(BASE + "WHERE dk.MaDKHP=?")) {
            ps.setInt(1, maDKHP);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    public List<DangKyHocPhan> search(String keyword) throws SQLException {
        List<DangKyHocPhan> list = new ArrayList<>();
        String sql = BASE + "WHERE dk.MaSV LIKE ? OR sv.HoTen LIKE ? OR hp.MaHP LIKE ? OR hp.TenHP LIKE ? " +
                "ORDER BY hk.NgayBatDau DESC, sv.MaSV, hp.MaHP";
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            String kw = "%" + keyword + "%";
            for (int i = 1; i <= 4; i++) ps.setString(i, kw);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) list.add(map(rs)); }
        }
        return list;
    }

    private List<DangKyHocPhan> query(String sql, String arg) throws SQLException {
        List<DangKyHocPhan> list = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (arg != null) ps.setString(1, arg);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) list.add(map(rs)); }
        }
        return list;
    }

    public boolean insert(String maSV, String maHP, String maHKNH, Date ngayDangKy) throws SQLException {
        String check = "SELECT COUNT(*) FROM DangKyHocPhan WHERE MaSV=? AND MaHP=? AND MaHKNH=?";
        String insert = "INSERT INTO DangKyHocPhan(MaSV,MaHP,MaHKNH,NgayDangKy) VALUES(?,?,?,?)";
        try (Connection c = DatabaseConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                try (PreparedStatement ps = c.prepareStatement(check)) {
                    ps.setString(1, maSV); ps.setString(2, maHP); ps.setString(3, maHKNH);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next() && rs.getInt(1) > 0) throw new SQLException("Sinh viên đã đăng ký học phần này trong học kỳ đã chọn.");
                    }
                }
                try (PreparedStatement ps = c.prepareStatement(insert)) {
                    ps.setString(1, maSV); ps.setString(2, maHP); ps.setString(3, maHKNH); ps.setDate(4, ngayDangKy);
                    ps.executeUpdate();
                }
                new HocPhiDAO().tinhHocPhi(c, maSV, maHKNH);
                c.commit();
                return true;
            } catch (SQLException e) { c.rollback(); throw e; }
            finally { c.setAutoCommit(true); }
        }
    }

    public boolean delete(int maDKHP) throws SQLException {
        try (Connection c = DatabaseConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                String maSV, maHKNH;
                try (PreparedStatement ps = c.prepareStatement("SELECT MaSV,MaHKNH FROM DangKyHocPhan WHERE MaDKHP=? FOR UPDATE")) {
                    ps.setInt(1, maDKHP);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) return false;
                        maSV = rs.getString(1); maHKNH = rs.getString(2);
                    }
                }
                int count;
                try (PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM DangKyHocPhan WHERE MaSV=? AND MaHKNH=?")) {
                    ps.setString(1, maSV); ps.setString(2, maHKNH);
                    try (ResultSet rs = ps.executeQuery()) { rs.next(); count = rs.getInt(1); }
                }
                try (PreparedStatement ps = c.prepareStatement("SELECT COALESCE(SUM(SoTien),0) FROM ThanhToan WHERE MaSV=? AND MaHKNH=?")) {
                    ps.setString(1, maSV); ps.setString(2, maHKNH);
                    try (ResultSet rs = ps.executeQuery()) {
                        rs.next();
                        if (rs.getBigDecimal(1).signum() > 0) {
                            throw new SQLException("Không thể hủy đăng ký học phần sau khi học kỳ này đã phát sinh thanh toán. Hãy xử lý điều chỉnh/hoàn tiền tại Phòng Tài vụ trước.");
                        }
                    }
                }
                try (PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM YeuCauThanhToan WHERE MaSV=? AND MaHKNH=? AND TrangThai='CHO_XAC_NHAN'")) {
                    ps.setString(1, maSV); ps.setString(2, maHKNH);
                    try (ResultSet rs = ps.executeQuery()) {
                        rs.next();
                        if (rs.getInt(1) > 0) {
                            throw new SQLException("Không thể hủy đăng ký khi sinh viên đang có yêu cầu thanh toán chờ xác nhận. Hãy xử lý/hủy yêu cầu thanh toán trước.");
                        }
                    }
                }
                try (PreparedStatement ps = c.prepareStatement("DELETE FROM DangKyHocPhan WHERE MaDKHP=?")) {
                    ps.setInt(1, maDKHP);
                    if (ps.executeUpdate() != 1) throw new SQLException("Không xóa được đăng ký học phần.");
                }
                if (count > 1) {
                    new HocPhiDAO().tinhHocPhi(c, maSV, maHKNH);
                } else {
                    try (PreparedStatement ps = c.prepareStatement("DELETE FROM CongNo WHERE MaSV=? AND MaHKNH=?")) { ps.setString(1, maSV); ps.setString(2, maHKNH); ps.executeUpdate(); }
                    try (PreparedStatement ps = c.prepareStatement("DELETE FROM HocPhi WHERE MaSV=? AND MaHKNH=?")) { ps.setString(1, maSV); ps.setString(2, maHKNH); ps.executeUpdate(); }
                }
                c.commit(); return true;
            } catch (SQLException e) { c.rollback(); throw e; }
            finally { c.setAutoCommit(true); }
        }
    }

    private DangKyHocPhan map(ResultSet rs) throws SQLException {
        DangKyHocPhan d = new DangKyHocPhan();
        d.setMaDKHP(rs.getInt("MaDKHP"));
        d.setMaSV(rs.getString("MaSV"));
        d.setHoTenSV(rs.getString("HoTen"));
        d.setMaHP(rs.getString("MaHP"));
        d.setTenHP(rs.getString("TenHP"));
        d.setSoTinChi(rs.getInt("SoTinChi"));
        d.setHocPhiMotTinChi(rs.getBigDecimal("HocPhiMotTinChi"));
        d.setMaHKNH(rs.getString("MaHKNH"));
        d.setTenHKNH("HK " + rs.getInt("HocKy") + " - " + rs.getString("NamHoc"));
        d.setNgayDangKy(rs.getString("NgayDangKy"));
        return d;
    }
}
