package com.mycompany.baitaplon.dao;

import com.mycompany.baitaplon.model.YeuCauThanhToan;
import com.mycompany.baitaplon.util.DatabaseConnection;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class YeuCauThanhToanDAO {
    private final CongNoDAO congNoDAO = new CongNoDAO();
    private static final String BASE =
            "SELECT yc.*, sv.HoTen, hk.HocKy, hk.NamHoc FROM YeuCauThanhToan yc " +
            "LEFT JOIN SinhVien sv ON yc.MaSV=sv.MaSV " +
            "LEFT JOIN HocKyNamHoc hk ON yc.MaHKNH=hk.MaHKNH ";

    public List<YeuCauThanhToan> getPending() throws SQLException {
        return query(BASE + "WHERE yc.TrangThai='CHO_XAC_NHAN' ORDER BY yc.NgayGui ASC, yc.MaYeuCau ASC", null);
    }

    public List<YeuCauThanhToan> getByMaSV(String maSV) throws SQLException {
        return query(BASE + "WHERE yc.MaSV=? ORDER BY yc.NgayGui DESC, yc.MaYeuCau DESC", new Object[]{maSV});
    }

    public int getPendingCount() throws SQLException {
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM YeuCauThanhToan WHERE TrangThai='CHO_XAC_NHAN'");
             ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getInt(1);
        }
    }

    public BigDecimal getPendingAmount(String maSV, String maHKNH) throws SQLException {
        String sql = "SELECT COALESCE(SUM(SoTien),0) FROM YeuCauThanhToan " +
                "WHERE MaSV=? AND MaHKNH=? AND TrangThai='CHO_XAC_NHAN'";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, maSV);
            ps.setString(2, maHKNH);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                BigDecimal value = rs.getBigDecimal(1);
                return value == null ? BigDecimal.ZERO : value;
            }
        }
    }

    public boolean cancelPending(int maYeuCau, String maSV) throws SQLException {
        String sql = "UPDATE YeuCauThanhToan SET TrangThai='DA_HUY',NguoiXuLy='Sinh viên',NgayXuLy=NOW(),LyDoTuChoi=NULL " +
                "WHERE MaYeuCau=? AND MaSV=? AND TrangThai='CHO_XAC_NHAN'";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, maYeuCau);
            ps.setString(2, maSV);
            return ps.executeUpdate() == 1;
        }
    }

    public boolean createRequest(YeuCauThanhToan yc) throws SQLException {
        if (yc == null || yc.getSoTien() == null || yc.getSoTien().signum() <= 0) {
            throw new SQLException("Số tiền cần xác nhận phải lớn hơn 0.");
        }
        if (blank(yc.getMaSV()) || blank(yc.getMaHKNH())) {
            throw new SQLException("Thiếu thông tin sinh viên hoặc học kỳ.");
        }
        if (blank(yc.getHinhThucThanhToan())) {
            throw new SQLException("Vui lòng chọn hình thức thanh toán.");
        }

        try (Connection c = DatabaseConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                BigDecimal conLai;
                String lock = "SELECT ConLai FROM CongNo WHERE MaSV=? AND MaHKNH=? FOR UPDATE";
                try (PreparedStatement ps = c.prepareStatement(lock)) {
                    ps.setString(1, yc.getMaSV());
                    ps.setString(2, yc.getMaHKNH());
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new SQLException("Học kỳ này chưa có công nợ. Hãy kiểm tra lại phần Học phí/Công nợ.");
                        conLai = rs.getBigDecimal(1);
                    }
                }
                if (conLai == null || conLai.signum() <= 0) {
                    throw new SQLException("Khoản công nợ này đã được thanh toán đủ.");
                }

                BigDecimal dangCho = BigDecimal.ZERO;
                String pendingSql = "SELECT COALESCE(SUM(SoTien),0) FROM YeuCauThanhToan " +
                        "WHERE MaSV=? AND MaHKNH=? AND TrangThai='CHO_XAC_NHAN'";
                try (PreparedStatement ps = c.prepareStatement(pendingSql)) {
                    ps.setString(1, yc.getMaSV());
                    ps.setString(2, yc.getMaHKNH());
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next() && rs.getBigDecimal(1) != null) dangCho = rs.getBigDecimal(1);
                    }
                }
                BigDecimal toiDa = conLai.subtract(dangCho);
                if (toiDa.signum() <= 0) {
                    throw new SQLException("Bạn đã có yêu cầu thanh toán đang chờ xác nhận cho toàn bộ số tiền còn lại.");
                }
                if (yc.getSoTien().compareTo(toiDa) > 0) {
                    throw new SQLException("Số tiền gửi xác nhận vượt phần còn có thể nộp. Tối đa: " + String.format("%,.0f VND", toiDa));
                }

                String sql = "INSERT INTO YeuCauThanhToan(MaSV,MaHKNH,SoTien,HinhThucThanhToan,NoiDung,NgayGui,TrangThai) " +
                        "VALUES(?,?,?,?,?,NOW(),'CHO_XAC_NHAN')";
                try (PreparedStatement ps = c.prepareStatement(sql)) {
                    ps.setString(1, yc.getMaSV());
                    ps.setString(2, yc.getMaHKNH());
                    ps.setBigDecimal(3, yc.getSoTien());
                    ps.setString(4, yc.getHinhThucThanhToan());
                    ps.setString(5, safe(yc.getNoiDung()));
                    if (ps.executeUpdate() != 1) throw new SQLException("Không gửi được yêu cầu xác nhận thanh toán.");
                }
                c.commit();
                return true;
            } catch (SQLException e) {
                c.rollback();
                throw e;
            } finally {
                c.setAutoCommit(true);
            }
        }
    }

    public boolean confirm(int maYeuCau, String nguoiXuLy) throws SQLException {
        try (Connection c = DatabaseConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                YeuCauThanhToan yc = getForUpdate(c, maYeuCau);
                if (yc == null) throw new SQLException("Không tìm thấy yêu cầu thanh toán.");
                if (!"CHO_XAC_NHAN".equals(yc.getTrangThai())) {
                    throw new SQLException("Yêu cầu này đã được xử lý trước đó.");
                }

                congNoDAO.capNhatCongNo(c, yc.getMaSV(), yc.getMaHKNH(), yc.getSoTien());

                String ghiChu = "Xác nhận từ yêu cầu #" + yc.getMaYeuCau();
                if (!blank(yc.getNoiDung())) ghiChu += " - " + yc.getNoiDung().trim();
                String insert = "INSERT INTO ThanhToan(MaSV,MaHKNH,SoTien,HinhThucThanhToan,NgayThanhToan,NguoiThu,GhiChu) " +
                        "VALUES(?,?,?,?,CURDATE(),?,?)";
                try (PreparedStatement ps = c.prepareStatement(insert)) {
                    ps.setString(1, yc.getMaSV());
                    ps.setString(2, yc.getMaHKNH());
                    ps.setBigDecimal(3, yc.getSoTien());
                    ps.setString(4, yc.getHinhThucThanhToan());
                    ps.setString(5, blank(nguoiXuLy) ? "Thư ký khoa" : nguoiXuLy.trim());
                    ps.setString(6, ghiChu);
                    if (ps.executeUpdate() != 1) throw new SQLException("Không tạo được phiếu thanh toán.");
                }

                String update = "UPDATE YeuCauThanhToan SET TrangThai='DA_XAC_NHAN',NguoiXuLy=?,NgayXuLy=NOW(),LyDoTuChoi=NULL " +
                        "WHERE MaYeuCau=? AND TrangThai='CHO_XAC_NHAN'";
                try (PreparedStatement ps = c.prepareStatement(update)) {
                    ps.setString(1, blank(nguoiXuLy) ? "Thư ký khoa" : nguoiXuLy.trim());
                    ps.setInt(2, maYeuCau);
                    if (ps.executeUpdate() != 1) throw new SQLException("Không cập nhật được trạng thái yêu cầu.");
                }

                c.commit();
                return true;
            } catch (SQLException e) {
                c.rollback();
                throw e;
            } finally {
                c.setAutoCommit(true);
            }
        }
    }

    public boolean reject(int maYeuCau, String lyDo, String nguoiXuLy) throws SQLException {
        if (blank(lyDo)) throw new SQLException("Vui lòng nhập lý do từ chối.");
        String sql = "UPDATE YeuCauThanhToan SET TrangThai='TU_CHOI',NguoiXuLy=?,NgayXuLy=NOW(),LyDoTuChoi=? " +
                "WHERE MaYeuCau=? AND TrangThai='CHO_XAC_NHAN'";
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, blank(nguoiXuLy) ? "Thư ký khoa" : nguoiXuLy.trim());
            ps.setString(2, lyDo.trim());
            ps.setInt(3, maYeuCau);
            if (ps.executeUpdate() != 1) throw new SQLException("Yêu cầu không còn ở trạng thái chờ xác nhận.");
            return true;
        }
    }

    private YeuCauThanhToan getForUpdate(Connection c, int id) throws SQLException {
        String sql = "SELECT MaYeuCau,MaSV,MaHKNH,SoTien,HinhThucThanhToan,NoiDung,TrangThai " +
                "FROM YeuCauThanhToan WHERE MaYeuCau=? FOR UPDATE";
        try (PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;
                YeuCauThanhToan yc = new YeuCauThanhToan();
                yc.setMaYeuCau(rs.getInt("MaYeuCau"));
                yc.setMaSV(rs.getString("MaSV"));
                yc.setMaHKNH(rs.getString("MaHKNH"));
                yc.setSoTien(rs.getBigDecimal("SoTien"));
                yc.setHinhThucThanhToan(rs.getString("HinhThucThanhToan"));
                yc.setNoiDung(rs.getString("NoiDung"));
                yc.setTrangThai(rs.getString("TrangThai"));
                return yc;
            }
        }
    }

    private List<YeuCauThanhToan> query(String sql, Object[] args) throws SQLException {
        List<YeuCauThanhToan> list = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (args != null) for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    private YeuCauThanhToan map(ResultSet rs) throws SQLException {
        YeuCauThanhToan yc = new YeuCauThanhToan();
        yc.setMaYeuCau(rs.getInt("MaYeuCau"));
        yc.setMaSV(rs.getString("MaSV"));
        yc.setHoTenSV(rs.getString("HoTen"));
        yc.setMaHKNH(rs.getString("MaHKNH"));
        yc.setTenHKNH("HK " + rs.getInt("HocKy") + " - " + rs.getString("NamHoc"));
        yc.setSoTien(rs.getBigDecimal("SoTien"));
        yc.setHinhThucThanhToan(rs.getString("HinhThucThanhToan"));
        yc.setNoiDung(rs.getString("NoiDung"));
        Timestamp gui = rs.getTimestamp("NgayGui");
        Timestamp xuLy = rs.getTimestamp("NgayXuLy");
        yc.setNgayGui(gui == null ? "" : gui.toLocalDateTime().toString().replace('T', ' ').substring(0, 16));
        yc.setTrangThai(rs.getString("TrangThai"));
        yc.setNguoiXuLy(rs.getString("NguoiXuLy"));
        yc.setNgayXuLy(xuLy == null ? "" : xuLy.toLocalDateTime().toString().replace('T', ' ').substring(0, 16));
        yc.setLyDoTuChoi(rs.getString("LyDoTuChoi"));
        return yc;
    }

    private static boolean blank(String s) { return s == null || s.isBlank(); }
    private static String safe(String s) { return s == null ? "" : s.trim(); }
}
