package com.mycompany.baitaplon.dao;

import com.mycompany.baitaplon.model.TaiKhoan;
import com.mycompany.baitaplon.model.VaiTro;
import com.mycompany.baitaplon.util.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class TaiKhoanDAO {

    public static class KhoaTaiKhoanException extends SQLException {
        public KhoaTaiKhoanException(String msg) { super(msg); }
    }

    public TaiKhoan authenticate(String tenDangNhap, String matKhau) throws SQLException {
        String sql = "SELECT * FROM TaiKhoan WHERE TenDangNhap = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, tenDangNhap.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    TaiKhoan tk = mapRow(rs);
                    if (tk.getTrangThai() == null || !tk.getTrangThai().equalsIgnoreCase("Khoa")) {
                        if (matKhau != null && matKhau.equals(tk.getMatKhau())) {
                            return tk;
                        }
                    } else {
                        throw new KhoaTaiKhoanException("Tài khoản đã bị khóa, vui lòng liên hệ quản trị viên.");
                    }
                }
            }
        }
        return null;
    }

    public boolean changePassword(String username, String oldPassword, String newPassword) throws SQLException {
        if (newPassword == null || newPassword.length() < 6) throw new SQLException("Mật khẩu mới phải có ít nhất 6 ký tự.");
        String sql = "UPDATE TaiKhoan SET MatKhau=? WHERE TenDangNhap=? AND MatKhau=? AND TrangThai='Hoat dong'";
        try (Connection conn = DatabaseConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newPassword); ps.setString(2, username); ps.setString(3, oldPassword);
            return ps.executeUpdate() == 1;
        }
    }

    public List<TaiKhoan> getAll() throws SQLException {
        List<TaiKhoan> list = new ArrayList<>();
        String sql = "SELECT * FROM TaiKhoan ORDER BY MaTK DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    public TaiKhoan getById(int maTK) throws SQLException {
        String sql = "SELECT * FROM TaiKhoan WHERE MaTK = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, maTK);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public TaiKhoan getByTenDN(String tenDN) throws SQLException {
        String sql = "SELECT * FROM TaiKhoan WHERE TenDangNhap = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, tenDN);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapRow(rs);
            }
        }
        return null;
    }

    public List<TaiKhoan> search(String keyword) throws SQLException {
        List<TaiKhoan> list = new ArrayList<>();
        String sql = "SELECT * FROM TaiKhoan WHERE TenDangNhap LIKE ? OR HoTen LIKE ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String kw = "%" + keyword + "%";
            ps.setString(1, kw); ps.setString(2, kw);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    public int insert(TaiKhoan tk) throws SQLException {
        String sql = "INSERT INTO TaiKhoan(TenDangNhap, MatKhau, VaiTro, MaSV, HoTen, TrangThai) VALUES (?,?,?,?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, tk.getTenDangNhap());
            ps.setString(2, tk.getMatKhau() == null || tk.getMatKhau().isEmpty() ? "123456" : tk.getMatKhau());
            ps.setString(3, tk.getVaiTro() != null ? tk.getVaiTro().name() : "SINH_VIEN");
            ps.setString(4, tk.getMaSV());
            ps.setString(5, tk.getHoTen());
            ps.setString(6, tk.getTrangThai() == null || tk.getTrangThai().isEmpty() ? "Hoat dong" : tk.getTrangThai());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) return keys.getInt(1);
            }
        }
        return -1;
    }

    public boolean update(TaiKhoan tk) throws SQLException {
        String sql = "UPDATE TaiKhoan SET TenDangNhap=?, VaiTro=?, MaSV=?, HoTen=?, TrangThai=? WHERE MaTK=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, tk.getTenDangNhap());
            ps.setString(2, tk.getVaiTro() != null ? tk.getVaiTro().name() : "SINH_VIEN");
            ps.setString(3, tk.getMaSV());
            ps.setString(4, tk.getHoTen());
            ps.setString(5, tk.getTrangThai() == null || tk.getTrangThai().isEmpty() ? "Hoat dong" : tk.getTrangThai());
            ps.setInt(6, tk.getMaTK());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean delete(int maTK) throws SQLException {
        String sql = "DELETE FROM TaiKhoan WHERE MaTK=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, maTK);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean resetPassword(int maTK) throws SQLException {
        String sql = "UPDATE TaiKhoan SET MatKhau='123456' WHERE MaTK=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, maTK);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean updateTrangThai(int maTK, String trangThai) throws SQLException {
        String sql = "UPDATE TaiKhoan SET TrangThai=? WHERE MaTK=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, trangThai);
            ps.setInt(2, maTK);
            return ps.executeUpdate() > 0;
        }
    }

    public boolean kiemTraAdminCuoiCung() throws SQLException {
        String sql = "SELECT COUNT(*) FROM TaiKhoan WHERE VaiTro IN ('ADMIN','ADMINISTRATOR','QUAN_TRI','QUANTRI') AND TrangThai='Hoat dong'";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            rs.next();
            return rs.getInt(1) <= 1;
        }
    }

    public TaiKhoan getAdminCuoiCung() throws SQLException {
        String sql = "SELECT * FROM TaiKhoan WHERE VaiTro IN ('ADMIN','ADMINISTRATOR','QUAN_TRI','QUANTRI') AND TrangThai='Hoat dong' LIMIT 1";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) return mapRow(rs);
        }
        return null;
    }

    private TaiKhoan mapRow(ResultSet rs) throws SQLException {
        TaiKhoan tk = new TaiKhoan();
        tk.setMaTK(rs.getInt("MaTK"));
        tk.setTenDangNhap(rs.getString("TenDangNhap"));
        tk.setMatKhau(rs.getString("MatKhau"));
        tk.setVaiTro(VaiTro.fromDb(rs.getString("VaiTro")));
        tk.setMaSV(rs.getString("MaSV"));
        tk.setHoTen(rs.getString("HoTen"));
        tk.setTrangThai(rs.getString("TrangThai"));
        return tk;
    }
}
