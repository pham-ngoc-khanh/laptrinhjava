package com.mycompany.baitaplon.dao;

import com.mycompany.baitaplon.model.ThanhToan;
import com.mycompany.baitaplon.util.DatabaseConnection;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ThanhToanDAO {
    private final CongNoDAO congNoDAO = new CongNoDAO();
    private static final String BASE = "SELECT tt.*, sv.HoTen, hk.HocKy, hk.NamHoc FROM ThanhToan tt " +
            "LEFT JOIN SinhVien sv ON tt.MaSV=sv.MaSV LEFT JOIN HocKyNamHoc hk ON tt.MaHKNH=hk.MaHKNH ";

    public List<ThanhToan> getAll() throws SQLException { return query(BASE + "ORDER BY tt.NgayThanhToan DESC, tt.MaThanhToan DESC", null); }
    public List<ThanhToan> getByMaSV(String maSV) throws SQLException { return query(BASE + "WHERE tt.MaSV=? ORDER BY tt.NgayThanhToan DESC, tt.MaThanhToan DESC", maSV); }

    private List<ThanhToan> query(String sql, String maSV) throws SQLException {
        List<ThanhToan> list = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (maSV != null) ps.setString(1, maSV);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) list.add(map(rs)); }
        }
        return list;
    }

    public boolean thanhToan(ThanhToan tt) throws SQLException {
        if (tt == null || tt.getSoTien() == null || tt.getSoTien().signum() <= 0) throw new SQLException("Số tiền thanh toán phải lớn hơn 0.");
        if (tt.getMaSV() == null || tt.getMaSV().isBlank() || tt.getMaHKNH() == null || tt.getMaHKNH().isBlank()) throw new SQLException("Thiếu sinh viên hoặc học kỳ.");
        try (Connection c = DatabaseConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                try (PreparedStatement check = c.prepareStatement(
                        "SELECT COUNT(*) FROM YeuCauThanhToan WHERE MaSV=? AND MaHKNH=? AND TrangThai='CHO_XAC_NHAN'")) {
                    check.setString(1, tt.getMaSV());
                    check.setString(2, tt.getMaHKNH());
                    try (ResultSet rs = check.executeQuery()) {
                        rs.next();
                        if (rs.getInt(1) > 0) {
                            throw new SQLException("Sinh viên đang có yêu cầu thanh toán chờ xác nhận trong học kỳ này. " +
                                    "Hãy xử lý tại tab 'Chờ xác nhận' để tránh ghi nhận trùng.");
                        }
                    }
                }
                // Khóa và cập nhật công nợ trên CHÍNH transaction này để không thể lệch dữ liệu.
                congNoDAO.capNhatCongNo(c, tt.getMaSV(), tt.getMaHKNH(), tt.getSoTien());
                String sql = "INSERT INTO ThanhToan(MaSV,MaHKNH,SoTien,HinhThucThanhToan,NgayThanhToan,NguoiThu,GhiChu) VALUES(?,?,?,?,?,?,?)";
                try (PreparedStatement ps = c.prepareStatement(sql)) {
                    ps.setString(1, tt.getMaSV()); ps.setString(2, tt.getMaHKNH());
                    ps.setBigDecimal(3, tt.getSoTien()); ps.setString(4, tt.getHinhThucThanhToan());
                    ps.setDate(5, Date.valueOf(tt.getNgayThanhToan())); ps.setString(6, tt.getNguoiThu()); ps.setString(7, tt.getGhiChu());
                    if (ps.executeUpdate() != 1) throw new SQLException("Không lưu được phiếu thanh toán.");
                }
                c.commit();
                return true;
            } catch (SQLException e) { c.rollback(); throw e; }
            finally { c.setAutoCommit(true); }
        }
    }

    private ThanhToan map(ResultSet rs) throws SQLException {
        ThanhToan tt = new ThanhToan(); tt.setMaThanhToan(rs.getInt("MaThanhToan")); tt.setMaSV(rs.getString("MaSV"));
        tt.setHoTenSV(rs.getString("HoTen")); tt.setMaHKNH(rs.getString("MaHKNH"));
        tt.setTenHKNH("HK " + rs.getInt("HocKy") + " - " + rs.getString("NamHoc")); tt.setSoTien(rs.getBigDecimal("SoTien"));
        tt.setHinhThucThanhToan(rs.getString("HinhThucThanhToan")); tt.setNgayThanhToan(rs.getString("NgayThanhToan"));
        tt.setNguoiThu(rs.getString("NguoiThu")); tt.setGhiChu(rs.getString("GhiChu")); return tt;
    }
}
