package com.mycompany.baitaplon.dao;

import com.mycompany.baitaplon.model.SinhVien;
import com.mycompany.baitaplon.util.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SinhVienDAO {
    private static final String BASE = "SELECT sv.*, l.TenLop, l.MaNganh AS MaNganh_Lop, n.TenNganh, l.KhoaHoc "
            + "FROM SinhVien sv "
            + "LEFT JOIN Lop l ON sv.MaLop = l.MaLop "
            + "LEFT JOIN Nganh n ON l.MaNganh = n.MaNganh ";

    private SinhVien map(ResultSet rs) throws SQLException {
        SinhVien sv = new SinhVien();
        sv.setMaSV(rs.getString("MaSV"));
        sv.setHoTen(rs.getString("HoTen"));
        sv.setNgaySinh(rs.getString("NgaySinh"));
        sv.setGioiTinh(rs.getString("GioiTinh"));
        sv.setDiaChi(rs.getString("DiaChi"));
        sv.setSdt(rs.getString("SDT"));
        sv.setEmail(rs.getString("Email"));
        sv.setMaLop(rs.getString("MaLop"));
        sv.setTenLop(rs.getString("TenLop"));
        sv.setMaNganh(rs.getString("MaNganh_Lop"));
        sv.setTenNganh(rs.getString("TenNganh"));
        int kh = rs.getInt("KhoaHoc");
        if (!rs.wasNull()) sv.setKhoaHoc(kh);
        return sv;
    }

    public List<SinhVien> getAll() throws SQLException {
        List<SinhVien> list = new ArrayList<>();
        String sql = BASE + " ORDER BY sv.MaSV";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public SinhVien getById(String maSV) throws SQLException {
        String sql = BASE + " WHERE sv.MaSV = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, maSV);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    public List<SinhVien> search(String keyword) throws SQLException {
        List<SinhVien> list = new ArrayList<>();
        String sql = BASE + " WHERE sv.MaSV LIKE ? OR sv.HoTen LIKE ? ORDER BY sv.MaSV";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String kw = "%" + keyword + "%";
            ps.setString(1, kw);
            ps.setString(2, kw);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        }
        return list;
    }

    public boolean insert(SinhVien sv) throws SQLException {
        String sql = "INSERT INTO SinhVien (MaSV, HoTen, NgaySinh, GioiTinh, DiaChi, SDT, Email, MaLop) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, sv.getMaSV()); ps.setString(2, sv.getHoTen());
                    if (sv.getNgaySinh() == null || sv.getNgaySinh().isBlank()) ps.setNull(3, Types.DATE); else ps.setDate(3, Date.valueOf(sv.getNgaySinh()));
                    ps.setString(4, sv.getGioiTinh()); ps.setString(5, sv.getDiaChi()); ps.setString(6, sv.getSdt()); ps.setString(7, sv.getEmail()); ps.setString(8, sv.getMaLop());
                    ps.executeUpdate();
                }
                try (PreparedStatement ps = conn.prepareStatement("INSERT IGNORE INTO TaiKhoan(TenDangNhap,MatKhau,VaiTro,MaSV,HoTen,TrangThai) VALUES(?, '123456', 'SINH_VIEN', ?, ?, 'Hoat dong')")) {
                    ps.setString(1, sv.getMaSV().toLowerCase()); ps.setString(2, sv.getMaSV()); ps.setString(3, sv.getHoTen()); ps.executeUpdate();
                }
                conn.commit(); return true;
            } catch (SQLException e) { conn.rollback(); throw e; }
            finally { conn.setAutoCommit(true); }
        }
    }

    public boolean update(SinhVien sv) throws SQLException {
        String sql = "UPDATE SinhVien SET HoTen=?, NgaySinh=?, GioiTinh=?, DiaChi=?, SDT=?, Email=?, MaLop=? WHERE MaSV=?";
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                int n;
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, sv.getHoTen());
                    if (sv.getNgaySinh() == null || sv.getNgaySinh().isBlank()) ps.setNull(2, Types.DATE); else ps.setDate(2, Date.valueOf(sv.getNgaySinh()));
                    ps.setString(3, sv.getGioiTinh()); ps.setString(4, sv.getDiaChi()); ps.setString(5, sv.getSdt()); ps.setString(6, sv.getEmail()); ps.setString(7, sv.getMaLop()); ps.setString(8, sv.getMaSV());
                    n = ps.executeUpdate();
                }
                try (PreparedStatement ps = conn.prepareStatement("UPDATE TaiKhoan SET HoTen=? WHERE MaSV=?")) { ps.setString(1, sv.getHoTen()); ps.setString(2, sv.getMaSV()); ps.executeUpdate(); }
                conn.commit(); return n > 0;
            } catch (SQLException e) { conn.rollback(); throw e; }
            finally { conn.setAutoCommit(true); }
        }
    }

    public boolean delete(String maSV) throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                try (PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM ThanhToan WHERE MaSV=?")) {
                    ps.setString(1, maSV);
                    try (ResultSet rs = ps.executeQuery()) {
                        rs.next();
                        if (rs.getInt(1) > 0) {
                            throw new SQLException("Không thể xóa sinh viên đã có lịch sử thanh toán. Cần giữ chứng từ và dữ liệu đối soát.");
                        }
                    }
                }
                try (PreparedStatement ps = conn.prepareStatement(
                        "SELECT COUNT(*) FROM YeuCauThanhToan WHERE MaSV=? AND TrangThai='CHO_XAC_NHAN'")) {
                    ps.setString(1, maSV);
                    try (ResultSet rs = ps.executeQuery()) {
                        rs.next();
                        if (rs.getInt(1) > 0) {
                            throw new SQLException("Sinh viên đang có yêu cầu thanh toán chờ xác nhận. Hãy xử lý hoặc hủy yêu cầu trước khi xóa.");
                        }
                    }
                }

                String[] sqls = {
                    "DELETE FROM TaiKhoan WHERE MaSV=?",
                    "DELETE FROM YeuCauThanhToan WHERE MaSV=?",
                    "DELETE FROM CongNo WHERE MaSV=?",
                    "DELETE FROM HocPhi WHERE MaSV=?",
                    "DELETE FROM DangKyHocPhan WHERE MaSV=?"
                };
                for (String sql : sqls) try (PreparedStatement ps = conn.prepareStatement(sql)) { ps.setString(1, maSV); ps.executeUpdate(); }
                int n; try (PreparedStatement ps = conn.prepareStatement("DELETE FROM SinhVien WHERE MaSV=?")) { ps.setString(1, maSV); n = ps.executeUpdate(); }
                conn.commit(); return n > 0;
            } catch (SQLException e) { conn.rollback(); throw e; }
            finally { conn.setAutoCommit(true); }
        }
    }

}
