package com.mycompany.baitaplon.dao;

import com.mycompany.baitaplon.model.AuditLog;
import com.mycompany.baitaplon.util.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AuditDAO {

    public boolean insert(AuditLog al) throws SQLException {
        String sql = "INSERT INTO AuditLog(ThoiGian, MaTK, TenDangNhap, HanhDong, DoiTuong, ChiTiet, NguoiThucHien) VALUES (?,?,?,?,?,?,?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setTimestamp(1, Timestamp.valueOf(al.getThoiGian() != null ? al.getThoiGian() : LocalDateTime.now()));
            if (al.getMaTK() == null) ps.setNull(2, java.sql.Types.INTEGER); else ps.setInt(2, al.getMaTK());
            ps.setString(3, al.getTenDangNhap());
            ps.setString(4, al.getHanhDong());
            ps.setString(5, al.getDoiTuong());
            ps.setString(6, al.getChiTiet());
            ps.setString(7, al.getNguoiThucHien());
            return ps.executeUpdate() > 0;
        }
    }

    public List<AuditLog> getAll() throws SQLException {
        List<AuditLog> list = new ArrayList<>();
        String sql = "SELECT * FROM AuditLog ORDER BY ThoiGian DESC, MaLog DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        }
        return list;
    }

    public List<AuditLog> searchByKeyword(String keyword) throws SQLException {
        List<AuditLog> list = new ArrayList<>();
        String sql = "SELECT * FROM AuditLog WHERE TenDangNhap LIKE ? OR HanhDong LIKE ? OR DoiTuong LIKE ? OR ChiTiet LIKE ? OR NguoiThucHien LIKE ? ORDER BY ThoiGian DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String kw = "%" + keyword + "%";
            ps.setString(1, kw); ps.setString(2, kw); ps.setString(3, kw); ps.setString(4, kw); ps.setString(5, kw);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(mapRow(rs));
            }
        }
        return list;
    }

    private AuditLog mapRow(ResultSet rs) throws SQLException {
        AuditLog al = new AuditLog();
        al.setMaLog(rs.getInt("MaLog"));
        Timestamp ts = rs.getTimestamp("ThoiGian");
        al.setThoiGian(ts == null ? null : ts.toLocalDateTime());
        int ma = rs.getInt("MaTK");
        al.setMaTK(rs.wasNull() ? null : ma);
        al.setTenDangNhap(rs.getString("TenDangNhap"));
        al.setHanhDong(rs.getString("HanhDong"));
        al.setDoiTuong(rs.getString("DoiTuong"));
        al.setChiTiet(rs.getString("ChiTiet"));
        al.setNguoiThucHien(rs.getString("NguoiThucHien"));
        return al;
    }
}
