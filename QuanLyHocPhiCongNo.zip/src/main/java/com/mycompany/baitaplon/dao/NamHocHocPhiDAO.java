package com.mycompany.baitaplon.dao;

import com.mycompany.baitaplon.model.NamHocHocPhi;
import com.mycompany.baitaplon.util.DatabaseConnection;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NamHocHocPhiDAO {

    public List<NamHocHocPhi> getAll() throws SQLException {
        String sql = "SELECT * FROM NamHocHocPhi ORDER BY NamHoc";
        List<NamHocHocPhi> list = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(map(rs));
        }
        return list;
    }

    public NamHocHocPhi getByNamHoc(String namHoc) throws SQLException {
        if (namHoc == null) return null;
        String sql = "SELECT * FROM NamHocHocPhi WHERE NamHoc=? ORDER BY MaNam DESC LIMIT 1";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, namHoc);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        }
        return null;
    }

    public BigDecimal getGiaMotTinChi(String namHoc) throws SQLException {
        NamHocHocPhi nh = getByNamHoc(namHoc);
        if (nh != null && nh.getHocPhiMotTinChi() != null) return nh.getHocPhiMotTinChi();
        return null;
    }

    private NamHocHocPhi map(ResultSet rs) throws SQLException {
        return new NamHocHocPhi(
                rs.getString("MaNam"),
                rs.getString("NamHoc"),
                rs.getBigDecimal("HocPhiMotTinChi"),
                rs.getString("GhiChu")
        );
    }
}
