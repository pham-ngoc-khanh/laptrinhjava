package com.mycompany.baitaplon.dao;

import com.mycompany.baitaplon.model.HocPhi;
import com.mycompany.baitaplon.util.DatabaseConnection;
import java.math.BigDecimal;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HocPhiDAO {
    private static final String BASE = "SELECT hp.*, sv.HoTen, hk.HocKy, hk.NamHoc FROM HocPhi hp " +
            "LEFT JOIN SinhVien sv ON hp.MaSV=sv.MaSV LEFT JOIN HocKyNamHoc hk ON hp.MaHKNH=hk.MaHKNH ";

    public List<HocPhi> getAll() throws SQLException { return query(BASE + "ORDER BY hk.NgayBatDau DESC, hp.MaSV", (String[]) null); }
    public List<HocPhi> getByMaSV(String maSV) throws SQLException { return query(BASE + "WHERE hp.MaSV=? ORDER BY hk.NgayBatDau DESC", maSV); }

    public HocPhi getByStudentTerm(String maSV, String maHKNH) throws SQLException {
        List<HocPhi> list = query(BASE + "WHERE hp.MaSV=? AND hp.MaHKNH=?", new String[]{maSV, maHKNH});
        return list.isEmpty() ? null : list.get(0);
    }

    private List<HocPhi> query(String sql, String arg) throws SQLException { return query(sql, arg == null ? null : new String[]{arg}); }
    private List<HocPhi> query(String sql, String[] args) throws SQLException {
        List<HocPhi> list = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (args != null) for (int i = 0; i < args.length; i++) ps.setString(i + 1, args[i]);
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) list.add(map(rs)); }
        }
        return list;
    }

    public boolean tinhHocPhi(String maSV, String maHKNH) throws SQLException {
        try (Connection c = DatabaseConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                boolean result = tinhHocPhi(c, maSV, maHKNH);
                if (!result) { c.rollback(); return false; }
                c.commit(); return true;
            } catch (SQLException e) { c.rollback(); throw e; }
            finally { c.setAutoCommit(true); }
        }
    }

    boolean tinhHocPhi(Connection c, String maSV, String maHKNH) throws SQLException {
        String namHoc = null;
        try (PreparedStatement p = c.prepareStatement("SELECT NamHoc FROM HocKyNamHoc WHERE MaHKNH=?")) {
            p.setString(1, maHKNH);
            try (ResultSet r = p.executeQuery()) { if (r.next()) namHoc = r.getString(1); }
        }
        if (namHoc == null) throw new SQLException("Học kỳ năm học " + maHKNH + " không tồn tại.");

        BigDecimal giaMotTC = null;
        try (PreparedStatement p = c.prepareStatement("SELECT HocPhiMotTinChi FROM NamHocHocPhi WHERE NamHoc=? ORDER BY MaNam DESC LIMIT 1")) {
            p.setString(1, namHoc);
            try (ResultSet r = p.executeQuery()) { if (r.next()) giaMotTC = r.getBigDecimal(1); }
        }
        if (giaMotTC == null || giaMotTC.signum() <= 0) {
            throw new SQLException("Chưa cấu hình học phí 1 tín chỉ cho năm học " + namHoc + " (bảng NamHocHocPhi).");
        }

        int tongTC = 0;
        String sumTC = "SELECT COALESCE(SUM(hp.SoTinChi),0) " +
                "FROM DangKyHocPhan dk JOIN HocPhan hp ON dk.MaHP=hp.MaHP WHERE dk.MaSV=? AND dk.MaHKNH=?";
        try (PreparedStatement ps = c.prepareStatement(sumTC)) {
            ps.setString(1, maSV); ps.setString(2, maHKNH);
            try (ResultSet rs = ps.executeQuery()) { if (rs.next()) tongTC = rs.getInt(1); }
        }
        if (tongTC <= 0) return false;
        BigDecimal tongHP = giaMotTC.multiply(BigDecimal.valueOf(tongTC));

        BigDecimal mienGiam = BigDecimal.ZERO;
        String existing = "SELECT MienGiam FROM HocPhi WHERE MaSV=? AND MaHKNH=? FOR UPDATE";
        boolean exists;
        try (PreparedStatement ps = c.prepareStatement(existing)) {
            ps.setString(1, maSV); ps.setString(2, maHKNH);
            try (ResultSet rs = ps.executeQuery()) {
                exists = rs.next();
                if (exists && rs.getBigDecimal(1) != null) mienGiam = rs.getBigDecimal(1);
            }
        }
        BigDecimal phaiThu = tongHP.subtract(mienGiam).max(BigDecimal.ZERO);
        if (exists) {
            String upd = "UPDATE HocPhi SET TongTinChi=?,TongHocPhi=?,PhaiThu=?,NgayTinh=CURDATE() WHERE MaSV=? AND MaHKNH=?";
            try (PreparedStatement ps = c.prepareStatement(upd)) {
                ps.setInt(1, tongTC); ps.setBigDecimal(2, tongHP); ps.setBigDecimal(3, phaiThu); ps.setString(4, maSV); ps.setString(5, maHKNH); ps.executeUpdate();
            }
        } else {
            String ins = "INSERT INTO HocPhi(MaSV,MaHKNH,TongTinChi,TongHocPhi,MienGiam,PhaiThu,NgayTinh) VALUES(?,?,?,?,0,?,CURDATE())";
            try (PreparedStatement ps = c.prepareStatement(ins)) {
                ps.setString(1, maSV); ps.setString(2, maHKNH); ps.setInt(3, tongTC); ps.setBigDecimal(4, tongHP); ps.setBigDecimal(5, tongHP); ps.executeUpdate();
            }
        }
        syncDebt(c, maSV, maHKNH, phaiThu);
        return true;
    }

    public boolean updateMienGiam(String maSV, String maHKNH, BigDecimal mienGiam) throws SQLException {
        if (mienGiam == null || mienGiam.signum() < 0) throw new SQLException("Miễn giảm không được âm.");
        try (Connection c = DatabaseConnection.getConnection()) {
            c.setAutoCommit(false);
            try {
                BigDecimal tongHP;
                String lock = "SELECT TongHocPhi FROM HocPhi WHERE MaSV=? AND MaHKNH=? FOR UPDATE";
                try (PreparedStatement ps = c.prepareStatement(lock)) {
                    ps.setString(1, maSV); ps.setString(2, maHKNH);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (!rs.next()) throw new SQLException("Chưa có bản ghi học phí. Hãy tính học phí trước.");
                        tongHP = rs.getBigDecimal(1);
                    }
                }
                if (mienGiam.compareTo(tongHP) > 0) throw new SQLException("Miễn giảm không được lớn hơn tổng học phí.");
                BigDecimal phaiThu = tongHP.subtract(mienGiam);
                try (PreparedStatement ps = c.prepareStatement("SELECT COALESCE(SoTienDaThu,0) FROM CongNo WHERE MaSV=? AND MaHKNH=? FOR UPDATE")) {
                    ps.setString(1, maSV); ps.setString(2, maHKNH);
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next() && rs.getBigDecimal(1).compareTo(phaiThu) > 0) {
                            throw new SQLException("Mức miễn giảm này làm số phải thu thấp hơn số tiền đã thu. Hãy xử lý điều chỉnh/hoàn tiền trước.");
                        }
                    }
                }
                try (PreparedStatement ps = c.prepareStatement("UPDATE HocPhi SET MienGiam=?,PhaiThu=?,NgayTinh=CURDATE() WHERE MaSV=? AND MaHKNH=?")) {
                    ps.setBigDecimal(1, mienGiam); ps.setBigDecimal(2, phaiThu); ps.setString(3, maSV); ps.setString(4, maHKNH); ps.executeUpdate();
                }
                syncDebt(c, maSV, maHKNH, phaiThu);
                c.commit(); return true;
            } catch (SQLException e) { c.rollback(); throw e; }
            finally { c.setAutoCommit(true); }
        }
    }

    private void syncDebt(Connection c, String maSV, String maHKNH, BigDecimal phaiThu) throws SQLException {
        BigDecimal daThu = BigDecimal.ZERO; boolean exists;
        try (PreparedStatement ps = c.prepareStatement("SELECT SoTienDaThu FROM CongNo WHERE MaSV=? AND MaHKNH=? FOR UPDATE")) {
            ps.setString(1, maSV); ps.setString(2, maHKNH);
            try (ResultSet rs = ps.executeQuery()) { exists = rs.next(); if (exists && rs.getBigDecimal(1) != null) daThu = rs.getBigDecimal(1); }
        }
        if (daThu.compareTo(phaiThu) > 0) {
            throw new SQLException("Không thể cập nhật học phí xuống thấp hơn số tiền đã thu (" +
                    String.format("%,.0f VND", daThu) + "). Hãy xử lý điều chỉnh/hoàn tiền trước.");
        }

        BigDecimal conLai = phaiThu.subtract(daThu);
        BigDecimal dangCho = BigDecimal.ZERO;
        try (PreparedStatement ps = c.prepareStatement(
                "SELECT COALESCE(SUM(SoTien),0) FROM YeuCauThanhToan WHERE MaSV=? AND MaHKNH=? AND TrangThai='CHO_XAC_NHAN'")) {
            ps.setString(1, maSV); ps.setString(2, maHKNH);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next() && rs.getBigDecimal(1) != null) dangCho = rs.getBigDecimal(1);
            }
        }
        if (dangCho.compareTo(conLai) > 0) {
            throw new SQLException("Không thể cập nhật học phí vì tổng yêu cầu thanh toán đang chờ (" +
                    String.format("%,.0f VND", dangCho) + ") vượt công nợ mới (" +
                    String.format("%,.0f VND", conLai) + "). Hãy xử lý/hủy yêu cầu thanh toán trước.");
        }

        String trangThai = conLai.signum() == 0 ? "Đã nộp đủ" : (daThu.signum() > 0 ? "Đang nợ" : "Chưa nộp");
        if (exists) {
            try (PreparedStatement ps = c.prepareStatement("UPDATE CongNo SET SoTienNo=?,ConLai=?,TrangThai=?,NgayCapNhat=CURDATE() WHERE MaSV=? AND MaHKNH=?")) {
                ps.setBigDecimal(1, phaiThu); ps.setBigDecimal(2, conLai); ps.setString(3, trangThai); ps.setString(4, maSV); ps.setString(5, maHKNH); ps.executeUpdate();
            }
        } else {
            try (PreparedStatement ps = c.prepareStatement("INSERT INTO CongNo(MaSV,MaHKNH,SoTienNo,SoTienDaThu,ConLai,TrangThai,NgayCapNhat) VALUES(?,?,?,0,?,?,CURDATE())")) {
                ps.setString(1, maSV); ps.setString(2, maHKNH); ps.setBigDecimal(3, phaiThu); ps.setBigDecimal(4, phaiThu); ps.setString(5, trangThai); ps.executeUpdate();
            }
        }
    }

    private HocPhi map(ResultSet rs) throws SQLException {
        HocPhi hp = new HocPhi(); hp.setMaHPPhi(rs.getInt("MaHPPhi")); hp.setMaSV(rs.getString("MaSV")); hp.setHoTenSV(rs.getString("HoTen"));
        hp.setMaHKNH(rs.getString("MaHKNH")); hp.setTenHKNH("HK " + rs.getInt("HocKy") + " - " + rs.getString("NamHoc"));
        hp.setTongTinChi(rs.getInt("TongTinChi")); hp.setTongHocPhi(rs.getBigDecimal("TongHocPhi")); hp.setMienGiam(rs.getBigDecimal("MienGiam"));
        hp.setPhaiThu(rs.getBigDecimal("PhaiThu")); hp.setNgayTinh(rs.getString("NgayTinh")); return hp;
    }
}
