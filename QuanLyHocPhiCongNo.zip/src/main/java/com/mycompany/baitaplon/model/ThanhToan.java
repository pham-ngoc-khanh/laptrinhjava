package com.mycompany.baitaplon.model;

import java.math.BigDecimal;

public class ThanhToan {
    private int maThanhToan;
    private String maSV;
    private String hoTenSV;
    private String maHKNH;
    private String tenHKNH;
    private BigDecimal soTien;
    private String hinhThucThanhToan;
    private String ngayThanhToan;
    private String nguoiThu;
    private String ghiChu;

    public ThanhToan() {}

    public ThanhToan(int maThanhToan, String maSV, String maHKNH, BigDecimal soTien, String hinhThucThanhToan, String ngayThanhToan, String nguoiThu, String ghiChu) {
        this.maThanhToan = maThanhToan;
        this.maSV = maSV;
        this.maHKNH = maHKNH;
        this.soTien = soTien;
        this.hinhThucThanhToan = hinhThucThanhToan;
        this.ngayThanhToan = ngayThanhToan;
        this.nguoiThu = nguoiThu;
        this.ghiChu = ghiChu;
    }

    public int getMaThanhToan() { return maThanhToan; }
    public void setMaThanhToan(int maThanhToan) { this.maThanhToan = maThanhToan; }
    public String getMaSV() { return maSV; }
    public void setMaSV(String maSV) { this.maSV = maSV; }
    public String getHoTenSV() { return hoTenSV; }
    public void setHoTenSV(String hoTenSV) { this.hoTenSV = hoTenSV; }
    public String getMaHKNH() { return maHKNH; }
    public void setMaHKNH(String maHKNH) { this.maHKNH = maHKNH; }
    public String getTenHKNH() { return tenHKNH; }
    public void setTenHKNH(String tenHKNH) { this.tenHKNH = tenHKNH; }
    public BigDecimal getSoTien() { return soTien; }
    public void setSoTien(BigDecimal soTien) { this.soTien = soTien; }
    public String getHinhThucThanhToan() { return hinhThucThanhToan; }
    public void setHinhThucThanhToan(String hinhThucThanhToan) { this.hinhThucThanhToan = hinhThucThanhToan; }
    public String getNgayThanhToan() { return ngayThanhToan; }
    public void setNgayThanhToan(String ngayThanhToan) { this.ngayThanhToan = ngayThanhToan; }
    public String getNguoiThu() { return nguoiThu; }
    public void setNguoiThu(String nguoiThu) { this.nguoiThu = nguoiThu; }
    public String getGhiChu() { return ghiChu; }
    public void setGhiChu(String ghiChu) { this.ghiChu = ghiChu; }
}
