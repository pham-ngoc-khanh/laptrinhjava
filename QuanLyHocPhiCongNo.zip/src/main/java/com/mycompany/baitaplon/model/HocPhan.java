package com.mycompany.baitaplon.model;

import java.math.BigDecimal;

public class HocPhan {
    private String maHP;
    private String tenHP;
    private int soTinChi;
    private BigDecimal hocPhiMotTinChi;
    private String maNganh;
    private String tenNganh;

    public HocPhan() {}

    public HocPhan(String maHP, String tenHP, int soTinChi, BigDecimal hocPhiMotTinChi, String maNganh) {
        this.maHP = maHP;
        this.tenHP = tenHP;
        this.soTinChi = soTinChi;
        this.hocPhiMotTinChi = hocPhiMotTinChi;
        this.maNganh = maNganh;
    }

    public String getMaHP() { return maHP; }
    public void setMaHP(String maHP) { this.maHP = maHP; }
    public String getTenHP() { return tenHP; }
    public void setTenHP(String tenHP) { this.tenHP = tenHP; }
    public int getSoTinChi() { return soTinChi; }
    public void setSoTinChi(int soTinChi) { this.soTinChi = soTinChi; }
    public BigDecimal getHocPhiMotTinChi() { return hocPhiMotTinChi; }
    public void setHocPhiMotTinChi(BigDecimal hocPhiMotTinChi) { this.hocPhiMotTinChi = hocPhiMotTinChi; }
    public String getMaNganh() { return maNganh; }
    public void setMaNganh(String maNganh) { this.maNganh = maNganh; }
    public String getTenNganh() { return tenNganh; }
    public void setTenNganh(String tenNganh) { this.tenNganh = tenNganh; }
}
