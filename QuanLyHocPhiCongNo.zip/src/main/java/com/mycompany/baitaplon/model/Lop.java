package com.mycompany.baitaplon.model;

public class Lop {
    private String maLop;
    private String tenLop;
    private String maNganh;
    private int khoaHoc;

    public Lop() {}

    public String getMaLop() { return maLop; }
    public void setMaLop(String maLop) { this.maLop = maLop; }
    public String getTenLop() { return tenLop; }
    public void setTenLop(String tenLop) { this.tenLop = tenLop; }
    public String getMaNganh() { return maNganh; }
    public void setMaNganh(String maNganh) { this.maNganh = maNganh; }
    public int getKhoaHoc() { return khoaHoc; }
    public void setKhoaHoc(int khoaHoc) { this.khoaHoc = khoaHoc; }
}
