package com.mycompany.baitaplon.model;

import java.time.LocalDateTime;

public class AuditLog {
    private int maLog;
    private LocalDateTime thoiGian;
    private Integer maTK;
    private String tenDangNhap;
    private String hanhDong;
    private String doiTuong;
    private String chiTiet;
    private String nguoiThucHien;

    public AuditLog() {}

    public AuditLog(Integer maTK, String tenDangNhap, String hanhDong, String doiTuong, String chiTiet, String nguoiThucHien) {
        this.maTK = maTK;
        this.tenDangNhap = tenDangNhap;
        this.hanhDong = hanhDong;
        this.doiTuong = doiTuong;
        this.chiTiet = chiTiet;
        this.nguoiThucHien = nguoiThucHien;
    }

    public int getMaLog() { return maLog; }
    public void setMaLog(int maLog) { this.maLog = maLog; }
    public LocalDateTime getThoiGian() { return thoiGian; }
    public void setThoiGian(LocalDateTime thoiGian) { this.thoiGian = thoiGian; }
    public Integer getMaTK() { return maTK; }
    public void setMaTK(Integer maTK) { this.maTK = maTK; }
    public String getTenDangNhap() { return tenDangNhap; }
    public void setTenDangNhap(String tenDangNhap) { this.tenDangNhap = tenDangNhap; }
    public String getHanhDong() { return hanhDong; }
    public void setHanhDong(String hanhDong) { this.hanhDong = hanhDong; }
    public String getDoiTuong() { return doiTuong; }
    public void setDoiTuong(String doiTuong) { this.doiTuong = doiTuong; }
    public String getChiTiet() { return chiTiet; }
    public void setChiTiet(String chiTiet) { this.chiTiet = chiTiet; }
    public String getNguoiThucHien() { return nguoiThucHien; }
    public void setNguoiThucHien(String nguoiThucHien) { this.nguoiThucHien = nguoiThucHien; }
}
