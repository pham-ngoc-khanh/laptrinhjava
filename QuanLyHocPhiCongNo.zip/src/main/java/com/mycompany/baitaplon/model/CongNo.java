package com.mycompany.baitaplon.model;

import java.math.BigDecimal;

public class CongNo {
    private int maCongNo;
    private String maSV;
    private String hoTenSV;
    private String maHKNH;
    private String tenHKNH;
    private BigDecimal soTienNo;
    private BigDecimal soTienDaThu;
    private BigDecimal conLai;
    private String trangThai;
    private String ngayCapNhat;

    public CongNo() {}

    public CongNo(int maCongNo, String maSV, String maHKNH, BigDecimal soTienNo, BigDecimal soTienDaThu, BigDecimal conLai, String trangThai, String ngayCapNhat) {
        this.maCongNo = maCongNo;
        this.maSV = maSV;
        this.maHKNH = maHKNH;
        this.soTienNo = soTienNo;
        this.soTienDaThu = soTienDaThu;
        this.conLai = conLai;
        this.trangThai = trangThai;
        this.ngayCapNhat = ngayCapNhat;
    }

    public int getMaCongNo() { return maCongNo; }
    public void setMaCongNo(int maCongNo) { this.maCongNo = maCongNo; }
    public String getMaSV() { return maSV; }
    public void setMaSV(String maSV) { this.maSV = maSV; }
    public String getHoTenSV() { return hoTenSV; }
    public void setHoTenSV(String hoTenSV) { this.hoTenSV = hoTenSV; }
    public String getMaHKNH() { return maHKNH; }
    public void setMaHKNH(String maHKNH) { this.maHKNH = maHKNH; }
    public String getTenHKNH() { return tenHKNH; }
    public void setTenHKNH(String tenHKNH) { this.tenHKNH = tenHKNH; }
    public BigDecimal getSoTienNo() { return soTienNo; }
    public void setSoTienNo(BigDecimal soTienNo) { this.soTienNo = soTienNo; }
    public BigDecimal getSoTienDaThu() { return soTienDaThu; }
    public void setSoTienDaThu(BigDecimal soTienDaThu) { this.soTienDaThu = soTienDaThu; }
    public BigDecimal getConLai() { return conLai; }
    public void setConLai(BigDecimal conLai) { this.conLai = conLai; }
    public String getTrangThai() { return trangThai; }
    public void setTrangThai(String trangThai) { this.trangThai = trangThai; }
    public String getNgayCapNhat() { return ngayCapNhat; }
    public void setNgayCapNhat(String ngayCapNhat) { this.ngayCapNhat = ngayCapNhat; }
}
