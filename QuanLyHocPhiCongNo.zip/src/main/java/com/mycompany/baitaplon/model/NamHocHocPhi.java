package com.mycompany.baitaplon.model;

import java.math.BigDecimal;

public class NamHocHocPhi {
    private String maNam;
    private String namHoc;
    private BigDecimal hocPhiMotTinChi;
    private String ghiChu;

    public NamHocHocPhi() {}
    public NamHocHocPhi(String maNam, String namHoc, BigDecimal hocPhiMotTinChi, String ghiChu) {
        this.maNam = maNam; this.namHoc = namHoc; this.hocPhiMotTinChi = hocPhiMotTinChi; this.ghiChu = ghiChu;
    }

    public String getMaNam() { return maNam; }
    public void setMaNam(String maNam) { this.maNam = maNam; }
    public String getNamHoc() { return namHoc; }
    public void setNamHoc(String namHoc) { this.namHoc = namHoc; }
    public BigDecimal getHocPhiMotTinChi() { return hocPhiMotTinChi; }
    public void setHocPhiMotTinChi(BigDecimal hocPhiMotTinChi) { this.hocPhiMotTinChi = hocPhiMotTinChi; }
    public String getGhiChu() { return ghiChu; }
    public void setGhiChu(String ghiChu) { this.ghiChu = ghiChu; }
}
