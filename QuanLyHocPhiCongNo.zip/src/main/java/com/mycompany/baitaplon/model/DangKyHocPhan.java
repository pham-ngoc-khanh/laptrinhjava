package com.mycompany.baitaplon.model;

import java.math.BigDecimal;

public class DangKyHocPhan {
    private int maDKHP;
    private String maSV;
    private String hoTenSV;
    private String maHP;
    private String tenHP;
    private int soTinChi;
    private BigDecimal hocPhiMotTinChi;
    private String maHKNH;
    private String tenHKNH;
    private String ngayDangKy;

    public int getMaDKHP() { return maDKHP; }
    public void setMaDKHP(int maDKHP) { this.maDKHP = maDKHP; }
    public String getMaSV() { return maSV; }
    public void setMaSV(String maSV) { this.maSV = maSV; }
    public String getHoTenSV() { return hoTenSV; }
    public void setHoTenSV(String hoTenSV) { this.hoTenSV = hoTenSV; }
    public String getMaHP() { return maHP; }
    public void setMaHP(String maHP) { this.maHP = maHP; }
    public String getTenHP() { return tenHP; }
    public void setTenHP(String tenHP) { this.tenHP = tenHP; }
    public int getSoTinChi() { return soTinChi; }
    public void setSoTinChi(int soTinChi) { this.soTinChi = soTinChi; }
    public BigDecimal getHocPhiMotTinChi() { return hocPhiMotTinChi; }
    public void setHocPhiMotTinChi(BigDecimal hocPhiMotTinChi) { this.hocPhiMotTinChi = hocPhiMotTinChi; }
    public String getMaHKNH() { return maHKNH; }
    public void setMaHKNH(String maHKNH) { this.maHKNH = maHKNH; }
    public String getTenHKNH() { return tenHKNH; }
    public void setTenHKNH(String tenHKNH) { this.tenHKNH = tenHKNH; }
    public String getNgayDangKy() { return ngayDangKy; }
    public void setNgayDangKy(String ngayDangKy) { this.ngayDangKy = ngayDangKy; }

    public BigDecimal getThanhTien() {
        return hocPhiMotTinChi == null ? BigDecimal.ZERO : hocPhiMotTinChi.multiply(BigDecimal.valueOf(soTinChi));
    }
}
