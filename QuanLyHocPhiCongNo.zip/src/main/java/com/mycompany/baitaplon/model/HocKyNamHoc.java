package com.mycompany.baitaplon.model;

public class HocKyNamHoc {
    private String maHKNH;
    private int hocKy;
    private String namHoc;
    private String ngayBatDau;
    private String ngayKetThuc;

    public HocKyNamHoc() {}
    public String getMaHKNH(){return maHKNH;} public void setMaHKNH(String v){maHKNH=v;}
    public int getHocKy(){return hocKy;} public void setHocKy(int v){hocKy=v;}
    public String getNamHoc(){return namHoc;} public void setNamHoc(String v){namHoc=v;}
    public String getNgayBatDau(){return ngayBatDau;} public void setNgayBatDau(String v){ngayBatDau=v;}
    public String getNgayKetThuc(){return ngayKetThuc;} public void setNgayKetThuc(String v){ngayKetThuc=v;}
    @Override public String toString(){return "HK " + hocKy + " - " + namHoc;}
}
