package com.mycompany.baitaplon.model;

import java.math.BigDecimal;

public class HocPhi {
    private int maHPPhi;
    private String maSV;
    private String hoTenSV;
    private String maHKNH;
    private String tenHKNH;
    private int tongTinChi;
    private BigDecimal tongHocPhi;
    private BigDecimal mienGiam;
    private BigDecimal phaiThu;
    private String ngayTinh;

    public HocPhi() {}

    public HocPhi(int maHPPhi, String maSV, String maHKNH, int tongTinChi, BigDecimal tongHocPhi, BigDecimal mienGiam, BigDecimal phaiThu, String ngayTinh) {
        this.maHPPhi = maHPPhi;
        this.maSV = maSV;
        this.maHKNH = maHKNH;
        this.tongTinChi = tongTinChi;
        this.tongHocPhi = tongHocPhi;
        this.mienGiam = mienGiam;
        this.phaiThu = phaiThu;
        this.ngayTinh = ngayTinh;
    }

    public int getMaHPPhi() { return maHPPhi; }
    public void setMaHPPhi(int maHPPhi) { this.maHPPhi = maHPPhi; }
    public String getMaSV() { return maSV; }
    public void setMaSV(String maSV) { this.maSV = maSV; }
    public String getHoTenSV() { return hoTenSV; }
    public void setHoTenSV(String hoTenSV) { this.hoTenSV = hoTenSV; }
    public String getMaHKNH() { return maHKNH; }
    public void setMaHKNH(String maHKNH) { this.maHKNH = maHKNH; }
    public String getTenHKNH() { return tenHKNH; }
    public void setTenHKNH(String tenHKNH) { this.tenHKNH = tenHKNH; }
    public int getTongTinChi() { return tongTinChi; }
    public void setTongTinChi(int tongTinChi) { this.tongTinChi = tongTinChi; }
    public BigDecimal getTongHocPhi() { return tongHocPhi; }
    public void setTongHocPhi(BigDecimal tongHocPhi) { this.tongHocPhi = tongHocPhi; }
    public BigDecimal getMienGiam() { return mienGiam; }
    public void setMienGiam(BigDecimal mienGiam) { this.mienGiam = mienGiam; }
    public BigDecimal getPhaiThu() { return phaiThu; }
    public void setPhaiThu(BigDecimal phaiThu) { this.phaiThu = phaiThu; }
    public String getNgayTinh() { return ngayTinh; }
    public void setNgayTinh(String ngayTinh) { this.ngayTinh = ngayTinh; }
}
