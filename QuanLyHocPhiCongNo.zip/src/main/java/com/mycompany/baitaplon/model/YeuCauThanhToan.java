package com.mycompany.baitaplon.model;

import java.math.BigDecimal;

public class YeuCauThanhToan {
    private int maYeuCau;
    private String maSV;
    private String hoTenSV;
    private String maHKNH;
    private String tenHKNH;
    private BigDecimal soTien;
    private String hinhThucThanhToan;
    private String noiDung;
    private String ngayGui;
    private String trangThai;
    private String nguoiXuLy;
    private String ngayXuLy;
    private String lyDoTuChoi;

    public int getMaYeuCau() { return maYeuCau; }
    public void setMaYeuCau(int maYeuCau) { this.maYeuCau = maYeuCau; }
    public String getMaSV() { return maSV; }
    public void setMaSV(String maSV) { this.maSV = maSV; }
    public String getHoTenSV() { return hoTenSV; }
    public void setHoTenSV(String hoTenSV) { this.hoTenSV = hoTenSV; }
    public String getMaHKNH() { return maHKNH; }
    public void setMaHKNH(String maHKNH) { this.maHKNH = maHKNH; }
    public String getTenHKNH() { return tenHKNH; }
    public void setTenHKNH(String tenHKNH) { this.tenHKNH = tenHKNH; }
    public BigDecimal getSoTien() { return soTien; }
    public void setSoTien(BigDecimal soTien) { this.soTien = soTien; }
    public String getHinhThucThanhToan() { return hinhThucThanhToan; }
    public void setHinhThucThanhToan(String hinhThucThanhToan) { this.hinhThucThanhToan = hinhThucThanhToan; }
    public String getNoiDung() { return noiDung; }
    public void setNoiDung(String noiDung) { this.noiDung = noiDung; }
    public String getNgayGui() { return ngayGui; }
    public void setNgayGui(String ngayGui) { this.ngayGui = ngayGui; }
    public String getTrangThai() { return trangThai; }
    public void setTrangThai(String trangThai) { this.trangThai = trangThai; }
    public String getNguoiXuLy() { return nguoiXuLy; }
    public void setNguoiXuLy(String nguoiXuLy) { this.nguoiXuLy = nguoiXuLy; }
    public String getNgayXuLy() { return ngayXuLy; }
    public void setNgayXuLy(String ngayXuLy) { this.ngayXuLy = ngayXuLy; }
    public String getLyDoTuChoi() { return lyDoTuChoi; }
    public void setLyDoTuChoi(String lyDoTuChoi) { this.lyDoTuChoi = lyDoTuChoi; }

    public String getTrangThaiHienThi() {
        if (trangThai == null) return "";
        return switch (trangThai) {
            case "CHO_XAC_NHAN" -> "Chờ xác nhận";
            case "DA_XAC_NHAN" -> "Đã nhận tiền - Hoàn tất";
            case "TU_CHOI" -> "Từ chối";
            case "DA_HUY" -> "Đã hủy";
            default -> trangThai;
        };
    }
}
