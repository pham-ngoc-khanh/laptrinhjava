package com.mycompany.baitaplon.controller;

import com.mycompany.baitaplon.service.DangKyHocPhanService;

/**
 * Controller của tầng nghiệp vụ. Controller giữ vai trò điểm vào từ View,
 * ủy quyền xử lý cho Service và không truy cập trực tiếp JDBC.
 */
public class DangKyHocPhanController extends DangKyHocPhanService {
    public DangKyHocPhanController() {
        super();
    }
}
