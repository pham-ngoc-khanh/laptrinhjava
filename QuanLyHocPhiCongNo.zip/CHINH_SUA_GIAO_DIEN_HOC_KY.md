# Chỉnh sửa giao diện Học kỳ

Bản này sửa trực tiếp màn hình **Học kỳ** và component ComboBox dùng chung.

- Bố cục form Học kỳ chuyển sang lưới responsive: tự giảm số cột khi cửa sổ hẹp, không ép/tràn chữ.
- Tách hàng **Thao tác** riêng, các nút Thêm / Cập nhật / Xóa / Làm mới luôn có kích thước an toàn.
- Thêm tiêu đề **Thông tin học kỳ** và hướng dẫn định dạng ngày.
- Thêm tiêu đề **Danh sách học kỳ** và bộ đếm số học kỳ.
- Bảng có sắp xếp theo cột, chiều rộng cột hợp lý, thanh cuộn khi cần.
- Sửa ComboBox: mũi tên được vẽ bằng vector, không còn ký tự ô vuông do thiếu font.
- Khi bảng đang được sắp xếp, chọn/sửa/xóa vẫn lấy đúng dòng dữ liệu.
- Không thay đổi cấu trúc database hay logic nghiệp vụ hiện có.
