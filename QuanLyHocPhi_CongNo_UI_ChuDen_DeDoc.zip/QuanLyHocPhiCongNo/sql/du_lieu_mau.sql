USE QuanLyDaoTao;

-- Chỉ chạy file này trên cơ sở dữ liệu mới/trống.
INSERT IGNORE INTO Khoa (MaKhoa, TenKhoa, DienThoai, Email) VALUES
('K001', 'Khoa Công nghệ thông tin', '02431234567', 'cntt@university.edu.vn'),
('K002', 'Khoa Kinh tế', '02431234568', 'kt@university.edu.vn'),
('K003', 'Khoa Điều dưỡng', '02431234569', 'dd@university.edu.vn');

INSERT IGNORE INTO Nganh (MaNganh, TenNganh, MaKhoa) VALUES
('N001', 'Công nghệ thông tin', 'K001'),
('N002', 'Trí tuệ nhân tạo', 'K001'),
('N003', 'Kế toán', 'K002'),
('N004', 'Quản trị kinh doanh', 'K002');

INSERT IGNORE INTO Lop (MaLop, TenLop, MaNganh, KhoaHoc) VALUES
('L001', 'D20CNTT01', 'N001', 2020),
('L002', 'D20CNTT02', 'N001', 2020),
('L003', 'D20AI01', 'N002', 2020),
('L004', 'D21KT01', 'N003', 2021);

INSERT IGNORE INTO SinhVien (MaSV, HoTen, NgaySinh, GioiTinh, DiaChi, SDT, Email, MaLop) VALUES
('SV001', 'Nguyễn Văn A', '2002-05-15', 'Nam', 'Hà Nội', '0912345678', 'a@sv.edu.vn', 'L001'),
('SV002', 'Trần Thị B', '2002-08-20', 'Nữ', 'Hải Phòng', '0923456789', 'b@sv.edu.vn', 'L001'),
('SV003', 'Lê Văn C', '2002-12-10', 'Nam', 'Hải Dương', '0934567890', 'c@sv.edu.vn', 'L002'),
('SV004', 'Phạm Thị D', '2003-03-25', 'Nữ', 'Hưng Yên', '0945678901', 'd@sv.edu.vn', 'L003'),
('SV005', 'Hoàng Văn E', '2003-07-01', 'Nam', 'Hà Nội', '0956789012', 'e@sv.edu.vn', 'L004');

INSERT IGNORE INTO HocKyNamHoc (MaHKNH, HocKy, NamHoc, NgayBatDau, NgayKetThuc) VALUES
('HK20201', 1, '2020-2021', '2020-09-01', '2021-01-15'),
('HK20202', 2, '2020-2021', '2021-02-01', '2021-06-30'),
('HK20211', 1, '2021-2022', '2021-09-01', '2022-01-15'),
('HK20212', 2, '2021-2022', '2022-02-01', '2022-06-30');

INSERT IGNORE INTO HocPhan (MaHP, TenHP, SoTinChi, HocPhiMotTinChi, MaNganh) VALUES
('HP001', 'Lập trình C++', 4, 550000, 'N001'),
('HP002', 'Cơ sở dữ liệu', 3, 550000, 'N001'),
('HP003', 'Toán rời rạc', 3, 450000, 'N001'),
('HP004', 'Lập trình Java', 4, 550000, 'N001'),
('HP005', 'Trí tuệ nhân tạo', 3, 600000, 'N002'),
('HP006', 'Kế toán tài chính', 3, 500000, 'N003'),
('HP007', 'Quản trị marketing', 3, 500000, 'N004');

INSERT IGNORE INTO DangKyHocPhan (MaSV, MaHP, MaHKNH, NgayDangKy) VALUES
('SV001', 'HP001', 'HK20201', '2020-09-01'),
('SV001', 'HP002', 'HK20201', '2020-09-01'),
('SV001', 'HP003', 'HK20201', '2020-09-01'),
('SV002', 'HP001', 'HK20201', '2020-09-02'),
('SV002', 'HP003', 'HK20201', '2020-09-02'),
('SV003', 'HP001', 'HK20201', '2020-09-01'),
('SV003', 'HP002', 'HK20201', '2020-09-01'),
('SV004', 'HP005', 'HK20211', '2021-09-01'),
('SV005', 'HP006', 'HK20211', '2021-09-01');

INSERT IGNORE INTO HocPhi (MaSV, MaHKNH, TongTinChi, TongHocPhi, MienGiam, PhaiThu, NgayTinh) VALUES
('SV001', 'HK20201', 10, 5200000, 0, 5200000, '2020-09-10'),
('SV002', 'HK20201', 7, 3550000, 500000, 3050000, '2020-09-10'),
('SV003', 'HK20201', 7, 3850000, 0, 3850000, '2020-09-10'),
('SV004', 'HK20211', 3, 1800000, 0, 1800000, '2021-09-10'),
('SV005', 'HK20211', 3, 1500000, 0, 1500000, '2021-09-10');

INSERT IGNORE INTO CongNo (MaSV, MaHKNH, SoTienNo, SoTienDaThu, ConLai, TrangThai, NgayCapNhat) VALUES
('SV001', 'HK20201', 5200000, 3000000, 2200000, 'Đang nợ', '2020-12-01'),
('SV002', 'HK20201', 3050000, 3050000, 0, 'Đã nộp đủ', '2020-11-15'),
('SV003', 'HK20201', 3850000, 0, 3850000, 'Chưa nộp', '2020-12-01'),
('SV004', 'HK20211', 1800000, 1000000, 800000, 'Đang nợ', '2021-12-01'),
('SV005', 'HK20211', 1500000, 1500000, 0, 'Đã nộp đủ', '2021-11-20');

INSERT IGNORE INTO ThanhToan (MaThanhToan, MaSV, MaHKNH, SoTien, HinhThucThanhToan, NgayThanhToan, NguoiThu, GhiChu) VALUES
(1, 'SV001', 'HK20201', 3000000, 'Chuyển khoản', '2020-10-15', 'Thư ký khoa', 'Đợt 1'),
(2, 'SV002', 'HK20201', 3050000, 'Tiền mặt', '2020-11-15', 'Thư ký khoa', 'Đợt 1'),
(3, 'SV004', 'HK20211', 1000000, 'Chuyển khoản', '2021-10-20', 'Thư ký khoa', 'Đợt 1'),
(4, 'SV005', 'HK20211', 1500000, 'Chuyển khoản', '2021-11-20', 'Thư ký khoa', 'Đợt 1');

INSERT IGNORE INTO TaiKhoan (TenDangNhap, MatKhau, VaiTro, MaSV, HoTen, TrangThai) VALUES
('thuky', '123456', 'THU_KY', NULL, 'Nguyễn Văn Thư Ký', 'Hoat dong'),
('sv001', '123456', 'SINH_VIEN', 'SV001', 'Nguyễn Văn A', 'Hoat dong'),
('sv002', '123456', 'SINH_VIEN', 'SV002', 'Trần Thị B', 'Hoat dong'),
('sv003', '123456', 'SINH_VIEN', 'SV003', 'Lê Văn C', 'Hoat dong'),
('sv004', '123456', 'SINH_VIEN', 'SV004', 'Phạm Thị D', 'Hoat dong'),
('sv005', '123456', 'SINH_VIEN', 'SV005', 'Hoàng Văn E', 'Hoat dong');
