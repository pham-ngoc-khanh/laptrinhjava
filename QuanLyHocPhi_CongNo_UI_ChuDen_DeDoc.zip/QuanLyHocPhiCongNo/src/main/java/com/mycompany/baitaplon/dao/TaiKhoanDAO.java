package com.mycompany.baitaplon.dao;

import com.mycompany.baitaplon.model.TaiKhoan;
import com.mycompany.baitaplon.model.VaiTro;
import com.mycompany.baitaplon.util.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TaiKhoanDAO {

    public TaiKhoan authenticate(String tenDangNhap, String matKhau) throws SQLException {
        String sql = "SELECT * FROM TaiKhoan WHERE TenDangNhap = ? AND MatKhau = ? AND TrangThai = 'Hoat dong'";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, tenDangNhap.trim());
            ps.setString(2, matKhau);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    public boolean changePassword(String username, String oldPassword, String newPassword) throws SQLException {
        if (newPassword == null || newPassword.length() < 6) throw new SQLException("Mật khẩu mới phải có ít nhất 6 ký tự.");
        String sql = "UPDATE TaiKhoan SET MatKhau=? WHERE TenDangNhap=? AND MatKhau=? AND TrangThai='Hoat dong'";
        try (Connection conn = DatabaseConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newPassword); ps.setString(2, username); ps.setString(3, oldPassword);
            return ps.executeUpdate() == 1;
        }
    }

    private TaiKhoan mapRow(ResultSet rs) throws SQLException {
        TaiKhoan tk = new TaiKhoan();
        tk.setMaTK(rs.getInt("MaTK"));
        tk.setTenDangNhap(rs.getString("TenDangNhap"));
        tk.setMatKhau(rs.getString("MatKhau"));
        tk.setVaiTro(VaiTro.fromDb(rs.getString("VaiTro")));
        tk.setMaSV(rs.getString("MaSV"));
        tk.setHoTen(rs.getString("HoTen"));
        tk.setTrangThai(rs.getString("TrangThai"));
        return tk;
    }
}
