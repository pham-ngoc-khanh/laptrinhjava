package com.mycompany.baitaplon.ui;

import com.mycompany.baitaplon.dao.SinhVienDAO;
import com.mycompany.baitaplon.dao.LopDAO;
import com.mycompany.baitaplon.dao.CongNoDAO;
import com.mycompany.baitaplon.model.SinhVien;
import com.mycompany.baitaplon.model.Lop;
import com.mycompany.baitaplon.model.CongNo;
import com.mycompany.baitaplon.util.UserSession;
import com.mycompany.baitaplon.util.InputValidator;
import com.mycompany.baitaplon.util.TableExportUtil;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

public class SinhVienPanel extends JPanel {
    private RoundedField txtMaSV, txtHoTen, txtNgaySinh, txtDiaChi, txtSDT, txtEmail, txtSearch;
    private RoundedCombo<String> cboGioiTinh, cboLop, cboLocLop, cboLocTrangThai;
    private StyledTable table;
    private DefaultTableModel model;
    private SinhVienDAO svDAO = new SinhVienDAO();
    private LopDAO lopDAO = new LopDAO();
    private CongNoDAO cnDAO = new CongNoDAO();
    private java.util.List<Lop> dsLop;
    private RoundedButton bThem, bSua, bXoa, bTim, bLamMoi, bXemChiTiet, bXuatFile;
    private JPanel inputPanel;

    private Consumer<String> detailOpener;

    public void setDetailOpener(Consumer<String> op) { this.detailOpener = op; }

    public SinhVienPanel() {
        super(new BorderLayout(14, 14));
        setOpaque(false);
        setBorder(new EmptyBorder(6, 6, 6, 6));
        add(createTopPanel(), BorderLayout.NORTH);
        add(createTablePanel(), BorderLayout.CENTER);
        add(createButtonPanel(), BorderLayout.SOUTH);
        loadData();
        loadLop();
    }

    public void configureForRole() {
        if (UserSession.isSinhVien()) {
            if (inputPanel != null) inputPanel.setVisible(false);
            if (bThem != null) bThem.setVisible(false);
            if (bSua != null) bSua.setVisible(false);
            if (bXoa != null) bXoa.setVisible(false);
        }
    }

    private JLabel makeLbl(String s) {
        JLabel l = new JLabel(s);
        l.setFont(Theme.FONT_LABEL);
        l.setForeground(Theme.TEXT_SECONDARY);
        return l;
    }

    private JPanel createTopPanel() {
        JPanel wrapOuter = new JPanel(new BorderLayout(0, 10));
        wrapOuter.setOpaque(false);

        inputPanel = new JPanel(new BorderLayout());
        inputPanel.setOpaque(false);
        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(20, 24, 18, 24));
        card.setTopAccent(Theme.PRIMARY);

        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 14);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0; p.add(makeLbl("Mã sinh viên"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.4;
        txtMaSV = new RoundedField(16); txtMaSV.setPlaceholder("VD: SV001"); p.add(txtMaSV, gbc);
        gbc.weightx = 0;

        gbc.gridx = 2; gbc.gridy = 0; p.add(makeLbl("Họ và tên"), gbc);
        gbc.gridx = 3; gbc.weightx = 0.6;
        txtHoTen = new RoundedField(20); txtHoTen.setPlaceholder("Họ tên đầy đủ"); p.add(txtHoTen, gbc);
        gbc.weightx = 0;

        gbc.gridx = 0; gbc.gridy = 1; p.add(makeLbl("Ngày sinh (YYYY-MM-DD)"), gbc);
        gbc.gridx = 1;
        txtNgaySinh = new RoundedField(16); txtNgaySinh.setPlaceholder("2002-12-31"); p.add(txtNgaySinh, gbc);

        gbc.gridx = 2; gbc.gridy = 1; p.add(makeLbl("Giới tính"), gbc);
        gbc.gridx = 3;
        cboGioiTinh = new RoundedCombo<>(new String[]{"Nam", "Nữ"});
        UiUtils.makeFlexible(cboGioiTinh,140,220,36);
        p.add(cboGioiTinh, gbc);

        gbc.gridx = 0; gbc.gridy = 2; p.add(makeLbl("Địa chỉ"), gbc);
        gbc.gridx = 1;
        txtDiaChi = new RoundedField(20); txtDiaChi.setPlaceholder("Số nhà, đường, phường..."); p.add(txtDiaChi, gbc);

        gbc.gridx = 2; gbc.gridy = 2; p.add(makeLbl("Số điện thoại"), gbc);
        gbc.gridx = 3;
        txtSDT = new RoundedField(20); txtSDT.setPlaceholder("VD: 0912345678"); p.add(txtSDT, gbc);

        gbc.gridx = 0; gbc.gridy = 3; p.add(makeLbl("Email"), gbc);
        gbc.gridx = 1;
        txtEmail = new RoundedField(20); txtEmail.setPlaceholder("email@sv.edu.vn"); p.add(txtEmail, gbc);

        gbc.gridx = 2; gbc.gridy = 3; p.add(makeLbl("Lớp"), gbc);
        gbc.gridx = 3;
        cboLop = new RoundedCombo<>();
        UiUtils.makeFlexible(cboLop,160,220,36);
        p.add(cboLop, gbc);

        card.add(p, BorderLayout.CENTER);
        inputPanel.add(card, BorderLayout.CENTER);
        wrapOuter.add(inputPanel, BorderLayout.NORTH);

        CardPanel filterCard = new CardPanel(new BorderLayout());
        filterCard.setBorder(new EmptyBorder(16, 24, 16, 24));
        filterCard.setTopAccent(Theme.INFO);
        JPanel fp = new JPanel(new WrapLayout(FlowLayout.LEFT, 14, 8));
        fp.setOpaque(false);

        JPanel g1 = new JPanel(); g1.setLayout(new BoxLayout(g1, BoxLayout.Y_AXIS)); g1.setOpaque(false);
        g1.add(makeLbl("🔍 Tìm kiếm (Mã SV / Họ tên)")); g1.add(Box.createVerticalStrut(4));
        txtSearch = new RoundedField(28); txtSearch.setPlaceholder("Nhập từ khóa cần tìm...");
        UiUtils.makeFlexible(txtSearch,200,300,36);
        g1.add(txtSearch);

        JPanel g2 = new JPanel(); g2.setLayout(new BoxLayout(g2, BoxLayout.Y_AXIS)); g2.setOpaque(false);
        g2.add(makeLbl("🏫 Lọc theo Lớp")); g2.add(Box.createVerticalStrut(4));
        cboLocLop = new RoundedCombo<>(); UiUtils.makeFlexible(cboLocLop,160,230,36);
        g2.add(cboLocLop);

        JPanel g3 = new JPanel(); g3.setLayout(new BoxLayout(g3, BoxLayout.Y_AXIS)); g3.setOpaque(false);
        g3.add(makeLbl("💳 Trạng thái tài chính")); g3.add(Box.createVerticalStrut(4));
        cboLocTrangThai = new RoundedCombo<>(new String[]{"📊 Tất cả", "🟢 Đã nộp đủ", "🟡 Đang nợ", "🔴 Chưa nộp"});
        UiUtils.makeFlexible(cboLocTrangThai,160,200,36);
        g3.add(cboLocTrangThai);

        bTim = new RoundedButton("Lọc", "primary");
        bTim.setPreferredSize(new Dimension(110, 40));
        bLamMoi = new RoundedButton("Làm mới", "warning");
        bLamMoi.setPreferredSize(new Dimension(130, 40));
        bXuatFile = new RoundedButton("Xuất file", "success");
        bXuatFile.setPreferredSize(new Dimension(130, 40));
        bXemChiTiet = new RoundedButton("Xem chi tiết", "purple");
        bXemChiTiet.setPreferredSize(new Dimension(150, 40));

        bTim.addActionListener(e -> loc());
        bLamMoi.addActionListener(e -> { clearForm(); cboLocLop.setSelectedIndex(0); cboLocTrangThai.setSelectedIndex(0); loadData(); });
        bXuatFile.addActionListener(e -> xuatFile());
        bXemChiTiet.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row < 0) { JOptionPane.showMessageDialog(this, "Chọn 1 sinh viên trong bảng"); return; }
            String maSV = str(model.getValueAt(row, 0));
            if (detailOpener != null) detailOpener.accept(maSV);
        });

        fp.add(g1); fp.add(g2); fp.add(g3);
        JPanel bp = new JPanel(); bp.setLayout(new BoxLayout(bp, BoxLayout.Y_AXIS)); bp.setOpaque(false);
        bp.add(Box.createVerticalStrut(18));
        JPanel brow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); brow.setOpaque(false);
        brow.add(bTim); brow.add(bLamMoi); brow.add(bXemChiTiet); brow.add(bXuatFile); bp.add(brow);
        fp.add(bp);

        filterCard.add(fp, BorderLayout.CENTER);
        wrapOuter.add(filterCard, BorderLayout.CENTER);
        return wrapOuter;
    }

    private JPanel createTablePanel() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(12, 12, 12, 12));
        card.setTopAccent(Theme.SECONDARY);

        String[] cols = {"Mã SV", "Họ tên", "Ngày sinh", "Giới tính", "Lớp", "Tổng học phí", "Đã thu", "Còn lại", "Trạng thái"};
        model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new StyledTable();
        table.setModel(model);
        table.getColumnModel().getColumn(0).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setPreferredWidth(180);
        table.getColumnModel().getColumn(2).setPreferredWidth(100);
        table.getColumnModel().getColumn(3).setPreferredWidth(70);
        table.getColumnModel().getColumn(4).setPreferredWidth(110);
        table.getColumnModel().getColumn(5).setPreferredWidth(130);
        table.getColumnModel().getColumn(6).setPreferredWidth(130);
        table.getColumnModel().getColumn(7).setPreferredWidth(130);
        table.getColumnModel().getColumn(8).setPreferredWidth(110);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(e -> { if (!e.getValueIsAdjusting()) fillForm(); });
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int row = table.getSelectedRow();
                    if (row >= 0) {
                        String maSV = str(model.getValueAt(row, 0));
                        if (detailOpener != null) detailOpener.accept(maSV);
                    }
                }
            }
        });
        table.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean isSel, boolean hasFocus, int row, int col) {
                JLabel c = (JLabel) super.getTableCellRendererComponent(t, v, isSel, hasFocus, row, col);
                c.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
                if (!isSel) c.setBackground(row % 2 == 0 ? Color.WHITE : Theme.SURFACE_ALT);
                if (col == 8 && v != null) {
                    String s = v.toString();
                    if (s.contains("Đã nộp")) { c.setForeground(Theme.SUCCESS); c.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD)); }
                    else if (s.contains("Đang nợ")) { c.setForeground(Theme.WARNING); c.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD)); }
                    else if (s.contains("Chưa")) { c.setForeground(Theme.DANGER); c.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD)); }
                }
                return c;
            }
        });

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        sp.getViewport().setOpaque(false);
        sp.setOpaque(false);
        UiUtils.tuneScrollPane(sp);
        card.add(sp, BorderLayout.CENTER);

        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false); wrap.add(card);
        return wrap;
    }

    private JPanel createButtonPanel() {
        JPanel p = new JPanel(new WrapLayout(FlowLayout.CENTER, 12, 6));
        p.setOpaque(false);
        bThem = new RoundedButton("Thêm mới", "primary");
        bSua = new RoundedButton("Cập nhật", "secondary");
        bXoa = new RoundedButton("Xóa", "danger");
        bThem.addActionListener(e -> them());
        bSua.addActionListener(e -> sua());
        bXoa.addActionListener(e -> xoa());
        p.add(bThem); p.add(bSua); p.add(bXoa);
        return p;
    }

    private Map<String, Object[]> loadCongNoMap() throws SQLException {
        Map<String, Object[]> map = new HashMap<>();
        List<CongNo> dsCN = UserSession.isSinhVien()
                ? cnDAO.getByMaSV(UserSession.getMaSV())
                : cnDAO.getAll();
        Map<String, BigDecimal> tongHP = new HashMap<>();
        Map<String, BigDecimal> tongThu = new HashMap<>();
        Map<String, BigDecimal> tongConLai = new HashMap<>();
        Map<String, String> trangThaiCuoi = new HashMap<>();
        for (CongNo cn : dsCN) {
            String maSV = cn.getMaSV();
            tongHP.put(maSV, tongHP.getOrDefault(maSV, BigDecimal.ZERO).add(cn.getSoTienNo() != null ? cn.getSoTienNo() : BigDecimal.ZERO));
            tongThu.put(maSV, tongThu.getOrDefault(maSV, BigDecimal.ZERO).add(cn.getSoTienDaThu() != null ? cn.getSoTienDaThu() : BigDecimal.ZERO));
            tongConLai.put(maSV, tongConLai.getOrDefault(maSV, BigDecimal.ZERO).add(cn.getConLai() != null ? cn.getConLai() : BigDecimal.ZERO));
            trangThaiCuoi.put(maSV, cn.getTrangThai());
        }
        for (String maSV : tongHP.keySet()) {
            BigDecimal cl = tongConLai.get(maSV);
            String tt;
            if (cl == null || cl.signum() <= 0) tt = "🟢 Đã nộp đủ";
            else if (cl.compareTo(tongHP.get(maSV)) >= 0) tt = "🔴 Chưa nộp";
            else tt = "🟡 Đang nợ";
            map.put(maSV, new Object[]{tongHP.get(maSV), tongThu.get(maSV), cl, tt});
        }
        return map;
    }

    private void fillTable(List<SinhVien> list) throws SQLException {
        Map<String, Object[]> cnMap = loadCongNoMap();
        model.setRowCount(0);
        for (SinhVien sv : list) {
            Object[] cn = cnMap.get(sv.getMaSV());
            BigDecimal hp = cn != null ? (BigDecimal) cn[0] : BigDecimal.ZERO;
            BigDecimal thu = cn != null ? (BigDecimal) cn[1] : BigDecimal.ZERO;
            BigDecimal cl = cn != null ? (BigDecimal) cn[2] : BigDecimal.ZERO;
            String tt = cn != null ? (String) cn[3] : "🔴 Chưa nộp";
            model.addRow(new Object[]{sv.getMaSV(), sv.getHoTen(), sv.getNgaySinh(), sv.getGioiTinh(),
                    sv.getTenLop(),
                    String.format("%,.0f", hp),
                    String.format("%,.0f", thu),
                    String.format("%,.0f", cl),
                    tt});
        }
    }

    private void loadData() {
        try {
            List<SinhVien> list = UserSession.isSinhVien()
                    ? java.util.Collections.singletonList(svDAO.getById(UserSession.getMaSV()))
                    : svDAO.getAll();
            if (list.size() == 1 && list.get(0) == null) list = java.util.Collections.emptyList();
            fillTable(list);
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    private void loadLop() {
        try {
            dsLop = lopDAO.getAll();
            cboLop.removeAllItems();
            for (Lop l : dsLop) cboLop.addItem(l.getMaLop() + " - " + l.getTenLop());
            cboLocLop.removeAllItems();
            cboLocLop.addItem("🌐 Tất cả lớp");
            for (Lop l : dsLop) cboLocLop.addItem(l.getMaLop() + " - " + l.getTenLop());
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    private String getSelectedMaLop() {
        String s = (String) cboLop.getSelectedItem();
        if (s == null) return null;
        return s.split(" - ")[0];
    }

    private void fillForm() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        String maSV = str(model.getValueAt(row, 0));
        try {
            SinhVien sv = svDAO.getById(maSV);
            if (sv == null) return;
            txtMaSV.setText(sv.getMaSV());
            txtHoTen.setText(sv.getHoTen());
            txtNgaySinh.setText(sv.getNgaySinh() != null ? sv.getNgaySinh() : "");
            String gt = sv.getGioiTinh();
            cboGioiTinh.setSelectedItem((gt == null || gt.isEmpty()) ? "Nam" : gt);
            txtDiaChi.setText(sv.getDiaChi() != null ? sv.getDiaChi() : "");
            txtSDT.setText(sv.getSdt() != null ? sv.getSdt() : "");
            txtEmail.setText(sv.getEmail() != null ? sv.getEmail() : "");
            String lop = sv.getMaLop();
            if (lop != null && !lop.isEmpty()) for (int i = 0; i < cboLop.getItemCount(); i++)
                if (cboLop.getItemAt(i).startsWith(lop + " - ")) { cboLop.setSelectedIndex(i); break; }
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    private String str(Object o) { return o == null ? "" : o.toString(); }

    private void clearForm() {
        for (RoundedField f : new RoundedField[]{txtMaSV, txtHoTen, txtNgaySinh, txtDiaChi, txtSDT, txtEmail, txtSearch})
            f.setText("");
        cboGioiTinh.setSelectedIndex(0);
        table.clearSelection();
    }

    private SinhVien getFormData() {
        String ma = txtMaSV.getText().trim().toUpperCase();
        String hoTen = txtHoTen.getText().trim();
        String ngaySinh = txtNgaySinh.getText().trim();
        String sdt = txtSDT.getText().trim();
        String email = txtEmail.getText().trim();
        if (ma.isEmpty()) { JOptionPane.showMessageDialog(this, "Vui lòng nhập Mã SV"); return null; }
        if (!ma.matches("[A-Z0-9_-]{3,10}")) { JOptionPane.showMessageDialog(this, "Mã SV chỉ gồm chữ, số, _ hoặc - và tối đa 10 ký tự."); return null; }
        if (hoTen.isEmpty()) { JOptionPane.showMessageDialog(this, "Vui lòng nhập Họ và tên"); return null; }
        if (!InputValidator.isValidDate(ngaySinh)) { JOptionPane.showMessageDialog(this, "Ngày sinh phải theo định dạng YYYY-MM-DD và là ngày hợp lệ."); return null; }
        if (!InputValidator.isValidPhone(sdt)) { JOptionPane.showMessageDialog(this, "Số điện thoại không hợp lệ."); return null; }
        if (!InputValidator.isValidEmail(email)) { JOptionPane.showMessageDialog(this, "Email không hợp lệ."); return null; }
        SinhVien sv = new SinhVien();
        sv.setMaSV(ma);
        sv.setHoTen(hoTen);
        sv.setNgaySinh(ngaySinh.isEmpty() ? null : ngaySinh);
        sv.setGioiTinh(cboGioiTinh.getSelectedItem().toString());
        sv.setDiaChi(txtDiaChi.getText().trim());
        sv.setSdt(sdt);
        sv.setEmail(email);
        sv.setMaLop(getSelectedMaLop());
        return sv;
    }

    private void them() {
        SinhVien sv = getFormData(); if (sv == null) return;
        try {
            if (svDAO.insert(sv)) { JOptionPane.showMessageDialog(this, "✅ Thêm thành công"); loadData(); clearForm(); }
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    private void sua() {
        if (table.getSelectedRow() < 0) { JOptionPane.showMessageDialog(this, "Chọn sinh viên cần sửa"); return; }
        SinhVien sv = getFormData(); if (sv == null) return;
        try {
            if (svDAO.update(sv)) { JOptionPane.showMessageDialog(this, "✅ Cập nhật thành công"); loadData(); clearForm(); }
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    private void xoa() {
        if (table.getSelectedRow() < 0) { JOptionPane.showMessageDialog(this, "Chọn sinh viên cần xóa"); return; }
        if (JOptionPane.showConfirmDialog(this, "Xóa sinh viên sẽ xóa cả đăng ký học phần, học phí, công nợ, giao dịch và tài khoản liên quan.\nBạn chắc chắn muốn tiếp tục?", "Xác nhận xóa toàn bộ dữ liệu", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE) != JOptionPane.YES_OPTION) return;
        try {
            if (svDAO.delete(txtMaSV.getText().trim())) { JOptionPane.showMessageDialog(this, "✅ Xóa thành công"); loadData(); clearForm(); }
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    private void loc() {
        try {
            String kw = txtSearch.getText().trim();
            int lopIdx = cboLocLop.getSelectedIndex();
            String maLopLoc = (lopIdx > 0 && cboLocLop.getSelectedItem() != null)
                    ? cboLocLop.getSelectedItem().toString().split(" - ")[0] : null;
            int ttIdx = cboLocTrangThai.getSelectedIndex();
            String ttLoc = ttIdx == 1 ? "🟢 Đã nộp đủ" : ttIdx == 2 ? "🟡 Đang nợ" : ttIdx == 3 ? "🔴 Chưa nộp" : "";
            List<SinhVien> list;
            if (UserSession.isSinhVien()) {
                list = java.util.Collections.singletonList(svDAO.getById(UserSession.getMaSV()));
                if (list.size() == 1 && list.get(0) == null) list = java.util.Collections.emptyList();
            } else if (!kw.isEmpty()) {
                list = svDAO.search(kw);
            } else {
                list = svDAO.getAll();
            }
            if (maLopLoc != null) {
                final String fLop = maLopLoc;
                list.removeIf(sv -> sv.getMaLop() == null || !sv.getMaLop().equals(fLop));
            }
            if (!ttLoc.isEmpty()) {
                Map<String, Object[]> cnMap = loadCongNoMap();
                final String fTT = ttLoc;
                list.removeIf(sv -> {
                    Object[] cn = cnMap.get(sv.getMaSV());
                    String tt = cn != null ? (String) cn[3] : "🔴 Chưa nộp";
                    return !tt.equals(fTT);
                });
            }
            fillTable(list);
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    public void searchFromGlobal(String keyword) {
        if (keyword == null) return;
        txtSearch.setText(keyword.trim());
        loc();
    }

    public void refreshData() { loadData(); }

    private void xuatFile() {
        TableExportUtil.exportCsv(this, table, "danh-sach-sinh-vien-cong-no");
    }
}
