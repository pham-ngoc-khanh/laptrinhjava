package com.mycompany.baitaplon;

import com.mycompany.baitaplon.ui.LoginDialog;
import com.mycompany.baitaplon.ui.MainFrame;
import com.mycompany.baitaplon.ui.Theme;
import com.mycompany.baitaplon.util.DatabaseInitializer;
import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;

public class Baitaplon {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            configureSwing();
            try {
                DatabaseInitializer.initialize();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(null,
                        "Không thể khởi tạo/kết nối MySQL.\n\n" +
                        "Kiểm tra MySQL Server đang chạy và cấu hình trong:\n" +
                        "src/main/resources/database.properties\n\n" +
                        "Chi tiết: " + shortMessage(e),
                        "Lỗi kết nối cơ sở dữ liệu", JOptionPane.ERROR_MESSAGE);
                return;
            }

            LoginDialog login = new LoginDialog(null);
            login.setVisible(true);
            if (!login.isAuthenticated()) return;
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        });
    }

    private static void configureSwing() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}
        UIManager.put("Label.font", Theme.FONT_BODY);
        UIManager.put("Button.font", Theme.FONT_BODY);
        UIManager.put("OptionPane.messageFont", Theme.FONT_BODY);
        UIManager.put("OptionPane.buttonFont", Theme.FONT_BODY.deriveFont(Font.BOLD));
        UIManager.put("ToolTip.font", Theme.FONT_SMALL);
    }

    private static String shortMessage(Throwable t) {
        String m = t.getMessage();
        if (m == null || m.isBlank()) return t.getClass().getSimpleName();
        return m.length() > 350 ? m.substring(0, 350) + "..." : m;
    }
}
