package com.mycompany.baitaplon.ui;

import com.mycompany.baitaplon.dao.HocKyNamHocDAO;
import com.mycompany.baitaplon.model.HocKyNamHoc;
import com.mycompany.baitaplon.util.InputValidator;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import java.awt.*;
import java.sql.SQLException;

/**
 * Màn hình quản lý học kỳ.
 *
 * Bố cục được thiết kế responsive để không ép ô nhập, không tràn chữ và
 * không đẩy các nút thao tác ra ngoài vùng nhìn thấy khi cửa sổ hẹp.
 */
public class HocKyPanel extends JPanel {
    private final HocKyNamHocDAO dao = new HocKyNamHocDAO();

    private RoundedField ma;
    private RoundedField nam;
    private RoundedField bd;
    private RoundedField kt;
    private RoundedCombo<String> hk;
    private StyledTable table;
    private DefaultTableModel model;
    private JLabel countLabel;

    public HocKyPanel() {
        super(new BorderLayout(14, 14));
        setOpaque(false);
        setBorder(new EmptyBorder(8, 8, 8, 8));
        add(createFormCard(), BorderLayout.NORTH);
        add(createTableCard(), BorderLayout.CENTER);
        load();
    }

    private JPanel createFormCard() {
        CardPanel card = new CardPanel(new BorderLayout(0, 14));
        card.setTopAccent(Theme.INFO);
        card.setBorder(new EmptyBorder(20, 22, 18, 22));

        JPanel heading = new JPanel();
        heading.setOpaque(false);
        heading.setLayout(new BoxLayout(heading, BoxLayout.Y_AXIS));

        JLabel title = new JLabel("Thông tin học kỳ");
        title.setFont(Theme.FONT_H2);
        title.setForeground(Theme.TEXT);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel hint = new JLabel("Nhập đầy đủ thông tin bên dưới. Định dạng ngày: YYYY-MM-DD.");
        hint.setFont(Theme.FONT_BODY);
        hint.setForeground(Theme.TEXT_MUTED);
        hint.setAlignmentX(Component.LEFT_ALIGNMENT);

        heading.add(title);
        heading.add(Box.createVerticalStrut(4));
        heading.add(hint);
        card.add(heading, BorderLayout.NORTH);

        ma = field("VD: HK20261");
        hk = new RoundedCombo<>(new String[]{"1", "2", "3"});
        UiUtils.makeFlexible(hk, 150, 180, 40);
        nam = field("VD: 2026-2027");
        bd = field("VD: 2026-09-01");
        kt = field("VD: 2027-01-15");

        ResponsiveGridPanel fields = new ResponsiveGridPanel(5, 185, 12, 12);
        fields.add(group("Mã học kỳ", ma));
        fields.add(group("Học kỳ", hk));
        fields.add(group("Năm học", nam));
        fields.add(group("Ngày bắt đầu", bd));
        fields.add(group("Ngày kết thúc", kt));
        card.add(fields, BorderLayout.CENTER);

        JPanel actionSection = new JPanel(new BorderLayout(0, 7));
        actionSection.setOpaque(false);
        actionSection.setBorder(new EmptyBorder(2, 0, 0, 0));

        JLabel actionTitle = new JLabel("Thao tác");
        actionTitle.setFont(Theme.FONT_LABEL);
        actionTitle.setForeground(Theme.TEXT_SECONDARY);
        actionSection.add(actionTitle, BorderLayout.NORTH);

        JPanel buttons = new JPanel(new WrapLayout(FlowLayout.LEFT, 10, 0));
        buttons.setOpaque(false);

        RoundedButton add = actionButton("Thêm", "primary");
        add.addActionListener(e -> save(false));
        RoundedButton edit = actionButton("Cập nhật", "secondary");
        edit.addActionListener(e -> save(true));
        RoundedButton del = actionButton("Xóa", "danger");
        del.addActionListener(e -> delete());
        RoundedButton clear = actionButton("Làm mới", "warning");
        clear.addActionListener(e -> clear());

        buttons.add(add);
        buttons.add(edit);
        buttons.add(del);
        buttons.add(clear);
        actionSection.add(buttons, BorderLayout.CENTER);
        card.add(actionSection, BorderLayout.SOUTH);

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.add(card, BorderLayout.CENTER);
        return wrapper;
    }

    private RoundedField field(String placeholder) {
        RoundedField x = new RoundedField(14);
        x.setPlaceholder(placeholder);
        UiUtils.makeFlexible(x, 150, 190, 40);
        return x;
    }

    private RoundedButton actionButton(String text, String type) {
        RoundedButton b = new RoundedButton(text, type);
        b.setPreferredSize(new Dimension(128, 44));
        b.setMinimumSize(new Dimension(110, 44));
        return b;
    }

    private JPanel group(String text, JComponent component) {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false);

        JLabel label = new JLabel(text);
        label.setFont(Theme.FONT_LABEL);
        label.setForeground(Theme.TEXT_SECONDARY);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);

        component.setAlignmentX(Component.LEFT_ALIGNMENT);
        component.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));

        p.add(label);
        p.add(Box.createVerticalStrut(6));
        p.add(component);
        return p;
    }

    private JPanel createTableCard() {
        CardPanel card = new CardPanel(new BorderLayout(0, 10));
        card.setTopAccent(Theme.PRIMARY);
        card.setBorder(new EmptyBorder(16, 16, 16, 16));

        JPanel header = new JPanel(new BorderLayout(12, 0));
        header.setOpaque(false);

        JLabel title = new JLabel("Danh sách học kỳ");
        title.setFont(Theme.FONT_H2);
        title.setForeground(Theme.TEXT);
        header.add(title, BorderLayout.WEST);

        countLabel = new JLabel("0 học kỳ");
        countLabel.setFont(Theme.FONT_LABEL);
        countLabel.setForeground(Theme.TEXT_MUTED);
        header.add(countLabel, BorderLayout.EAST);
        card.add(header, BorderLayout.NORTH);

        model = new DefaultTableModel(
                new String[]{"Mã học kỳ", "Học kỳ", "Năm học", "Ngày bắt đầu", "Ngày kết thúc"}, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        table = new StyledTable();
        table.setModel(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setAutoCreateRowSorter(true);
        table.setRowHeight(Math.max(38, table.getRowHeight()));
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) fill();
        });

        TableColumnModel columns = table.getColumnModel();
        columns.getColumn(0).setPreferredWidth(150);
        columns.getColumn(1).setPreferredWidth(90);
        columns.getColumn(2).setPreferredWidth(160);
        columns.getColumn(3).setPreferredWidth(170);
        columns.getColumn(4).setPreferredWidth(170);

        JScrollPane scroll = new JScrollPane(table,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        UiUtils.tuneScrollPane(scroll);
        scroll.setBorder(BorderFactory.createEmptyBorder());
        card.add(scroll, BorderLayout.CENTER);

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setOpaque(false);
        wrapper.add(card, BorderLayout.CENTER);
        return wrapper;
    }

    public void refreshData() {
        load();
    }

    private void load() {
        if (model == null) return;
        try {
            model.setRowCount(0);
            for (HocKyNamHoc h : dao.getAll()) {
                model.addRow(new Object[]{
                        h.getMaHKNH(), h.getHocKy(), h.getNamHoc(),
                        h.getNgayBatDau(), h.getNgayKetThuc()
                });
            }
            if (countLabel != null) {
                countLabel.setText(model.getRowCount() + " học kỳ");
            }
        } catch (SQLException e) {
            err(e);
        }
    }

    private HocKyNamHoc data() {
        String m = ma.getText().trim().toUpperCase();
        String n = nam.getText().trim();
        String s = bd.getText().trim();
        String e = kt.getText().trim();

        if (m.isEmpty() || n.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mã học kỳ và năm học không được để trống.");
            return null;
        }
        if (!n.matches("\\d{4}-\\d{4}")) {
            JOptionPane.showMessageDialog(this, "Năm học phải có dạng 2026-2027.");
            return null;
        }
        if (!InputValidator.isValidDate(s) || !InputValidator.isValidDate(e)) {
            JOptionPane.showMessageDialog(this, "Ngày phải đúng định dạng YYYY-MM-DD.");
            return null;
        }
        if (!s.isEmpty() && !e.isEmpty()
                && java.time.LocalDate.parse(e).isBefore(java.time.LocalDate.parse(s))) {
            JOptionPane.showMessageDialog(this, "Ngày kết thúc phải sau hoặc bằng ngày bắt đầu.");
            return null;
        }

        HocKyNamHoc h = new HocKyNamHoc();
        h.setMaHKNH(m);
        h.setHocKy(Integer.parseInt(String.valueOf(hk.getSelectedItem())));
        h.setNamHoc(n);
        h.setNgayBatDau(s.isEmpty() ? null : s);
        h.setNgayKetThuc(e.isEmpty() ? null : e);
        return h;
    }

    private void save(boolean update) {
        HocKyNamHoc h = data();
        if (h == null) return;
        try {
            boolean ok = update ? dao.update(h) : dao.insert(h);
            if (ok) {
                JOptionPane.showMessageDialog(this,
                        update ? "Cập nhật học kỳ thành công." : "Thêm học kỳ thành công.");
                load();
                clear();
            }
        } catch (SQLException e) {
            err(e);
        }
    }

    private void delete() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) {
            JOptionPane.showMessageDialog(this, "Chọn học kỳ cần xóa.");
            return;
        }
        int row = table.convertRowIndexToModel(viewRow);
        String m = String.valueOf(model.getValueAt(row, 0));
        if (JOptionPane.showConfirmDialog(this,
                "Xóa học kỳ " + m + "?", "Xác nhận",
                JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            if (dao.delete(m)) {
                load();
                clear();
            }
        } catch (SQLException e) {
            err(e);
        }
    }

    private void fill() {
        int viewRow = table.getSelectedRow();
        if (viewRow < 0) return;
        int row = table.convertRowIndexToModel(viewRow);
        ma.setText(String.valueOf(model.getValueAt(row, 0)));
        hk.setSelectedItem(String.valueOf(model.getValueAt(row, 1)));
        nam.setText(String.valueOf(model.getValueAt(row, 2)));
        bd.setText(val(model.getValueAt(row, 3)));
        kt.setText(val(model.getValueAt(row, 4)));
    }

    private String val(Object o) {
        return o == null ? "" : o.toString();
    }

    private void clear() {
        ma.setText("");
        nam.setText("");
        bd.setText("");
        kt.setText("");
        hk.setSelectedIndex(0);
        table.clearSelection();
        ma.requestFocusInWindow();
    }

    private void err(Exception e) {
        JOptionPane.showMessageDialog(this, e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
    }
}
