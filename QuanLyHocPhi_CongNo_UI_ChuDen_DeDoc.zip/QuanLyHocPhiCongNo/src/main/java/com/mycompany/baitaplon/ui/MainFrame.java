package com.mycompany.baitaplon.ui;

import com.mycompany.baitaplon.util.DatabaseConnection;
import com.mycompany.baitaplon.util.UserSession;
import com.mycompany.baitaplon.dao.TaiKhoanDAO;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;

public class MainFrame extends JFrame {
    private JPanel contentPanel;
    private CardLayout cardLayout;
    private ThongKePanel thongKePanel;
    private SinhVienPanel sinhVienPanel;
    private SinhVienChiTietPanel sinhVienChiTietPanel;
    private HocPhanPanel hocPhanPanel;
    private DangKyHocPhanPanel dangKyHocPhanPanel;
    private HocKyPanel hocKyPanel;
    private HocPhiPanel hocPhiPanel;
    private CongNoPanel congNoPanel;
    private ThanhToanPanel thanhToanPanel;
    private BaoCaoPanel baoCaoPanel;
    private JPanel navPanel;
    private JLabel lblStatus;
    private int activeNavIdx = 0;

    private static final String CARD_DASHBOARD = "DASHBOARD";
    private static final String CARD_SINHVIEN = "SINHVIEN";
    private static final String CARD_SV_CHITIET = "SV_CHITIET";
    private static final String CARD_HOCPHAN = "HOCPHAN";
    private static final String CARD_DANGKY = "DANGKY";
    private static final String CARD_HOCKY = "HOCKY";
    private static final String CARD_HOCPHI = "HOCPHI";
    private static final String CARD_CONGNO = "CONGNO";
    private static final String CARD_THANHTOAN = "THANHTOAN";
    private static final String CARD_BAOCAO = "BAOCAO";

    public MainFrame() {
        super("");
        setUndecorated(true);
        setBackground(new Color(0, 0, 0, 0));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Rectangle usable = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
        int initialW = Math.min(1360, Math.max(1040, usable.width - 28));
        int initialH = Math.min(820, Math.max(650, usable.height - 28));
        setSize(initialW, initialH);
        setMinimumSize(new Dimension(Math.min(1040, usable.width), Math.min(650, usable.height)));
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int r = 20;
                g2.setColor(new Color(0, 0, 0, 60));
                g2.fill(new RoundRectangle2D.Float(4, 6, getWidth() - 8, getHeight() - 8, r, r));
                g2.setColor(new Color(0, 0, 0, 40));
                g2.fill(new RoundRectangle2D.Float(2, 3, getWidth() - 4, getHeight() - 4, r, r));
                g2.setColor(Theme.BG);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), r, r));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        root.setOpaque(false);
        root.setBorder(new EmptyBorder(0, 0, 0, 0));

        root.add(createTopBar(), BorderLayout.NORTH);
        root.add(createMainBody(), BorderLayout.CENTER);
        root.add(createStatusBar(), BorderLayout.SOUTH);

        setContentPane(root);
        FrameDragListener drag = new FrameDragListener(this);
        root.addMouseListener(drag);
        root.addMouseMotionListener(drag);
        applyRoleRestrictions();
    }

    private JPanel createTopBar() {
        JPanel p = new JPanel(new BorderLayout(12, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fillRect(0, 0, getWidth(), 64);
                g2.setColor(Theme.BORDER);
                g2.drawLine(0, 63, getWidth(), 63);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        p.setOpaque(false);
        p.setPreferredSize(new Dimension(0, 64));
        p.setBorder(new EmptyBorder(10, 18, 10, 14));

        // Khối logo được giữ gọn để phần tìm kiếm và tài khoản không lấn nhau.
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);
        left.setPreferredSize(new Dimension(250, 44));
        left.setMinimumSize(new Dimension(215, 44));

        JPanel logoBox = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, Theme.PRIMARY, getWidth(), getHeight(), Theme.SECONDARY);
                g2.setPaint(gp);
                g2.fill(new RoundRectangle2D.Float(0, 0, 44, 44, 12, 12));
                g2.setFont(Theme.FONT_ICON.deriveFont(22f));
                FontMetrics fm = g2.getFontMetrics();
                String ic = "🏛";
                int tw = fm.stringWidth(ic);
                g2.setColor(Color.WHITE);
                g2.drawString(ic, (44 - tw) / 2, (44 - fm.getHeight()) / 2 + fm.getAscent());
                g2.dispose();
            }
        };
        logoBox.setOpaque(false);
        logoBox.setPreferredSize(new Dimension(44, 44));

        JPanel titles = new JPanel();
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
        titles.setOpaque(false);
        JLabel t1 = new JLabel("BursarPortal");
        t1.setFont(Theme.FONT_H3);
        t1.setForeground(Theme.TEXT);
        JLabel t2 = new JLabel(UserSession.isSinhVien() ? "Cổng thông tin Sinh viên" : "Phòng Tài vụ · Quản lý tài chính");
        t2.setFont(Theme.FONT_SMALL);
        t2.setForeground(Theme.TEXT_MUTED);
        titles.add(Box.createVerticalStrut(2));
        titles.add(t1);
        titles.add(Box.createVerticalStrut(2));
        titles.add(t2);
        left.add(logoBox);
        left.add(titles);

        JPanel center = new JPanel(new BorderLayout());
        center.setOpaque(false);
        center.setBorder(new EmptyBorder(2, 6, 2, 6));
        if (!UserSession.isSinhVien()) {
            RoundedField searchField = new RoundedField(28);
            searchField.setPlaceholder("🔍  Tìm nhanh theo MSSV / họ tên...");
            searchField.setPreferredSize(new Dimension(280, 40));
            searchField.setMinimumSize(new Dimension(140, 40));
            searchField.addActionListener(e -> {
                String kw = searchField.getText().trim();
                if (!kw.isEmpty()) {
                    navigateTo(CARD_SINHVIEN, 1);
                    sinhVienPanel.searchFromGlobal(kw);
                }
            });
            center.add(searchField, BorderLayout.CENTER);
        }

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 3));
        right.setOpaque(false);

        JLabel userChip = new JLabel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Theme.SURFACE_ALT);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 20, 20));
                g2.setColor(Theme.BORDER);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, 20, 20));
                GradientPaint gp = new GradientPaint(8, 4, Theme.PRIMARY, 44, 36, Theme.SECONDARY);
                g2.setPaint(gp);
                g2.fillOval(8, 4, 32, 32);
                g2.setColor(Color.WHITE);
                g2.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD, 14f));
                FontMetrics fm = g2.getFontMetrics();
                String initials = UserSession.getHoTen();
                if (initials == null || initials.isBlank()) initials = "U";
                else {
                    String[] parts = initials.trim().split("\\s+");
                    initials = parts.length >= 2
                            ? parts[0].substring(0, 1) + parts[parts.length - 1].substring(0, 1)
                            : parts[0].substring(0, 1);
                }
                initials = initials.toUpperCase();
                int tw = fm.stringWidth(initials);
                g2.drawString(initials, 24 - tw / 2, 22 + fm.getAscent() / 2 - 4);

                String name = UserSession.getHoTen();
                String role = UserSession.get().getVaiTro().getTenHienThi();
                g2.setColor(Theme.TEXT);
                g2.setFont(Theme.FONT_LABEL);
                FontMetrics nfm = g2.getFontMetrics();
                g2.drawString(fitText(name, nfm, Math.max(45, getWidth() - 62)), 52, 20);
                g2.setColor(Theme.TEXT_MUTED);
                g2.setFont(Theme.FONT_SMALL);
                FontMetrics rfm = g2.getFontMetrics();
                g2.drawString(fitText(role, rfm, Math.max(45, getWidth() - 62)), 52, 36);
                g2.dispose();
            }
        };
        userChip.setPreferredSize(new Dimension(165, 40));
        userChip.setMinimumSize(new Dimension(135, 40));
        userChip.setToolTipText(UserSession.getHoTen() + " • " + UserSession.get().getVaiTro().getTenHienThi());

        RoundedButton btnChangePass = new RoundedButton("MK", Theme.mix(Theme.PRIMARY, Color.WHITE, 0.2), Theme.TEXT_ON_LIGHT, "outline");
        btnChangePass.setPreferredSize(new Dimension(42, 38));
        btnChangePass.setToolTipText("Đổi mật khẩu");
        btnChangePass.addActionListener(e -> doChangePassword());

        RoundedButton btnLogout = new RoundedButton("ĐX", Theme.mix(Theme.DANGER, Color.WHITE, 0.35), Theme.TEXT_ON_LIGHT, "outline");
        btnLogout.setPreferredSize(new Dimension(42, 38));
        btnLogout.setToolTipText("Đăng xuất");
        btnLogout.addActionListener(e -> doLogout());

        JButton bMin = makeWindowBtn("-", new Color(226, 232, 240));
        JButton bMax = makeWindowBtn("□", new Color(226, 232, 240));
        JButton bClose = makeWindowBtn("X", Theme.DANGER);
        bMin.setToolTipText("Thu nhỏ");
        bMax.setToolTipText("Phóng to / Khôi phục");
        bClose.setToolTipText("Đóng");
        bMin.addActionListener(e -> setState(JFrame.ICONIFIED));
        bMax.addActionListener(e -> {
            if ((getExtendedState() & MAXIMIZED_BOTH) == 0) setExtendedState(getExtendedState() | MAXIMIZED_BOTH);
            else setExtendedState(getExtendedState() & ~MAXIMIZED_BOTH);
        });
        bClose.addActionListener(e -> {
            if (JOptionPane.showConfirmDialog(this, "Xác nhận thoát khỏi hệ thống?", "Thoát", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE) == JOptionPane.YES_OPTION) {
                UserSession.clear();
                DatabaseConnection.closeConnection();
                System.exit(0);
            }
        });

        right.add(userChip);
        right.add(btnChangePass);
        right.add(btnLogout);
        right.add(Box.createHorizontalStrut(2));
        right.add(bMin);
        right.add(bMax);
        right.add(bClose);

        p.add(left, BorderLayout.WEST);
        p.add(center, BorderLayout.CENTER);
        p.add(right, BorderLayout.EAST);
        return p;
    }

    private static String fitText(String text, FontMetrics fm, int maxWidth) {
        if (text == null) return "";
        if (fm.stringWidth(text) <= maxWidth) return text;
        String dots = "…";
        int width = fm.stringWidth(dots);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < text.length(); i++) {
            int next = fm.charWidth(text.charAt(i));
            if (width + next > maxWidth) break;
            sb.append(text.charAt(i));
            width += next;
        }
        return sb.append(dots).toString();
    }

    private JButton makeWindowBtn(String s, Color bg) {
        JButton b = new JButton(s) {
            Color bgc = bg;
            boolean hov = false;

            {
                addMouseListener(new MouseAdapter() {
                    public void mouseEntered(MouseEvent e) {
                        hov = true;
                        repaint();
                    }

                    public void mouseExited(MouseEvent e) {
                        hov = false;
                        repaint();
                    }
                });
            }

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(hov ? (hov && bgc == Theme.DANGER ? Theme.DANGER : Theme.mix(bgc, Color.WHITE, 0.7)) : bgc);
                g2.fill(new RoundRectangle2D.Float(2, 2, 36, 30, 10, 10));
                g2.setColor(bgc == Theme.DANGER ? Color.WHITE : Theme.TEXT_SECONDARY);
                g2.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD));
                FontMetrics fm = g2.getFontMetrics();
                int tw = fm.stringWidth(s);
                g2.drawString(s, (getWidth() - tw) / 2, (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
                g2.dispose();
            }
        };
        b.setOpaque(false);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setPreferredSize(new Dimension(40, 34));
        return b;
    }

    private JPanel createMainBody() {
        JPanel body = new JPanel(new BorderLayout(0, 0));
        body.setOpaque(false);
        body.setBorder(new EmptyBorder(0, 0, 0, 0));

        body.add(createSidebar(), BorderLayout.WEST);
        body.add(createContentArea(), BorderLayout.CENTER);
        return body;
    }

    private JPanel createSidebar() {
        navPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Color.WHITE);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(Theme.BORDER);
                g2.drawLine(getWidth() - 1, 0, getWidth() - 1, getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        navPanel.setOpaque(false);
        navPanel.setPreferredSize(new Dimension(250, 0));
        navPanel.setMinimumSize(new Dimension(235, 0));
        navPanel.setLayout(new BoxLayout(navPanel, BoxLayout.Y_AXIS));
        navPanel.setBorder(new EmptyBorder(16, 12, 16, 12));

        String roleLabel = UserSession.isSinhVien() ? "SINH VIÊN" : "QUẢN TRỊ";
        JLabel lblGroup1 = new JLabel("  " + roleLabel);
        lblGroup1.setFont(Theme.FONT_SMALL.deriveFont(Font.BOLD));
        lblGroup1.setForeground(Theme.TEXT_MUTED);
        lblGroup1.setBorder(new EmptyBorder(6, 8, 8, 0));
        lblGroup1.setAlignmentX(Component.LEFT_ALIGNMENT);
        navPanel.add(lblGroup1);
        navPanel.add(Box.createVerticalStrut(2));

        String[][] adminItems = new String[][]{
                {"📊", "Tổng quan", CARD_DASHBOARD},
                {"👥", "Sinh viên", CARD_SINHVIEN},
                {"📚", "Học phần", CARD_HOCPHAN},
                {"🗓", "Học kỳ", CARD_HOCKY},
                {"📝", "Đăng ký học phần", CARD_DANGKY},
                {"💸", "Học phí", CARD_HOCPHI},
                {"💰", "Công nợ", CARD_CONGNO},
                {"💳", "Thanh toán & xác nhận", CARD_THANHTOAN},
                {"📈", "Báo cáo", CARD_BAOCAO},
        };
        String[][] svItems = new String[][]{
                {"🏠", "Tổng quan", CARD_DASHBOARD},
                {"📝", "Học phần đã đăng ký", CARD_DANGKY},
                {"💸", "Học phí của tôi", CARD_HOCPHI},
                {"💰", "Công nợ của tôi", CARD_CONGNO},
                {"💳", "Thanh toán học phí", CARD_THANHTOAN},
        };
        String[][] items = UserSession.isSinhVien() ? svItems : adminItems;

        int idx = 0;
        for (String[] item : items) {
            final int fidx = idx;
            final String fcard = item[2];
            NavItem btn = new NavItem(item[0], item[1], idx == 0);
            btn.setAlignmentX(Component.LEFT_ALIGNMENT);
            final int fidxFin = idx;
            btn.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    navigateTo(fcard, fidxFin);
                }
            });
            navPanel.add(btn);
            navPanel.add(Box.createVerticalStrut(4));
            idx++;
        }

        navPanel.add(Box.createVerticalGlue());

        NavItem logoutItem = new NavItem("🚪", "Đăng xuất", false) {
            @Override
            protected Color getAccent() {
                return Theme.DANGER;
            }
        };
        logoutItem.setAlignmentX(Component.LEFT_ALIGNMENT);
        logoutItem.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                doLogout();
            }
        });
        navPanel.add(logoutItem);
        navPanel.add(Box.createVerticalStrut(8));

        return navPanel;
    }

    private static class NavItem extends JPanel {
        private final String icon;
        private final String label;
        private boolean active;
        private boolean hover;

        public NavItem(String icon, String label, boolean active) {
            this.icon = icon;
            this.label = label;
            this.active = active;
            setOpaque(false);
            setPreferredSize(new Dimension(226, 44));
            setMinimumSize(new Dimension(211, 44));
            setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
            setToolTipText(label);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    hover = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    hover = false;
                    repaint();
                }
            });
        }

        protected Color getAccent() {
            return Theme.PRIMARY;
        }

        public void setActive(boolean a) {
            this.active = a;
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (active) {
                GradientPaint gp = new GradientPaint(0, 0, Theme.mix(getAccent(), Color.WHITE, 0.15), getWidth(), 0, Theme.mix(getAccent(), Color.WHITE, 0.28));
                g2.setPaint(gp);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                g2.setColor(getAccent());
                g2.fillRect(0, 8, 4, getHeight() - 16);
            } else if (hover) {
                g2.setColor(Theme.SURFACE_ALT);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
            }
            g2.setFont(Theme.FONT_ICON.deriveFont(18f));
            FontMetrics fmi = g2.getFontMetrics();
            int twi = fmi.stringWidth(icon);
            Color c = active ? getAccent() : (hover ? Theme.TEXT_SECONDARY : Theme.TEXT_MUTED);
            g2.setColor(c);
            g2.drawString(icon, 20 - twi / 2, (getHeight() - fmi.getHeight()) / 2 + fmi.getAscent());
            g2.setFont(Theme.FONT_BODY.deriveFont(active ? Font.BOLD : Font.PLAIN));
            g2.setColor(active ? Theme.TEXT : (hover ? Theme.TEXT_SECONDARY : Theme.TEXT_MUTED));
            FontMetrics fmt = g2.getFontMetrics();
            String shownLabel = fitText(label, fmt, Math.max(40, getWidth() - 58));
            g2.drawString(shownLabel, 48, (getHeight() - fmt.getHeight()) / 2 + fmt.getAscent());
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private JPanel createContentArea() {
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.setBorder(new EmptyBorder(16, 20, 0, 20));

        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setOpaque(false);

        thongKePanel = new ThongKePanel();
        sinhVienPanel = new SinhVienPanel();
        sinhVienChiTietPanel = new SinhVienChiTietPanel();
        hocPhanPanel = new HocPhanPanel();
        dangKyHocPhanPanel = new DangKyHocPhanPanel();
        hocKyPanel = new HocKyPanel();
        hocPhiPanel = new HocPhiPanel();
        congNoPanel = new CongNoPanel();
        thanhToanPanel = new ThanhToanPanel();
        baoCaoPanel = new BaoCaoPanel();

        thongKePanel.setOnShowAllRecent(() -> {
            int ttIdx = UserSession.isSinhVien() ? 4 : 7;
            navigateTo(CARD_THANHTOAN, ttIdx);
        });
        thongKePanel.setOnShowPaymentHistory(() -> {
            int ttIdx = UserSession.isSinhVien() ? 4 : 7;
            navigateTo(CARD_THANHTOAN, ttIdx);
        });

        sinhVienPanel.setDetailOpener(maSV -> {
            sinhVienChiTietPanel.loadForStudent(maSV);
            cardLayout.show(contentPanel, CARD_SV_CHITIET);
        });
        sinhVienChiTietPanel.setBackListener(() -> cardLayout.show(contentPanel, CARD_SINHVIEN));

        contentPanel.add(UiUtils.pageScroll(thongKePanel), CARD_DASHBOARD);
        contentPanel.add(UiUtils.pageScroll(sinhVienPanel), CARD_SINHVIEN);
        contentPanel.add(UiUtils.pageScroll(sinhVienChiTietPanel), CARD_SV_CHITIET);
        contentPanel.add(UiUtils.pageScroll(hocPhanPanel), CARD_HOCPHAN);
        contentPanel.add(UiUtils.pageScroll(dangKyHocPhanPanel), CARD_DANGKY);
        contentPanel.add(UiUtils.pageScroll(hocKyPanel), CARD_HOCKY);
        contentPanel.add(UiUtils.pageScroll(hocPhiPanel), CARD_HOCPHI);
        contentPanel.add(UiUtils.pageScroll(congNoPanel), CARD_CONGNO);
        // Thanh toán có tab + bảng tự cuộn riêng. Không bọc thêm pageScroll để tránh nút hành động bị đẩy ra ngoài màn hình.
        contentPanel.add(thanhToanPanel, CARD_THANHTOAN);
        contentPanel.add(UiUtils.pageScroll(baoCaoPanel), CARD_BAOCAO);

        wrap.add(contentPanel, BorderLayout.CENTER);
        return wrap;
    }

    private void navigateTo(String card, int idx) {
        activeNavIdx = idx;
        for (int i = 0; i < navPanel.getComponentCount(); i++) {
            Component c = navPanel.getComponent(i);
            if (c instanceof NavItem) ((NavItem) c).setActive(false);
        }
        int count = 0;
        for (int i = 0; i < navPanel.getComponentCount(); i++) {
            Component c = navPanel.getComponent(i);
            if (c instanceof NavItem && count < (UserSession.isSinhVien() ? 5 : 9)) {
                if (count == idx) ((NavItem) c).setActive(true);
                count++;
            } else if (c instanceof NavItem) {
                count++;
            }
        }
        cardLayout.show(contentPanel, card);
        if (CARD_DASHBOARD.equals(card)) thongKePanel.refreshData();
        if (CARD_DANGKY.equals(card)) dangKyHocPhanPanel.refreshData();
        if (CARD_HOCKY.equals(card)) hocKyPanel.refreshData();
        if (CARD_HOCPHI.equals(card)) hocPhiPanel.refreshData();
        if (CARD_CONGNO.equals(card)) congNoPanel.refreshData();
        if (CARD_THANHTOAN.equals(card)) thanhToanPanel.refreshData();
        if (CARD_BAOCAO.equals(card)) baoCaoPanel.refreshData();
    }

    private void applyRoleRestrictions() {
        thongKePanel.configureForRole();
        dangKyHocPhanPanel.configureForRole();
        hocPhiPanel.configureForRole();
        congNoPanel.configureForRole();
        thanhToanPanel.configureForRole();
        sinhVienPanel.configureForRole();
        sinhVienChiTietPanel.configureForRole();
    }


    private void doChangePassword() {
        JPasswordField oldPass = new JPasswordField(18);
        JPasswordField newPass = new JPasswordField(18);
        JPasswordField confirm = new JPasswordField(18);
        JPanel p = new JPanel(new GridLayout(0, 1, 4, 4));
        p.add(new JLabel("Mật khẩu hiện tại:")); p.add(oldPass);
        p.add(new JLabel("Mật khẩu mới (ít nhất 6 ký tự):")); p.add(newPass);
        p.add(new JLabel("Nhập lại mật khẩu mới:")); p.add(confirm);
        int result = JOptionPane.showConfirmDialog(this, p, "Đổi mật khẩu", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) return;
        String oldValue = new String(oldPass.getPassword());
        String newValue = new String(newPass.getPassword());
        String confirmValue = new String(confirm.getPassword());
        if (newValue.length() < 6) { JOptionPane.showMessageDialog(this, "Mật khẩu mới phải có ít nhất 6 ký tự."); return; }
        if (!newValue.equals(confirmValue)) { JOptionPane.showMessageDialog(this, "Mật khẩu nhập lại không khớp."); return; }
        try {
            boolean ok = new TaiKhoanDAO().changePassword(UserSession.get().getTenDangNhap(), oldValue, newValue);
            if (ok) JOptionPane.showMessageDialog(this, "✅ Đổi mật khẩu thành công.");
            else JOptionPane.showMessageDialog(this, "Mật khẩu hiện tại không đúng.", "Không thể đổi mật khẩu", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void doLogout() {
        if (JOptionPane.showConfirmDialog(this, "Bạn có muốn đăng xuất?", "Đăng xuất", JOptionPane.YES_NO_OPTION) != JOptionPane.YES_OPTION) {
            return;
        }
        UserSession.clear();
        DatabaseConnection.closeConnection();
        dispose();
        LoginDialog login = new LoginDialog(null);
        login.setVisible(true);
        if (login.isAuthenticated()) {
            MainFrame frame = new MainFrame();
            frame.setVisible(true);
        } else {
            System.exit(0);
        }
    }

    private JPanel createStatusBar() {
        JPanel p = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(Theme.SURFACE);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(Theme.BORDER);
                g2.drawLine(0, 0, getWidth(), 0);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(8, 24, 8, 24));
        p.setPreferredSize(new Dimension(0, 36));

        lblStatus = new JLabel(buildStatusText());
        lblStatus.setFont(Theme.FONT_SMALL);
        lblStatus.setForeground(Theme.TEXT_MUTED);
        JLabel time = new JLabel("📅 " + java.time.LocalDate.now() + "    🕒 " + java.time.LocalTime.now().withNano(0).toString());
        time.setFont(Theme.FONT_SMALL);
        time.setForeground(Theme.TEXT_MUTED);

        lblStatus.setToolTipText(buildStatusText());
        time.setHorizontalAlignment(SwingConstants.RIGHT);
        JPanel statusGrid = new JPanel(new GridLayout(1, 2, 12, 0));
        statusGrid.setOpaque(false);
        statusGrid.add(lblStatus);
        statusGrid.add(time);
        p.add(statusGrid, BorderLayout.CENTER);
        return p;
    }

    private String buildStatusText() {
        String role = UserSession.get().getVaiTro().getTenHienThi();
        return "● Sẵn sàng   •   👤 " + UserSession.getHoTen() + " (" + role + ")";
    }

    public static class FrameDragListener extends MouseAdapter {
        private final JFrame frame;
        private Point mouseDown = null;

        public FrameDragListener(JFrame f) {
            frame = f;
        }

        public void mousePressed(MouseEvent e) {
            mouseDown = e.getPoint();
        }

        public void mouseReleased(MouseEvent e) {
            mouseDown = null;
        }

        public void mouseDragged(MouseEvent e) {
            if (mouseDown != null) {
                Point cp = e.getLocationOnScreen();
                frame.setLocation(cp.x - mouseDown.x, cp.y - mouseDown.y);
            }
        }
    }
}
