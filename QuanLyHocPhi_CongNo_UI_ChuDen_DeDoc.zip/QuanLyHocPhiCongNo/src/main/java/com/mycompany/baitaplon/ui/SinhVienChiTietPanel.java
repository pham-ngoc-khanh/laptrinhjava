package com.mycompany.baitaplon.ui;

import com.mycompany.baitaplon.dao.*;
import com.mycompany.baitaplon.model.*;
import com.mycompany.baitaplon.util.UserSession;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class SinhVienChiTietPanel extends JPanel {
    private SinhVienDAO svDAO = new SinhVienDAO();
    private HocPhiDAO hocPhiDAO = new HocPhiDAO();
    private CongNoDAO congNoDAO = new CongNoDAO();
    private ThanhToanDAO thanhToanDAO = new ThanhToanDAO();
    private HocKyNamHocDAO hkDAO = new HocKyNamHocDAO();
    private LopDAO lopDAO = new LopDAO();
    private SinhVien currentSV;
    private Runnable backListener;
    private RoundedButton bLapHoaDon, bNhanTT;

    private JLabel lblHoTen, lblMSSV, lblLop, lblNganh, lblKhoaHoc, lblNgaySinh, lblEmail, lblSDT;
    private JLabel lblTongHP, lblDaThu, lblConLai, lblTrangThai;
    private DefaultTableModel modelPhi, modelGD;
    private StyledTable tblPhi, tblGD;
    private RoundedCombo<String> cboHKNH;

    public SinhVienChiTietPanel() {
        super(new BorderLayout(16, 16));
        setOpaque(false);
        setBorder(new EmptyBorder(6, 6, 16, 6));
        add(createHeader(), BorderLayout.NORTH);
        add(createBody(), BorderLayout.CENTER);
    }

    public void setBackListener(Runnable r) {
        this.backListener = r;
    }

    public void configureForRole() {
        if (UserSession.isSinhVien()) {
            if (bLapHoaDon != null) bLapHoaDon.setVisible(false);
            if (bNhanTT != null) bNhanTT.setVisible(false);
        }
    }

    private JPanel createHeader() {
        JPanel p = new JPanel(new BorderLayout(16, 0));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(0, 4, 8, 4));

        RoundedButton backBtn = new RoundedButton("← Quay lại Danh sách", Theme.mix(Theme.PRIMARY, Color.WHITE, 0.85), Theme.TEXT_ON_LIGHT, "outline");
        backBtn.setPreferredSize(new Dimension(200, 40));
        backBtn.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD));
        backBtn.addActionListener(e -> { if (backListener != null) backListener.run(); });

        JPanel titlePanel = new JPanel();
        titlePanel.setLayout(new BoxLayout(titlePanel, BoxLayout.Y_AXIS));
        titlePanel.setOpaque(false);
        JLabel t1 = new JLabel("📋 Chi tiết Học phí Sinh viên");
        t1.setFont(Theme.FONT_H2.deriveFont(Font.BOLD, 22f));
        t1.setForeground(Theme.TEXT);
        t1.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel t2 = new JLabel("Xem thông tin, các khoản phí và lịch sử giao dịch của 1 sinh viên");
        t2.setFont(Theme.FONT_BODY);
        t2.setForeground(Theme.TEXT_MUTED);
        t2.setAlignmentX(Component.LEFT_ALIGNMENT);
        titlePanel.add(t1);
        titlePanel.add(Box.createVerticalStrut(2));
        titlePanel.add(t2);

        p.add(backBtn, BorderLayout.WEST);
        p.add(titlePanel, BorderLayout.CENTER);
        return p;
    }

    private JComponent createBody() {
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        split.setOpaque(false);
        split.setBorder(BorderFactory.createEmptyBorder());
        split.setDividerSize(4);
        split.setResizeWeight(0.28);
        split.setBackground(Theme.BG);
        JPanel info = createInfoCard();
        JPanel right = createRightSide();
        info.setMinimumSize(new Dimension(285, 420));
        right.setMinimumSize(new Dimension(430, 420));
        split.setLeftComponent(info);
        split.setRightComponent(right);
        return split;
    }

    private JPanel createInfoCard() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(20, 20, 20, 20));
        card.setTopAccent(Theme.PRIMARY);

        JPanel header = new JPanel(new BorderLayout(0, 10));
        header.setOpaque(false);

        JPanel avatar = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, Theme.PRIMARY, getWidth(), getHeight(), Theme.SECONDARY);
                g2.setPaint(gp);
                g2.fillOval(0, 0, 110, 110);
                g2.setColor(new Color(255, 255, 255, 180));
                g2.drawOval(2, 2, 106, 106);
                String initials = "";
                if (currentSV != null && currentSV.getHoTen() != null && !currentSV.getHoTen().isEmpty()) {
                    String[] parts = currentSV.getHoTen().trim().split("\\s+");
                    if (parts.length >= 2) initials = parts[0].substring(0, 1) + parts[parts.length - 1].substring(0, 1);
                    else initials = parts[0].substring(0, 1);
                    initials = initials.toUpperCase();
                } else initials = "SV";
                g2.setFont(Theme.FONT_H2.deriveFont(Font.BOLD, 36f));
                FontMetrics fm = g2.getFontMetrics();
                int tw = fm.stringWidth(initials);
                g2.setColor(Color.WHITE);
                g2.drawString(initials, (110 - tw) / 2, (110 - fm.getHeight()) / 2 + fm.getAscent());
                g2.dispose();
            }
        };
        avatar.setOpaque(false);
        avatar.setPreferredSize(new Dimension(110, 110));

        JPanel names = new JPanel();
        names.setLayout(new BoxLayout(names, BoxLayout.Y_AXIS));
        names.setOpaque(false);
        lblHoTen = new JLabel("—");
        lblHoTen.setFont(Theme.FONT_H2.deriveFont(Font.BOLD, 18f));
        lblHoTen.setForeground(Theme.TEXT);
        lblHoTen.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel studentBadge = new JLabel("🎓 THẺ SINH VIÊN ĐIỆN TỬ") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, Theme.mix(Theme.PRIMARY, Color.WHITE, 0.2), getWidth(), 0, Theme.mix(Theme.SECONDARY, Color.WHITE, 0.2));
                g2.setPaint(gp);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 8, 8));
                g2.setFont(Theme.FONT_SMALL.deriveFont(Font.BOLD));
                g2.setColor(Theme.PRIMARY_DARK);
                FontMetrics fm = g2.getFontMetrics();
                String badgeText = getText();
                while (fm.stringWidth(badgeText) > Math.max(20, getWidth() - 20) && badgeText.length() > 2) badgeText = badgeText.substring(0, badgeText.length()-2) + "…";
                g2.drawString(badgeText, 10, (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
                g2.dispose();
            }
        };
        studentBadge.setText("🎓 THẺ SINH VIÊN ĐIỆN TỬ");
        studentBadge.setPreferredSize(new Dimension(180, 24));
        studentBadge.setAlignmentX(Component.LEFT_ALIGNMENT);
        names.add(studentBadge);
        names.add(Box.createVerticalStrut(8));
        names.add(lblHoTen);

        JPanel topRow = new JPanel(new BorderLayout(12, 0));
        topRow.setOpaque(false);
        topRow.add(avatar, BorderLayout.WEST);
        topRow.add(names, BorderLayout.CENTER);
        header.add(topRow, BorderLayout.NORTH);

        JPanel infoGrid = new JPanel(new GridBagLayout());
        infoGrid.setOpaque(false);
        infoGrid.setBorder(new EmptyBorder(16, 0, 0, 0));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 0, 6, 10);
        gbc.anchor = GridBagConstraints.WEST;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        String[][] fields = new String[][]{
                {"🆔 MSSV:", "lblMSSV"},
                {"🏫 Lớp:", "lblLop"},
                {"📘 Ngành:", "lblNganh"},
                {"🎓 Khóa học:", "lblKhoaHoc"},
                {"🎂 Ngày sinh:", "lblNgaySinh"},
                {"📧 Email:", "lblEmail"},
                {"📞 SĐT:", "lblSDT"},
        };
        JLabel[] labels = {lblMSSV = new JLabel("—"), lblLop = new JLabel("—"), lblNganh = new JLabel("—"),
                lblKhoaHoc = new JLabel("—"), lblNgaySinh = new JLabel("—"), lblEmail = new JLabel("—"), lblSDT = new JLabel("—")};
        for (int i = 0; i < fields.length; i++) {
            gbc.gridx = 0; gbc.gridy = i; gbc.weightx = 0;
            JLabel l = new JLabel(fields[i][0]);
            l.setFont(Theme.FONT_LABEL);
            l.setForeground(Theme.TEXT_MUTED);
            infoGrid.add(l, gbc);
            gbc.gridx = 1; gbc.weightx = 1;
            labels[i].setFont(Theme.FONT_BODY.deriveFont(Font.BOLD));
            labels[i].setForeground(Theme.TEXT);
            labels[i].setToolTipText(labels[i].getText());
            infoGrid.add(labels[i], gbc);
        }
        header.add(infoGrid, BorderLayout.CENTER);

        JPanel quickStats = new JPanel(new GridLayout(3, 1, 0, 8));
        quickStats.setOpaque(false);
        quickStats.setBorder(new EmptyBorder(16, 0, 0, 0));
        quickStats.add(statMiniRow("💸 Tổng học phí:", lblTongHP = new JLabel("0 VND"), Theme.WARNING));
        quickStats.add(statMiniRow("✅ Đã thu:", lblDaThu = new JLabel("0 VND"), Theme.SUCCESS));
        quickStats.add(statMiniRow("⚠ Còn lại:", lblConLai = new JLabel("0 VND"), Theme.DANGER));
        header.add(quickStats, BorderLayout.SOUTH);

        card.add(header, BorderLayout.CENTER);

        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        footer.setBorder(new EmptyBorder(14, 0, 0, 0));
        lblTrangThai = new JLabel("● Trạng thái: —") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Theme.SURFACE_ALT);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
                g2.setFont(getFont());
                FontMetrics fm = g2.getFontMetrics();
                String text = getText();
                Color dot = Theme.TEXT_MUTED;
                Color textColor = Theme.TEXT_SECONDARY;
                if (text.contains("Đã nộp đủ")) { dot = Theme.SUCCESS; textColor = Theme.SUCCESS; }
                else if (text.contains("Đang nợ")) { dot = Theme.WARNING; textColor = Theme.WARNING; }
                else if (text.contains("Chưa nộp")) { dot = Theme.DANGER; textColor = Theme.DANGER; }
                g2.setColor(dot);
                g2.fillOval(14, (getHeight() - 10) / 2, 10, 10);
                g2.setColor(textColor);
                String shown = text;
                while (fm.stringWidth(shown) > Math.max(20, getWidth() - 48) && shown.length() > 2) shown = shown.substring(0, shown.length()-2) + "…";
                g2.drawString(shown, 34, (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
                g2.dispose();
            }
        };
        lblTrangThai.setPreferredSize(new Dimension(0, 42));
        lblTrangThai.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD));
        footer.add(lblTrangThai, BorderLayout.CENTER);
        card.add(footer, BorderLayout.SOUTH);

        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.add(card, BorderLayout.CENTER);
        return wrap;
    }

    private JPanel statMiniRow(String name, JLabel value, Color accent) {
        JPanel p = new JPanel(new BorderLayout(0, 0)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(Theme.SURFACE_ALT);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 10, 10));
                g2.setColor(Theme.BORDER);
                g2.draw(new RoundRectangle2D.Float(0.5f, 0.5f, getWidth() - 1, getHeight() - 1, 10, 10));
                g2.setColor(accent);
                g2.fillRect(0, 0, 4, getHeight());
                g2.dispose();
            }
        };
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(10, 16, 10, 16));
        JLabel l = new JLabel(name);
        l.setFont(Theme.FONT_LABEL);
        l.setForeground(Theme.TEXT_SECONDARY);
        value.setFont(Theme.FONT_H3);
        value.setForeground(accent);
        p.add(l, BorderLayout.WEST);
        p.add(value, BorderLayout.EAST);
        return p;
    }

    private JPanel createRightSide() {
        JPanel p = new JPanel(new BorderLayout(14, 14));
        p.setOpaque(false);
        p.add(createToolbar(), BorderLayout.NORTH);
        p.add(createTabbedArea(), BorderLayout.CENTER);
        return p;
    }

    private JPanel createToolbar() {
        JPanel p = new JPanel(new WrapLayout(FlowLayout.LEFT, 10, 8));
        p.setOpaque(false);

        JPanel left = new JPanel(new WrapLayout(FlowLayout.LEFT, 8, 2));
        left.setOpaque(false);
        JLabel l = new JLabel("📅 Học kỳ:");
        l.setFont(Theme.FONT_LABEL);
        l.setForeground(Theme.TEXT_SECONDARY);
        cboHKNH = new RoundedCombo<>();
        UiUtils.makeFlexible(cboHKNH, 170, 230, 36);
        cboHKNH.addActionListener(e -> refreshDataForCurrentSV());
        RoundedButton bAll = new RoundedButton("Tất cả học kỳ", Theme.mix(Theme.INFO, Color.WHITE, 0.88), Theme.TEXT_ON_LIGHT, "outline");
        bAll.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD));
        bAll.addActionListener(e -> {
            cboHKNH.setSelectedIndex(0);
            refreshDataForCurrentSV();
        });
        left.add(l); left.add(cboHKNH); left.add(bAll);

        JPanel right = new JPanel(new WrapLayout(FlowLayout.LEFT, 8, 2));
        right.setOpaque(false);
        bLapHoaDon = new RoundedButton("Lập hóa đơn", "warning");
        bLapHoaDon.addActionListener(e -> lapHoaDon());
        bNhanTT = new RoundedButton("Nhận thanh toán", "success");
        bNhanTT.addActionListener(e -> nhanThanhToanNhanh());
        right.add(bLapHoaDon); right.add(bNhanTT);

        p.add(left); p.add(right);
        return p;
    }

    private JComponent createTabbedArea() {
        StyledTabbedPane tabs = new StyledTabbedPane();
        JPanel p1 = new JPanel(new BorderLayout(0, 12));
        p1.setOpaque(false);
        p1.setBorder(new EmptyBorder(8, 8, 8, 8));
        CardPanel cardPhi = new CardPanel(new BorderLayout());
        cardPhi.setTopAccent(Theme.WARNING);
        cardPhi.setBorder(new EmptyBorder(12, 12, 12, 12));
        String[] cols = {"#", "Khoản phí", "Học kỳ", "Hạn chót", "Số tiền (VND)", "Đã thanh toán", "Trạng thái"};
        modelPhi = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblPhi = new StyledTable();
        tblPhi.setModel(modelPhi);
        tblPhi.getColumnModel().getColumn(0).setPreferredWidth(40);
        tblPhi.getColumnModel().getColumn(1).setPreferredWidth(220);
        tblPhi.getColumnModel().getColumn(2).setPreferredWidth(130);
        tblPhi.getColumnModel().getColumn(3).setPreferredWidth(120);
        tblPhi.getColumnModel().getColumn(4).setPreferredWidth(150);
        tblPhi.getColumnModel().getColumn(5).setPreferredWidth(150);
        tblPhi.getColumnModel().getColumn(6).setPreferredWidth(120);
        tblPhi.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean isSel, boolean hasFocus, int row, int col) {
                JLabel c = (JLabel) super.getTableCellRendererComponent(t, v, isSel, hasFocus, row, col);
                c.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
                if (!isSel) c.setBackground(row % 2 == 0 ? Color.WHITE : Theme.SURFACE_ALT);
                if (col == 6 && v != null) {
                    String s = v.toString();
                    if (s.contains("Đã") || s.contains("xong")) { c.setForeground(Theme.SUCCESS); c.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD)); }
                    else if (s.contains("đang") || s.contains("trong")) { c.setForeground(Theme.WARNING); c.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD)); }
                    else { c.setForeground(Theme.DANGER); c.setFont(Theme.FONT_BODY.deriveFont(Font.BOLD)); }
                }
                return c;
            }
        });
        JScrollPane sp1 = new JScrollPane(tblPhi);
        sp1.setOpaque(false); sp1.getViewport().setOpaque(false);
        sp1.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        UiUtils.tuneScrollPane(sp1);
        cardPhi.add(sp1, BorderLayout.CENTER);
        p1.add(cardPhi, BorderLayout.CENTER);

        JPanel p2 = new JPanel(new BorderLayout(0, 12));
        p2.setOpaque(false);
        p2.setBorder(new EmptyBorder(8, 8, 8, 8));
        CardPanel cardGD = new CardPanel(new BorderLayout());
        cardGD.setTopAccent(Theme.SECONDARY);
        cardGD.setBorder(new EmptyBorder(12, 12, 12, 12));
        String[] cols2 = {"Ngày GD", "Mã GD", "Loại", "Kỳ", "Hình thức", "Số tiền (VND)", "Người thu", "Ghi chú"};
        modelGD = new DefaultTableModel(cols2, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        tblGD = new StyledTable();
        tblGD.setModel(modelGD);
        tblGD.getColumnModel().getColumn(0).setPreferredWidth(100);
        tblGD.getColumnModel().getColumn(1).setPreferredWidth(120);
        tblGD.getColumnModel().getColumn(2).setPreferredWidth(100);
        tblGD.getColumnModel().getColumn(3).setPreferredWidth(110);
        tblGD.getColumnModel().getColumn(4).setPreferredWidth(120);
        tblGD.getColumnModel().getColumn(5).setPreferredWidth(140);
        tblGD.getColumnModel().getColumn(6).setPreferredWidth(140);
        tblGD.getColumnModel().getColumn(7).setPreferredWidth(200);
        JScrollPane sp2 = new JScrollPane(tblGD);
        sp2.setOpaque(false); sp2.getViewport().setOpaque(false);
        sp2.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        UiUtils.tuneScrollPane(sp2);
        cardGD.add(sp2, BorderLayout.CENTER);
        p2.add(cardGD, BorderLayout.CENTER);

        tabs.addTab("📋 Chi tiết các khoản phí", p1);
        tabs.addTab("🧾 Lịch Sử Giao Dịch", p2);
        return tabs;
    }

    public void loadForStudent(String maSV) {
        try {
            loadHKCombo();
            currentSV = svDAO.getById(maSV);
            if (currentSV == null) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy sinh viên " + maSV);
                return;
            }
            lblHoTen.setText(currentSV.getHoTen());
            lblMSSV.setText(currentSV.getMaSV());
            lblLop.setText(str(currentSV.getTenLop()));
            String tenNganh = "—";
            String khoaHocStr = "—";
            try {
                if (currentSV.getMaLop() != null) {
                    Lop lop = lopDAO.getById(currentSV.getMaLop());
                    if (lop != null) {
                        if (lop.getKhoaHoc() > 0) khoaHocStr = "Khóa " + lop.getKhoaHoc();
                        if (lop.getMaNganh() != null) {
                            tenNganh = lookupTenNganh(lop.getMaNganh());
                        }
                    }
                }
            } catch (Exception ignored) {}
            lblNganh.setText(tenNganh);
            lblKhoaHoc.setText(khoaHocStr);
            lblNgaySinh.setText(str(currentSV.getNgaySinh()));
            lblEmail.setText(str(currentSV.getEmail()));
            lblSDT.setText(str(currentSV.getSdt()));
            refreshDataForCurrentSV();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private String lookupTenNganh(String maNganh) {
        if (maNganh == null) return "—";
        try (java.sql.Connection c = com.mycompany.baitaplon.util.DatabaseConnection.getConnection();
             java.sql.PreparedStatement ps = c.prepareStatement("SELECT TenNganh FROM Nganh WHERE MaNganh = ?")) {
            ps.setString(1, maNganh);
            try (java.sql.ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String t = rs.getString(1);
                    return t != null && !t.isEmpty() ? t : maNganh;
                }
            }
        } catch (Exception ignored) {}
        return maNganh;
    }

    private void loadHKCombo() {
        try {
            List<HocKyNamHoc> ds = hkDAO.getAll();
            cboHKNH.removeAllItems();
            cboHKNH.addItem("Tất cả học kỳ");
            for (HocKyNamHoc hk : ds) cboHKNH.addItem(hk.getMaHKNH() + " - HK " + hk.getHocKy() + " " + hk.getNamHoc());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private String getSelectedHKMa() {
        if (cboHKNH.getSelectedIndex() <= 0) return null;
        return cboHKNH.getSelectedItem().toString().split(" - ")[0];
    }

    private void refreshDataForCurrentSV() {
        if (currentSV == null) return;
        String maSV = currentSV.getMaSV();
        String maHK = getSelectedHKMa();
        try {
            List<HocPhi> dsHP = hocPhiDAO.getByMaSV(maSV);
            List<CongNo> dsCN = congNoDAO.getByMaSV(maSV);
            List<ThanhToan> dsTT = thanhToanDAO.getByMaSV(maSV);
            if (maHK != null) {
                final String f = maHK;
                dsHP.removeIf(h -> !f.equals(h.getMaHKNH()));
                dsCN.removeIf(c -> !f.equals(c.getMaHKNH()));
                dsTT.removeIf(t -> !f.equals(t.getMaHKNH()));
            }

            modelPhi.setRowCount(0);
            int row = 1;
            for (HocPhi hp : dsHP) {
                String trangThai = "Chưa đóng";
                BigDecimal conLai = hp.getPhaiThu() == null ? BigDecimal.ZERO : hp.getPhaiThu();
                for (CongNo cn : dsCN) if (cn.getMaHKNH().equals(hp.getMaHKNH())) { conLai = cn.getConLai(); trangThai = cn.getTrangThai(); break; }
                modelPhi.addRow(new Object[]{
                        row++, "Học phí tín chỉ (" + hp.getTongTinChi() + " TC)", hp.getTenHKNH(),
                        hp.getNgayTinh(), hp.getTongHocPhi(),
                        hp.getTongHocPhi() != null && conLai != null ? hp.getTongHocPhi().subtract(conLai) : hp.getTongHocPhi(),
                        trangThai
                });
            }
            if (dsHP.isEmpty()) {
                for (CongNo cn : dsCN) {
                    modelPhi.addRow(new Object[]{
                            row++, "Công nợ kỳ " + cn.getTenHKNH(), cn.getTenHKNH(),
                            cn.getNgayCapNhat(), cn.getSoTienNo(), cn.getSoTienDaThu(), cn.getTrangThai()
                    });
                }
            }

            modelGD.setRowCount(0);
            for (ThanhToan tt : dsTT) {
                modelGD.addRow(new Object[]{
                        tt.getNgayThanhToan(), "GD-" + tt.getMaThanhToan(), "THANH TOÁN",
                        tt.getTenHKNH(), tt.getHinhThucThanhToan(),
                        "+" + String.format("%,.0f", tt.getSoTien()),
                        str(tt.getNguoiThu()), str(tt.getGhiChu())
                });
            }
            for (HocPhi hp : dsHP) {
                modelGD.insertRow(0, new Object[]{
                        hp.getNgayTinh(), "SYS-HP-" + hp.getMaHPPhi(), "GHI NỢ",
                        hp.getTenHKNH(), "Hệ thống",
                        "-" + String.format("%,.0f", hp.getPhaiThu()),
                        "Hệ thống", "Tính học phí kỳ " + hp.getTenHKNH()
                });
            }

            BigDecimal tongHP = BigDecimal.ZERO, tongDaThu = BigDecimal.ZERO, tongConLai = BigDecimal.ZERO;
            String ttFinal = "Đã nộp đủ";
            boolean hasNo = false, hasPart = false;
            for (CongNo cn : dsCN) {
                if (cn.getSoTienNo() != null) tongHP = tongHP.add(cn.getSoTienNo());
                if (cn.getSoTienDaThu() != null) tongDaThu = tongDaThu.add(cn.getSoTienDaThu());
                if (cn.getConLai() != null) tongConLai = tongConLai.add(cn.getConLai());
                if ("Chưa nộp".equals(cn.getTrangThai())) hasNo = true;
                else if ("Đang nợ".equals(cn.getTrangThai())) hasPart = true;
            }
            if (hasNo && !hasPart) ttFinal = "Chưa nộp";
            else if (hasPart || hasNo) ttFinal = "Đang nợ";
            if (tongHP.signum() == 0) for (HocPhi hp : dsHP) {
                tongHP = tongHP.add(hp.getPhaiThu());
                tongConLai = tongConLai.add(hp.getPhaiThu());
                ttFinal = "Chưa nộp";
            }
            lblTongHP.setText(String.format("%,.0f VND", tongHP));
            lblDaThu.setText(String.format("%,.0f VND", tongDaThu));
            lblConLai.setText(String.format("%,.0f VND", tongConLai));
            lblTrangThai.setText("● Trạng thái: " + ttFinal);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void lapHoaDon() {
        if (currentSV == null) return;
        try {
            List<CongNo> debts = congNoDAO.getByMaSV(currentSV.getMaSV());
            List<ThanhToan> payments = thanhToanDAO.getByMaSV(currentSV.getMaSV());
            BigDecimal phaiThu = BigDecimal.ZERO, daThu = BigDecimal.ZERO, conLai = BigDecimal.ZERO;
            for (CongNo cn : debts) {
                if (cn.getSoTienNo() != null) phaiThu = phaiThu.add(cn.getSoTienNo());
                if (cn.getSoTienDaThu() != null) daThu = daThu.add(cn.getSoTienDaThu());
                if (cn.getConLai() != null) conLai = conLai.add(cn.getConLai());
            }
            StringBuilder text = new StringBuilder();
            text.append("TRƯỜNG ĐẠI HỌC - PHÒNG TÀI VỤ\n");
            text.append("PHIẾU XÁC NHẬN HỌC PHÍ / CÔNG NỢ\n");
            text.append("============================================================\n");
            text.append("Ngày lập: ").append(LocalDate.now()).append("\n");
            text.append("Mã sinh viên: ").append(currentSV.getMaSV()).append("\n");
            text.append("Họ tên: ").append(currentSV.getHoTen()).append("\n");
            text.append("Lớp: ").append(currentSV.getTenLop() == null ? "" : currentSV.getTenLop()).append("\n\n");
            text.append(String.format("Tổng phải thu: %,.0f VND\n", phaiThu));
            text.append(String.format("Tổng đã thu : %,.0f VND\n", daThu));
            text.append(String.format("Còn lại     : %,.0f VND\n", conLai));
            text.append("\nLỊCH SỬ THANH TOÁN\n");
            text.append("------------------------------------------------------------\n");
            if (payments.isEmpty()) text.append("Chưa có giao dịch thanh toán.\n");
            for (ThanhToan tt : payments) {
                text.append(tt.getNgayThanhToan()).append(" | ").append(tt.getTenHKNH()).append(" | ")
                    .append(String.format("%,.0f VND", tt.getSoTien())).append(" | ")
                    .append(tt.getHinhThucThanhToan() == null ? "" : tt.getHinhThucThanhToan()).append("\n");
            }
            text.append("\nNgười lập: ").append(UserSession.getHoTen()).append("\n");
            JTextArea area = new JTextArea(text.toString());
            area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 11));
            boolean printed = area.print(null, null, true, null, null, true);
            if (printed) JOptionPane.showMessageDialog(this, "✅ Phiếu đã được gửi tới máy in. Bạn có thể chọn 'Microsoft Print to PDF' để lưu PDF.");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Không thể lập/in phiếu: " + e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void nhanThanhToanNhanh() {
        if (currentSV == null) return;
        String soTienStr = JOptionPane.showInputDialog(this,
                "Nhập số tiền thanh toán (VND) cho sinh viên " + currentSV.getHoTen() + ":",
                "Nhận thanh toán nhanh", JOptionPane.QUESTION_MESSAGE);
        if (soTienStr == null || soTienStr.trim().isEmpty()) return;
        BigDecimal soTien;
        try { soTien = new BigDecimal(soTienStr.trim()); }
        catch (NumberFormatException e) { JOptionPane.showMessageDialog(this, "Số tiền không hợp lệ"); return; }
        String[] hkOpts;
        try {
            List<HocKyNamHoc> ds = hkDAO.getAll();
            hkOpts = new String[ds.size()];
            for (int i = 0; i < ds.size(); i++) hkOpts[i] = ds.get(i).getMaHKNH() + " - HK " + ds.get(i).getHocKy() + " " + ds.get(i).getNamHoc();
        } catch (SQLException e) { return; }
        String hk = (String) JOptionPane.showInputDialog(this, "Chọn kỳ áp dụng:", "Kỳ học",
                JOptionPane.QUESTION_MESSAGE, null, hkOpts, hkOpts[0]);
        if (hk == null) return;
        String maHK = hk.split(" - ")[0];
        ThanhToan tt = new ThanhToan();
        tt.setMaSV(currentSV.getMaSV());
        tt.setMaHKNH(maHK);
        tt.setSoTien(soTien);
        tt.setHinhThucThanhToan("Tiền mặt");
        tt.setNgayThanhToan(LocalDate.now().toString());
        tt.setNguoiThu("Thu Ngân (Nhanh)");
        tt.setGhiChu("Thanh toán nhanh");
        try {
            if (thanhToanDAO.thanhToan(tt)) {
                JOptionPane.showMessageDialog(this, "✅ Nhận thanh toán thành công: " + String.format("%,.0f VND", soTien));
                refreshDataForCurrentSV();
            }
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    private String str(Object o) { return o == null ? "—" : o.toString(); }
}
