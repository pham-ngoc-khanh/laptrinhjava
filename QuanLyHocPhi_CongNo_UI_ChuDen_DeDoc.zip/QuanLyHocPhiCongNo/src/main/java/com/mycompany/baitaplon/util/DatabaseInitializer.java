package com.mycompany.baitaplon.util;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.*;

public final class DatabaseInitializer {
    private DatabaseInitializer() {}

    public static void initialize() throws SQLException {
        try (Connection conn = DatabaseConnection.getConnection(); Statement st = conn.createStatement()) {
            executeScript(st, loadScript("/db/init.sql"));
            if (isFreshDatabase(conn)) executeScript(st, loadScript("/db/seed.sql"));
            ensureAdminAccount(conn);
        }
    }

    private static boolean isFreshDatabase(Connection conn) throws SQLException {
        String[] tables = {"Khoa", "SinhVien", "HocPhan", "TaiKhoan"};
        for (String table : tables) {
            try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM " + table)) {
                rs.next();
                if (rs.getInt(1) > 0) return false;
            }
        }
        return true;
    }

    private static void ensureAdminAccount(Connection conn) throws SQLException {
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM TaiKhoan")) {
            rs.next();
            if (rs.getInt(1) > 0) return;
        }
        try (PreparedStatement ps = conn.prepareStatement("INSERT INTO TaiKhoan(TenDangNhap,MatKhau,VaiTro,MaSV,HoTen,TrangThai) VALUES('thuky','123456','THU_KY',NULL,'Thư ký khoa','Hoat dong')")) {
            ps.executeUpdate();
        }
    }

    private static void executeScript(Statement st, String script) throws SQLException {
        for (String raw : script.split(";")) {
            String sql = raw.trim();
            if (!sql.isEmpty()) st.execute(sql);
        }
    }

    private static String loadScript(String resource) throws SQLException {
        InputStream in = DatabaseInitializer.class.getResourceAsStream(resource);
        if (in == null) throw new SQLException("Không tìm thấy script CSDL: " + resource);
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                String t = line.trim();
                if (!t.startsWith("--") && !t.isEmpty()) sb.append(line).append('\n');
            }
        } catch (IOException e) { throw new SQLException("Không đọc được script CSDL", e); }
        return sb.toString();
    }
}
