package com.mycompany.baitaplon.ui;

import java.awt.*;

public class Theme {
    public static final Color PRIMARY = new Color(99, 102, 241);
    public static final Color PRIMARY_DARK = new Color(79, 70, 229);
    public static final Color PRIMARY_LIGHT = new Color(165, 180, 252);
    public static final Color SECONDARY = new Color(14, 165, 233);
    public static final Color SUCCESS = new Color(16, 185, 129);
    public static final Color DANGER = new Color(239, 68, 68);
    public static final Color WARNING = new Color(245, 158, 11);
    public static final Color INFO = new Color(6, 182, 212);
    public static final Color PURPLE = new Color(139, 92, 246);
    public static final Color PINK = new Color(236, 72, 153);

    public static final Color BG = new Color(248, 250, 252);
    public static final Color SURFACE = Color.WHITE;
    public static final Color SURFACE_ALT = new Color(241, 245, 249);
    public static final Color BORDER = new Color(226, 232, 240);
    public static final Color TEXT = new Color(15, 23, 42);
    public static final Color TEXT_SECONDARY = new Color(71, 85, 105);
    public static final Color TEXT_MUTED = new Color(100, 116, 139);
    // Chữ dùng trên các nền sáng/pastel để luôn đủ tương phản.
    public static final Color TEXT_ON_LIGHT = new Color(15, 23, 42);

    public static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 28);
    public static final Font FONT_SUBTITLE = new Font("Segoe UI", Font.PLAIN, 14);
    public static final Font FONT_H2 = new Font("Segoe UI", Font.BOLD, 20);
    public static final Font FONT_H3 = new Font("Segoe UI", Font.BOLD, 16);
    public static final Font FONT_LABEL = new Font("Segoe UI", Font.BOLD, 12);
    public static final Font FONT_BODY = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_SMALL = new Font("Segoe UI", Font.PLAIN, 11);
    public static final Font FONT_STAT = new Font("Segoe UI", Font.BOLD, 26);
    public static final Font FONT_STAT_BIG = new Font("Segoe UI", Font.BOLD, 32);
    public static final Font FONT_ICON = new Font("Segoe UI Emoji", Font.PLAIN, 22);

    public static final int RADIUS = 12;
    public static final int RADIUS_SMALL = 8;
    public static final int SHADOW_PAD = 6;

    /** Độ sáng cảm nhận (0..1) để chọn màu chữ có tương phản tốt. */
    public static double luminance(Color c) {
        return (0.2126 * c.getRed() + 0.7152 * c.getGreen() + 0.0722 * c.getBlue()) / 255.0;
    }

    /**
     * Tự chuyển chữ sang màu đen/xanh đen khi nền sáng.
     * Nền tối vẫn giữ màu chữ được yêu cầu (thường là trắng).
     */
    public static Color readableForeground(Color background, Color requested) {
        if (background == null) return requested == null ? TEXT : requested;
        return luminance(background) >= 0.60 ? TEXT_ON_LIGHT : (requested == null ? Color.WHITE : requested);
    }

    public static Color mix(Color c1, Color c2, double ratio) {
        int r = (int) (c1.getRed() * ratio + c2.getRed() * (1 - ratio));
        int g = (int) (c1.getGreen() * ratio + c2.getGreen() * (1 - ratio));
        int b = (int) (c1.getBlue() * ratio + c2.getBlue() * (1 - ratio));
        return new Color(r, g, b);
    }
}
