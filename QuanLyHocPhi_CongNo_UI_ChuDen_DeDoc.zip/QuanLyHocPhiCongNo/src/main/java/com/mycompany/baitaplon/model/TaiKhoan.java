package com.mycompany.baitaplon.model;

public class TaiKhoan {
    private int maTK;
    private String tenDangNhap;
    private String matKhau;
    private VaiTro vaiTro;
    private String maSV;
    private String hoTen;
    private String trangThai;

    public TaiKhoan() {}

    public boolean isThuKy() {
        return vaiTro == VaiTro.THU_KY;
    }

    public boolean isSinhVien() {
        return vaiTro == VaiTro.SINH_VIEN;
    }

    public int getMaTK() { return maTK; }
    public void setMaTK(int maTK) { this.maTK = maTK; }
    public String getTenDangNhap() { return tenDangNhap; }
    public void setTenDangNhap(String tenDangNhap) { this.tenDangNhap = tenDangNhap; }
    public String getMatKhau() { return matKhau; }
    public void setMatKhau(String matKhau) { this.matKhau = matKhau; }
    public VaiTro getVaiTro() { return vaiTro; }
    public void setVaiTro(VaiTro vaiTro) { this.vaiTro = vaiTro; }
    public String getMaSV() { return maSV; }
    public void setMaSV(String maSV) { this.maSV = maSV; }
    public String getHoTen() { return hoTen; }
    public void setHoTen(String hoTen) { this.hoTen = hoTen; }
    public String getTrangThai() { return trangThai; }
    public void setTrangThai(String trangThai) { this.trangThai = trangThai; }
}
