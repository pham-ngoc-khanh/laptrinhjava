package com.mycompany.baitaplon.util;

import com.mycompany.baitaplon.model.TaiKhoan;

public final class UserSession {
    private static TaiKhoan current;

    private UserSession() {}

    public static void set(TaiKhoan taiKhoan) {
        current = taiKhoan;
    }

    public static TaiKhoan get() {
        return current;
    }

    public static void clear() {
        current = null;
    }

    public static boolean isLoggedIn() {
        return current != null;
    }

    public static boolean isThuKy() {
        return current != null && current.isThuKy();
    }

    public static boolean isSinhVien() {
        return current != null && current.isSinhVien();
    }

    public static String getMaSV() {
        return current != null ? current.getMaSV() : null;
    }

    public static String getHoTen() {
        return current != null ? current.getHoTen() : "";
    }
}
