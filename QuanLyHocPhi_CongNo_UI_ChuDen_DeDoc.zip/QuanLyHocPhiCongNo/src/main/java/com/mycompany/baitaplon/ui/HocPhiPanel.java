package com.mycompany.baitaplon.ui;

import com.mycompany.baitaplon.dao.HocPhiDAO;
import com.mycompany.baitaplon.dao.HocKyNamHocDAO;
import com.mycompany.baitaplon.dao.SinhVienDAO;
import com.mycompany.baitaplon.model.HocPhi;
import com.mycompany.baitaplon.model.HocKyNamHoc;
import com.mycompany.baitaplon.model.SinhVien;
import com.mycompany.baitaplon.util.UserSession;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.math.BigDecimal;
import java.util.List;

public class HocPhiPanel extends JPanel {
    private RoundedCombo<String> cboSV, cboHKNH;
    private RoundedButton bTinh, bLamMoi, bMienGiam;
    private StyledTable table;
    private DefaultTableModel model;
    private HocPhiDAO hpDAO = new HocPhiDAO();
    private SinhVienDAO svDAO = new SinhVienDAO();
    private HocKyNamHocDAO hkDAO = new HocKyNamHocDAO();
    private List<SinhVien> dsSV;
    private List<HocKyNamHoc> dsHK;

    public HocPhiPanel() {
        super(new BorderLayout(14, 14));
        setOpaque(false);
        setBorder(new EmptyBorder(6, 6, 6, 6));
        add(createTopPanel(), BorderLayout.NORTH);
        add(createTablePanel(), BorderLayout.CENTER);
        loadData();
        loadCombos();
    }

    private JLabel makeLbl(String s) { JLabel l = new JLabel(s); l.setFont(Theme.FONT_LABEL); l.setForeground(Theme.TEXT_SECONDARY); return l; }

    private JPanel createTopPanel() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(20, 22, 18, 22));
        card.setTopAccent(Theme.WARNING);
        JPanel p = new JPanel(new WrapLayout(FlowLayout.LEFT, 14, 8)); p.setOpaque(false);

        JPanel g1 = new JPanel(); g1.setLayout(new BoxLayout(g1, BoxLayout.Y_AXIS)); g1.setOpaque(false);
        g1.add(makeLbl("🎓 Sinh viên")); g1.add(Box.createVerticalStrut(4));
        cboSV = new RoundedCombo<>(); UiUtils.makeFlexible(cboSV,200,300,36);
        g1.add(cboSV);

        JPanel g2 = new JPanel(); g2.setLayout(new BoxLayout(g2, BoxLayout.Y_AXIS)); g2.setOpaque(false);
        g2.add(makeLbl("📅 Học kỳ - Năm học")); g2.add(Box.createVerticalStrut(4));
        cboHKNH = new RoundedCombo<>(); UiUtils.makeFlexible(cboHKNH,190,260,36);
        g2.add(cboHKNH);

        bTinh = new RoundedButton("TÍNH HỌC PHÍ", "success");
        bTinh.setPreferredSize(new Dimension(200, 40));
        bLamMoi = new RoundedButton("Làm mới", "warning");
        bLamMoi.setPreferredSize(new Dimension(140, 40));
        bMienGiam = new RoundedButton("Miễn giảm", "purple");
        bMienGiam.setPreferredSize(new Dimension(145, 40));
        bTinh.addActionListener(e -> tinhHocPhi());
        bLamMoi.addActionListener(e -> loadData());
        bMienGiam.addActionListener(e -> capNhatMienGiam());

        p.add(g1); p.add(g2); p.add(Box.createHorizontalStrut(8));
        JPanel bp = new JPanel(); bp.setLayout(new BoxLayout(bp, BoxLayout.Y_AXIS)); bp.setOpaque(false);
        bp.add(Box.createVerticalStrut(18));
        JPanel row = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0)); row.setOpaque(false);
        row.add(bTinh); row.add(bMienGiam); row.add(bLamMoi); bp.add(row);
        p.add(bp);

        card.add(p, BorderLayout.CENTER);
        JPanel wrap = new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(card);
        return wrap;
    }

    private JPanel createTablePanel() {
        CardPanel card = new CardPanel(new BorderLayout());
        card.setBorder(new EmptyBorder(12, 12, 12, 12));
        card.setTopAccent(Theme.DANGER);
        String[] cols = {"Mã HPPhi", "Mã SV", "Họ tên", "Học kỳ", "Tổng TC", "Tổng học phí", "Miễn giảm", "Phải thu", "Ngày tính"};
        model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new StyledTable(); table.setModel(model);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getColumnModel().getColumn(0).setPreferredWidth(80);
        table.getColumnModel().getColumn(1).setPreferredWidth(90);
        table.getColumnModel().getColumn(2).setPreferredWidth(200);
        table.getColumnModel().getColumn(3).setPreferredWidth(150);
        table.getColumnModel().getColumn(4).setPreferredWidth(80);
        table.getColumnModel().getColumn(5).setPreferredWidth(140);
        table.getColumnModel().getColumn(6).setPreferredWidth(110);
        table.getColumnModel().getColumn(7).setPreferredWidth(140);
        table.getColumnModel().getColumn(8).setPreferredWidth(110);
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        sp.getViewport().setOpaque(false); sp.setOpaque(false); UiUtils.tuneScrollPane(sp);
        card.add(sp, BorderLayout.CENTER);
        JPanel wrap = new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(card);
        return wrap;
    }

    private void loadData() {
        try {
            List<HocPhi> list;
            if (UserSession.isSinhVien()) {
                list = hpDAO.getByMaSV(UserSession.getMaSV());
            } else {
                list = hpDAO.getAll();
            }
            model.setRowCount(0);
            for (HocPhi hp : list) model.addRow(new Object[]{hp.getMaHPPhi(), hp.getMaSV(), hp.getHoTenSV(),
                hp.getTenHKNH(), hp.getTongTinChi(), money(hp.getTongHocPhi()), money(hp.getMienGiam()), money(hp.getPhaiThu()), hp.getNgayTinh()});
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    public void refreshData() { loadCombos(); loadData(); }

    public void configureForRole() {
        if (UserSession.isSinhVien()) {
            bTinh.setVisible(false);
            bMienGiam.setVisible(false);
            cboSV.setEnabled(false);
            String maSV = UserSession.getMaSV();
            for (int i = 0; i < cboSV.getItemCount(); i++) {
                if (cboSV.getItemAt(i).startsWith(maSV + " - ")) {
                    cboSV.setSelectedIndex(i);
                    break;
                }
            }
        }
    }

    private void loadCombos() {
        try {
            dsSV = svDAO.getAll(); cboSV.removeAllItems();
            for (SinhVien sv : dsSV) cboSV.addItem(sv.getMaSV() + " - " + sv.getHoTen());
            dsHK = hkDAO.getAll(); cboHKNH.removeAllItems();
            for (HocKyNamHoc hk : dsHK) cboHKNH.addItem(hk.getMaHKNH() + " - " + hk.toString());
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }

    private String money(BigDecimal value) { return String.format("%,.0f VND", value == null ? BigDecimal.ZERO : value); }

    private void capNhatMienGiam() {
        int row = table.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Chọn một dòng học phí cần cập nhật miễn giảm."); return; }
        String maSV = String.valueOf(model.getValueAt(row, 1));
        String hkDisplay = String.valueOf(model.getValueAt(row, 3));
        String maHK = null;
        try {
            for (HocKyNamHoc hk : hkDAO.getAll()) {
                String display = "HK " + hk.getHocKy() + " - " + hk.getNamHoc();
                if (display.equals(hkDisplay)) { maHK = hk.getMaHKNH(); break; }
            }
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, e.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE); return; }
        if (maHK == null) { JOptionPane.showMessageDialog(this, "Không xác định được học kỳ."); return; }
        String input = JOptionPane.showInputDialog(this, "Nhập số tiền miễn/giảm (VND):", "0");
        if (input == null) return;
        try {
            BigDecimal value = new BigDecimal(input.trim().replace(",", ""));
            hpDAO.updateMienGiam(maSV, maHK, value);
            JOptionPane.showMessageDialog(this, "✅ Đã cập nhật miễn giảm và đồng bộ công nợ.");
            loadData();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Số tiền không hợp lệ.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void tinhHocPhi() {
        if (cboSV.getSelectedIndex() < 0 || cboHKNH.getSelectedIndex() < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn Sinh viên và Học kỳ"); return;
        }
        String maSV = cboSV.getSelectedItem().toString().split(" - ")[0];
        String maHKNH = cboHKNH.getSelectedItem().toString().split(" - ")[0];
        try {
            if (hpDAO.tinhHocPhi(maSV, maHKNH)) { JOptionPane.showMessageDialog(this, "✅ Tính học phí thành công!"); loadData(); }
            else JOptionPane.showMessageDialog(this, "⚠ Sinh viên chưa đăng ký học phần nào trong học kỳ này");
        } catch (SQLException e) { JOptionPane.showMessageDialog(this, "Lỗi: " + e.getMessage()); }
    }
}
