package com.mycompany.baitaplon.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;
import javax.swing.event.TableModelListener;
import java.awt.*;

/** Bảng có cuộn ngang và tự căn chiều rộng cột để tiêu đề/nội dung không đè lên nhau. */
public class StyledTable extends JTable {
    private TableModel listenedModel;
    private final TableModelListener autoSizeListener = e -> SwingUtilities.invokeLater(this::autoSizeColumns);

    public StyledTable() {
        super();
        setup();
    }

    private void setup() {
        setFont(Theme.FONT_BODY);
        setRowHeight(36);
        setShowGrid(false);
        setIntercellSpacing(new Dimension(0, 0));
        setSelectionBackground(Theme.PRIMARY_LIGHT);
        setSelectionForeground(Theme.PRIMARY_DARK);
        setForeground(Theme.TEXT);
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder());
        setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        setFillsViewportHeight(true);

        JTableHeader h = getTableHeader();
        h.setFont(Theme.FONT_LABEL);
        h.setForeground(Color.WHITE);
        h.setBackground(Theme.PRIMARY);
        h.setOpaque(true);
        h.setPreferredSize(new Dimension(0, 42));
        h.setReorderingAllowed(false);
        h.setBorder(BorderFactory.createEmptyBorder());
        h.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean isSel, boolean hasFocus, int row, int col) {
                JLabel c = (JLabel) super.getTableCellRendererComponent(t, v, isSel, hasFocus, row, col);
                c.setOpaque(true);
                c.setFont(Theme.FONT_LABEL);
                c.setForeground(Color.WHITE);
                c.setBackground(Theme.PRIMARY);
                c.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
                c.setToolTipText(v == null ? null : v.toString());
                return c;
            }
        });

        setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v, boolean isSel, boolean hasFocus, int row, int col) {
                JLabel c = (JLabel) super.getTableCellRendererComponent(t, v, isSel, hasFocus, row, col);
                c.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
                c.setFont(Theme.FONT_BODY);
                c.setToolTipText(v == null ? null : v.toString());
                if (!isSel) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : Theme.SURFACE_ALT);
                    c.setForeground(Theme.TEXT);
                }
                return c;
            }
        });

        attachModel(getModel());
        addPropertyChangeListener("model", e -> {
            if (e.getOldValue() instanceof TableModel oldModel && autoSizeListener != null) {
                try { oldModel.removeTableModelListener(autoSizeListener); } catch (Exception ignored) {}
            }
            if (e.getNewValue() instanceof TableModel newModel) attachModel(newModel);
            SwingUtilities.invokeLater(this::autoSizeColumns);
        });
        SwingUtilities.invokeLater(this::autoSizeColumns);
    }

    private void attachModel(TableModel model) {
        if (model == null || model == listenedModel) return;
        if (listenedModel != null) {
            try { listenedModel.removeTableModelListener(autoSizeListener); } catch (Exception ignored) {}
        }
        listenedModel = model;
        listenedModel.addTableModelListener(autoSizeListener);
    }

    /** Căn cột theo tiêu đề + tối đa 80 dòng đầu, có giới hạn để bảng vẫn dễ dùng. */
    public void autoSizeColumns() {
        if (getColumnModel() == null || getColumnCount() == 0) return;
        int rows = Math.min(getRowCount(), 80);
        for (int col = 0; col < getColumnCount(); col++) {
            TableColumn column = getColumnModel().getColumn(col);
            int measured = 80;
            try {
                TableCellRenderer hr = getTableHeader().getDefaultRenderer();
                Component hc = hr.getTableCellRendererComponent(this, column.getHeaderValue(), false, false, -1, col);
                measured = Math.max(measured, hc.getPreferredSize().width + 8);
            } catch (Exception ignored) {}
            for (int row = 0; row < rows; row++) {
                try {
                    TableCellRenderer cr = getCellRenderer(row, col);
                    Component cc = prepareRenderer(cr, row, col);
                    measured = Math.max(measured, cc.getPreferredSize().width + 8);
                } catch (Exception ignored) {}
            }
            int current = column.getPreferredWidth();
            int width = Math.max(current, Math.min(360, measured));
            column.setMinWidth(Math.min(80, width));
            column.setPreferredWidth(width);
        }
        revalidate();
    }
}
