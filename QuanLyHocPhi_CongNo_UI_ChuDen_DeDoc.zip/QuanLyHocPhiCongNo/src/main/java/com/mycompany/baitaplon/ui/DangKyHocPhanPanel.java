package com.mycompany.baitaplon.ui;

import com.mycompany.baitaplon.dao.*;
import com.mycompany.baitaplon.model.*;
import com.mycompany.baitaplon.util.TableExportUtil;
import com.mycompany.baitaplon.util.UserSession;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class DangKyHocPhanPanel extends JPanel {
    private final DangKyHocPhanDAO dao = new DangKyHocPhanDAO();
    private final SinhVienDAO svDAO = new SinhVienDAO();
    private final HocPhanDAO hpDAO = new HocPhanDAO();
    private final HocKyNamHocDAO hkDAO = new HocKyNamHocDAO();
    private RoundedCombo<String> cboSV, cboHP, cboHK;
    private RoundedField txtSearch;
    private RoundedButton btnAdd, btnDelete, btnRefresh, btnExport;
    private StyledTable table;
    private DefaultTableModel model;
    private JLabel lblCount, lblCredits, lblAmount;

    public DangKyHocPhanPanel() {
        super(new BorderLayout(14,14));
        setOpaque(false); setBorder(new EmptyBorder(6,6,6,6));
        add(createTop(), BorderLayout.NORTH);
        add(createTable(), BorderLayout.CENTER);
        add(createSummary(), BorderLayout.SOUTH);
        loadCombos(); loadData();
    }

    private JLabel label(String s) { JLabel l=new JLabel(s); l.setFont(Theme.FONT_LABEL); l.setForeground(Theme.TEXT_SECONDARY); return l; }

    private JPanel createTop() {
        JPanel outer=new JPanel(new BorderLayout(0,10)); outer.setOpaque(false);
        CardPanel form=new CardPanel(new BorderLayout()); form.setTopAccent(Theme.PURPLE); form.setBorder(new EmptyBorder(18,22,16,22));
        JPanel row=new JPanel(new WrapLayout(FlowLayout.LEFT,12,8)); row.setOpaque(false);
        cboSV=new RoundedCombo<>(); cboSV.setPreferredSize(new Dimension(280,36));
        cboHP=new RoundedCombo<>(); cboHP.setPreferredSize(new Dimension(300,36));
        cboHK=new RoundedCombo<>(); cboHK.setPreferredSize(new Dimension(230,36));
        row.add(group("🎓 Sinh viên",cboSV)); row.add(group("📚 Học phần",cboHP)); row.add(group("📅 Học kỳ",cboHK));
        btnAdd=new RoundedButton("Đăng ký", "primary"); btnAdd.setPreferredSize(new Dimension(145,42)); btnAdd.addActionListener(e->addRegistration());
        JPanel bp=new JPanel(new BorderLayout()); bp.setOpaque(false); bp.setBorder(new EmptyBorder(18,4,0,0)); bp.add(btnAdd); row.add(bp);
        form.add(row); outer.add(form,BorderLayout.NORTH);

        CardPanel filter=new CardPanel(new BorderLayout()); filter.setTopAccent(Theme.INFO); filter.setBorder(new EmptyBorder(14,20,14,20));
        JPanel fr=new JPanel(new WrapLayout(FlowLayout.LEFT,10,6)); fr.setOpaque(false);
        txtSearch=new RoundedField(28); txtSearch.setPlaceholder("Tìm MSSV, họ tên hoặc học phần..."); txtSearch.setPreferredSize(new Dimension(360,36));
        txtSearch.addActionListener(e->loadData());
        RoundedButton find=new RoundedButton("Tìm", "secondary"); find.addActionListener(e->loadData());
        btnRefresh=new RoundedButton("Làm mới", "warning"); btnRefresh.addActionListener(e->{txtSearch.setText("");loadCombos();loadData();});
        btnDelete=new RoundedButton("Hủy đăng ký", "danger"); btnDelete.addActionListener(e->deleteRegistration());
        btnExport=new RoundedButton("Xuất CSV", "success"); btnExport.addActionListener(e->TableExportUtil.exportCsv(this,table,"dang-ky-hoc-phan"));
        fr.add(txtSearch); fr.add(find); fr.add(btnRefresh); fr.add(btnDelete); fr.add(btnExport); filter.add(fr);
        outer.add(filter,BorderLayout.CENTER); return outer;
    }

    private JPanel group(String title, JComponent c) { JPanel p=new JPanel(); p.setLayout(new BoxLayout(p,BoxLayout.Y_AXIS)); p.setOpaque(false); c.setMaximumSize(new Dimension(Integer.MAX_VALUE, Math.max(36,c.getPreferredSize().height))); p.add(label(title)); p.add(Box.createVerticalStrut(4)); p.add(c); return p; }

    private JPanel createTable() {
        CardPanel card=new CardPanel(new BorderLayout()); card.setTopAccent(Theme.SECONDARY); card.setBorder(new EmptyBorder(10,10,10,10));
        model=new DefaultTableModel(new String[]{"Mã ĐK","Mã SV","Họ tên","Mã HP","Tên học phần","Số TC","Học phí/TC","Thành tiền","Học kỳ","Ngày ĐK"},0){public boolean isCellEditable(int r,int c){return false;}};
        table=new StyledTable(); table.setModel(model); table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getColumnModel().getColumn(0).setPreferredWidth(65); table.getColumnModel().getColumn(2).setPreferredWidth(170); table.getColumnModel().getColumn(4).setPreferredWidth(200); table.getColumnModel().getColumn(8).setPreferredWidth(140);
        JScrollPane sp=new JScrollPane(table); sp.setBorder(BorderFactory.createEmptyBorder()); sp.getViewport().setOpaque(false); sp.setOpaque(false); UiUtils.tuneScrollPane(sp); card.add(sp);
        JPanel wrap=new JPanel(new BorderLayout()); wrap.setOpaque(false); wrap.add(card); return wrap;
    }

    private JPanel createSummary() {
        CardPanel card=new CardPanel(new BorderLayout());
        card.setTopAccent(Theme.SUCCESS);
        card.setBorder(new EmptyBorder(12,16,12,16));
        ResponsiveGridPanel grid = new ResponsiveGridPanel(3, 220, 12, 10);
        lblCount=summary("Số lượt đăng ký","0");
        lblCredits=summary("Tổng tín chỉ","0");
        lblAmount=summary("Tổng học phí","0 VND");
        grid.add(lblCount); grid.add(lblCredits); grid.add(lblAmount);
        card.add(grid, BorderLayout.CENTER);
        JPanel w=new JPanel(new BorderLayout());w.setOpaque(false);w.add(card);return w;
    }
    private JLabel summary(String t,String v){JLabel l=new JLabel("<html><span style='color:#64748b'>"+t+"</span><br><b style='font-size:16px;color:#0f172a'>"+v+"</b></html>");l.setBorder(new EmptyBorder(6,12,6,12));l.setPreferredSize(new Dimension(220,58));l.setToolTipText(t+": "+v);return l;}

    public void configureForRole() {
        if(UserSession.isSinhVien()){
            btnAdd.setVisible(false); btnDelete.setVisible(false); cboSV.setEnabled(false); cboHP.setEnabled(false); cboHK.setEnabled(false);
            String ma=UserSession.getMaSV(); for(int i=0;i<cboSV.getItemCount();i++) if(cboSV.getItemAt(i).startsWith(ma+" - ")) {cboSV.setSelectedIndex(i);break;}
        }
    }

    public void refreshData(){loadCombos();loadData();}

    private void loadCombos(){
        try{
            cboSV.removeAllItems(); for(SinhVien s:svDAO.getAll()) cboSV.addItem(s.getMaSV()+" - "+s.getHoTen());
            cboHP.removeAllItems(); for(HocPhan h:hpDAO.getAll()) cboHP.addItem(h.getMaHP()+" - "+h.getTenHP()+" ("+h.getSoTinChi()+" TC)");
            cboHK.removeAllItems(); for(HocKyNamHoc h:hkDAO.getAll()) cboHK.addItem(h.getMaHKNH()+" - "+h.toString());
        }catch(SQLException e){showError(e);}
    }

    private void loadData(){
        try{
            List<DangKyHocPhan> list;
            if(UserSession.isSinhVien()) list=dao.getByMaSV(UserSession.getMaSV());
            else {String k=txtSearch==null?"":txtSearch.getText().trim(); list=k.isEmpty()?dao.getAll():dao.search(k);}
            model.setRowCount(0); int tc=0; BigDecimal money=BigDecimal.ZERO;
            for(DangKyHocPhan d:list){model.addRow(new Object[]{d.getMaDKHP(),d.getMaSV(),d.getHoTenSV(),d.getMaHP(),d.getTenHP(),d.getSoTinChi(),String.format("%,.0f",d.getHocPhiMotTinChi()),String.format("%,.0f",d.getThanhTien()),d.getTenHKNH(),d.getNgayDangKy()});tc+=d.getSoTinChi();money=money.add(d.getThanhTien());}
            if(lblCount!=null){lblCount.setText(html("Số lượt đăng ký",String.valueOf(list.size())));lblCredits.setText(html("Tổng tín chỉ",String.valueOf(tc)));lblAmount.setText(html("Tổng học phí",String.format("%,.0f VND",money)));}
        }catch(SQLException e){showError(e);}
    }
    private String html(String t,String v){return "<html><span style='color:#64748b'>"+t+"</span><br><b style='font-size:16px;color:#0f172a'>"+v+"</b></html>";}

    private void addRegistration(){
        if(cboSV.getSelectedItem()==null||cboHP.getSelectedItem()==null||cboHK.getSelectedItem()==null){JOptionPane.showMessageDialog(this,"Vui lòng chọn đủ sinh viên, học phần và học kỳ.");return;}
        String sv=code(cboSV), hp=code(cboHP), hk=code(cboHK);
        try{dao.insert(sv,hp,hk,Date.valueOf(LocalDate.now()));JOptionPane.showMessageDialog(this,"✅ Đăng ký thành công. Học phí và công nợ đã được tính/cập nhật tự động.");loadData();}
        catch(SQLException e){showError(e);}
    }

    private void deleteRegistration(){
        int r=table.getSelectedRow(); if(r<0){JOptionPane.showMessageDialog(this,"Chọn một đăng ký cần hủy.");return;}
        int id=Integer.parseInt(model.getValueAt(r,0).toString());
        if(JOptionPane.showConfirmDialog(this,"Hủy đăng ký học phần đã chọn? Học phí sẽ được tính lại tự động.","Xác nhận",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;
        try{if(dao.delete(id)){JOptionPane.showMessageDialog(this,"✅ Đã hủy đăng ký và đồng bộ học phí/công nợ.");loadData();}}catch(SQLException e){showError(e);}
    }
    private String code(RoundedCombo<String> c){return c.getSelectedItem().toString().split(" - ")[0];}
    private void showError(Exception e){JOptionPane.showMessageDialog(this,e.getMessage(),"Lỗi",JOptionPane.ERROR_MESSAGE);}
}
