package com.mycompany.baitaplon.model;

public enum VaiTro {
    SINH_VIEN("Sinh viên"),
    THU_KY("Thư ký khoa");

    private final String tenHienThi;

    VaiTro(String tenHienThi) {
        this.tenHienThi = tenHienThi;
    }

    public String getTenHienThi() {
        return tenHienThi;
    }

    public static VaiTro fromDb(String value) {
        if (value == null) return null;
        return switch (value.toUpperCase()) {
            case "SINH_VIEN", "SINHVIEN" -> SINH_VIEN;
            case "THU_KY", "THUKY" -> THU_KY;
            default -> null;
        };
    }
}
